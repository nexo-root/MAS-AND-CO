import sys,json,re
from faster_whisper import WhisperModel
m=WhisperModel('small',device='cpu',compute_type='int8',download_root='/opt/whisper-models')
seg,_=m.transcribe(sys.argv[1],language='es',beam_size=1,vad_filter=False)
txt=' '.join(s.text.strip() for s in seg)
ref=' '.join(w['p'] for w in json.load(open(sys.argv[2])))
norm=lambda s:re.sub(r'[^a-záéíóúñü0-9 ]','',s.lower()).split()
a,b=norm(txt),norm(ref)
import difflib
r=difflib.SequenceMatcher(None,a,b).ratio()
print('ASR:',txt);print('match ratio %.3f'%r)
