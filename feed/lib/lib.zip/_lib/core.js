import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { BokehPass } from 'three/addons/postprocessing/BokehPass.js';
export const OW=1080, OH=1920;
const FinalShader={uniforms:{tDiffuse:{value:null},uT:{value:0},uGrain:{value:0.035},uVig:{value:0.35},uCA:{value:0},uGlitch:{value:0},uFlash:{value:0},uFlashCol:{value:new THREE.Color(1,1,1)},uLift:{value:new THREE.Vector3(0,0,0)},uGain:{value:new THREE.Vector3(1,1,1)},uSat:{value:1}},
vertexShader:`varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,
fragmentShader:`uniform sampler2D tDiffuse;uniform float uT,uGrain,uVig,uCA,uGlitch,uFlash,uSat;uniform vec3 uFlashCol,uLift,uGain;varying vec2 vUv;
float h(vec2 p){return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453);}
void main(){vec2 uv=vUv;
 if(uGlitch>0.){float row=floor(uv.y*48.);float fr=floor(uT*30.);float r=h(vec2(row,fr));if(r<uGlitch*0.55){uv.x+=(h(vec2(row,fr+3.))-.5)*0.12*uGlitch;}}
 vec2 d=uv-.5;float ca=uCA*0.012+uGlitch*0.01;
 vec3 c=vec3(texture2D(tDiffuse,uv-d*ca).r,texture2D(tDiffuse,uv).g,texture2D(tDiffuse,uv+d*ca).b);
 float l=dot(c,vec3(.299,.587,.114));c=mix(vec3(l),c,uSat);
 c=uLift+c*uGain;
 float v=smoothstep(1.05,0.35,length(d*vec2(1.0,0.82)));c*=mix(1.,v,uVig);
 c+=(h(uv*vec2(1123.,1997.)+fract(uT*7.13))-.5)*uGrain;
 c=mix(c,uFlashCol,clamp(uFlash,0.,1.));
 gl_FragColor=vec4(c,1.);}`};
export function makeCore(o={}){
  const q=new URLSearchParams(location.search);
  const SS=parseFloat(q.get('ss')||o.ss||1.5);
  const W=Math.round(OW*SS),H=Math.round(OH*SS);
  const renderer=new THREE.WebGLRenderer({antialias:false,preserveDrawingBuffer:true,powerPreference:'high-performance'});
  renderer.setPixelRatio(1);renderer.setSize(W,H,false);
  renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=o.exposure??1.0;
  renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
  const scene=new THREE.Scene();
  const cam=new THREE.PerspectiveCamera(32,OW/OH,0.02,200);
  const rt=new THREE.WebGLRenderTarget(W,H,{type:THREE.HalfFloatType,samples:4});
  const comp=new EffectComposer(renderer,rt);comp.setSize(W,H);
  comp.addPass(new RenderPass(scene,cam));
  let bokeh=null;if(o.dof){bokeh=new BokehPass(scene,cam,{focus:3,aperture:0.002,maxblur:0.008});comp.addPass(bokeh);}
  const bloom=new UnrealBloomPass(new THREE.Vector2(W,H),...(o.bloom||[0.55,0.5,0.82]));comp.addPass(bloom);
  comp.addPass(new OutputPass());
  const fin=new ShaderPass(FinalShader);comp.addPass(fin);
  const out=document.createElement('canvas');out.width=OW;out.height=OH;const octx=out.getContext('2d');
  octx.imageSmoothingEnabled=true;octx.imageSmoothingQuality='high';
  const ov=document.createElement('canvas');ov.width=OW;ov.height=OH;const ctx=ov.getContext('2d');
  function glitch2d(amt,t){ // whole-frame slice + rgb split, deterministic
    if(amt<=0.001)return;const img=octx.getImageData(0,0,OW,OH),s=img.data,dst=new Uint8ClampedArray(s.length);
    const fr=Math.floor(t*30);const H2=(a,b)=>{const x=Math.sin(a*12.9898+b*78.233)*43758.5453;return x-Math.floor(x);};
    const band=24;const sp=Math.round(14*amt);
    for(let y=0;y<OH;y++){const b=Math.floor(y/band);const r=H2(b,fr);const off=r<0.45*amt?Math.round((H2(b,fr+9)-.5)*180*amt):0;
      for(let x=0;x<OW;x++){const i=(y*OW+x)*4;const xr=Math.min(OW-1,Math.max(0,x-off-sp)),xg=Math.min(OW-1,Math.max(0,x-off)),xb=Math.min(OW-1,Math.max(0,x-off+sp));
        dst[i]=s[(y*OW+xr)*4];dst[i+1]=s[(y*OW+xg)*4+1];dst[i+2]=s[(y*OW+xb)*4+2];dst[i+3]=255;}}
    img.data.set(dst);octx.putImageData(img,0,0);}
  function frame(fmt,{glitch=0,t=0,drawOverlay}={}){
    fin.uniforms.uT.value=t;comp.render();
    octx.drawImage(renderer.domElement,0,0,W,H,0,0,OW,OH);
    if(drawOverlay){ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,OW,OH);drawOverlay(ctx);octx.drawImage(ov,0,0);}
    glitch2d(glitch,t);
    return out.toDataURL(fmt==='png'?'image/png':'image/jpeg',0.94).split(',')[1];
  }
  return {THREE,renderer,scene,cam,comp,bloom,bokeh,fin,out,octx,ov,ctx,frame,SS,W,H};
}
export async function loadFont(name,url,desc={}){const f=new FontFace(name,`url(${url})`,desc);await f.load();document.fonts.add(f);return f;}
