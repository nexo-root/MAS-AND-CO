import * as THREE from 'three';
// generic deterministic point sprites: caller fills arrays each frame
export class Sprites{
  constructor(scene,max,{additive=true,tex=null,depthTest=true}={}){
    this.max=max;const g=new THREE.BufferGeometry();
    this.pos=new Float32Array(max*3);this.col=new Float32Array(max*3);this.sz=new Float32Array(max);this.al=new Float32Array(max);
    g.setAttribute('position',new THREE.BufferAttribute(this.pos,3));g.setAttribute('color',new THREE.BufferAttribute(this.col,3));
    g.setAttribute('size',new THREE.BufferAttribute(this.sz,1));g.setAttribute('alpha',new THREE.BufferAttribute(this.al,1));
    if(!tex){const c=document.createElement('canvas');c.width=c.height=64;const x=c.getContext('2d');const gr=x.createRadialGradient(32,32,0,32,32,32);gr.addColorStop(0,'rgba(255,255,255,1)');gr.addColorStop(0.35,'rgba(255,255,255,0.55)');gr.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=gr;x.fillRect(0,0,64,64);tex=new THREE.CanvasTexture(c);}
    this.mat=new THREE.ShaderMaterial({uniforms:{map:{value:tex},uScale:{value:1000}},transparent:true,depthWrite:false,depthTest,blending:additive?THREE.AdditiveBlending:THREE.NormalBlending,
      vertexShader:`attribute float size;attribute float alpha;varying vec3 vC;varying float vA;uniform float uScale;void main(){vC=color;vA=alpha;vec4 mv=modelViewMatrix*vec4(position,1.);gl_PointSize=size*uScale/max(0.01,-mv.z);gl_Position=projectionMatrix*mv;}`,
      fragmentShader:`uniform sampler2D map;varying vec3 vC;varying float vA;void main(){vec4 t=texture2D(map,gl_PointCoord);gl_FragColor=vec4(vC*t.rgb,t.a*vA);if(gl_FragColor.a<0.003)discard;}`,vertexColors:true});
    this.pts=new THREE.Points(g,this.mat);this.pts.frustumCulled=false;scene.add(this.pts);this.g=g;this.n=0;
  }
  begin(){this.n=0;}
  add(x,y,z,size,alpha,r=1,g=1,b=1){if(this.n>=this.max)return;const i=this.n++;this.pos[i*3]=x;this.pos[i*3+1]=y;this.pos[i*3+2]=z;this.sz[i]=size;this.al[i]=alpha;this.col[i*3]=r;this.col[i*3+1]=g;this.col[i*3+2]=b;}
  end(heightPx){for(let i=this.n;i<this.max;i++){this.al[i]=0;this.sz[i]=0;}
    for(const k of ['position','color','size','alpha'])this.g.attributes[k].needsUpdate=true;if(heightPx)this.mat.uniforms.uScale.value=heightPx;}
}
