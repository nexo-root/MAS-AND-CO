import numpy as np, subprocess, json
from scipy import signal
SR=48000
_rng=np.random.default_rng(11)
def sec(t): return int(round(t*SR))
def norm(s):
    m=np.max(np.abs(s))+1e-12; return s/m
def rmsn(s):
    # normalize to RMS 1 over loudest 120 ms
    w=int(0.12*SR); 
    if len(s)<=w: r=np.sqrt(np.mean(s**2))+1e-12
    else:
        e=np.convolve(s**2,np.ones(w)/w,'valid'); r=np.sqrt(e.max())+1e-12
    return s/r
def env_ar(n,a,r):
    e=np.ones(n); na=min(n,int(a*SR)); nr=min(n,int(r*SR))
    if na>0: e[:na]=np.linspace(0,1,na)
    if nr>0: e[n-nr:]*=np.linspace(1,0,nr)
    return e
def tone(f,d,dec=6,h=((1,1),)):
    t=np.arange(int(d*SR))/SR; s=sum(a*np.sin(2*np.pi*f*k*t) for k,a in h); return s*np.exp(-t*dec)
def click(f=2000,d=0.03,noise=0.4):
    t=np.arange(int(d*SR))/SR; s=np.sin(2*np.pi*f*t)*np.exp(-t*140)+noise*_rng.standard_normal(len(t))*np.exp(-t*500); return s
def tick(f=3200):
    t=np.arange(int(0.05*SR))/SR; s=np.sin(2*np.pi*f*t)*np.exp(-t*160)+0.6*np.sin(2*np.pi*f*1.5*t)*np.exp(-t*220)+0.3*_rng.standard_normal(len(t))*np.exp(-t*900); return s
def pop(f=600,d=0.09):
    t=np.arange(int(d*SR))/SR; fr=f*(1+1.5*np.exp(-t*60)); ph=2*np.pi*np.cumsum(fr)/SR; return np.sin(ph)*np.exp(-t*45)
def thud(f0=90,d=0.45,k=12):
    t=np.arange(int(d*SR))/SR; ph=2*np.pi*np.cumsum(f0*(0.6+1.4*np.exp(-t*25)))/SR; return np.sin(ph)*np.exp(-t*k)
def boom(d=1.6):
    t=np.arange(int(d*SR))/SR; ph=2*np.pi*np.cumsum(32+48*np.exp(-t*7))/SR; s=np.sin(ph)*np.exp(-t*2.6)
    nz=_rng.standard_normal(len(t)); b,a=signal.butter(2,180/(SR/2)); s+=0.5*signal.lfilter(b,a,nz)*np.exp(-t*6); return s
def bandnoise(d,f0,f1,q=0.6):
    n=int(d*SR); nz=_rng.standard_normal(n); out=np.zeros(n); blk=512; zi=None
    for i in range(0,n,blk):
        u=i/max(1,n-1); fc=f0*(f1/f0)**u; lo=max(60,fc*(1-q)); hi=min(SR/2*0.95,fc*(1+q))
        b,a=signal.butter(2,[lo/(SR/2),hi/(SR/2)],'band'); out[i:i+blk]=signal.lfilter(b,a,nz[i:i+blk])
    return out
def whoosh(d=0.8,f0=300,f1=2600,shape=1.6):
    s=bandnoise(d,f0,f1); e=np.sin(np.pi*np.linspace(0,1,len(s)))**shape; return s*e
def swish(d=0.35): return whoosh(d,1200,5000,2.5)
def riser(d,f0=200,f1=1600):
    t=np.arange(int(d*SR))/SR; fr=f0*(f1/f0)**(t/d); ph=2*np.pi*np.cumsum(fr)/SR
    s=0.6*np.sin(ph)+0.4*np.sin(ph*2.01); s+=0.5*bandnoise(d,f0*2,f1*3)*(t/d); return s*(t/d)**1.5
def ding(f0=1318.5,d=1.4):
    t=np.arange(int(d*SR))/SR; return sum(a*np.sin(2*np.pi*f0*r*t)*np.exp(-t*k) for r,a,k in [(1,1,3),(2.0,0.35,5),(3.01,0.2,8),(0.5,0.25,4)])
def chime(notes,gap=0.07,d=1.2):
    out=np.zeros(int((d+gap*len(notes))*SR))
    for i,f in enumerate(notes): s=ding(f,d); q=sec(i*gap); out[q:q+len(s)]+=s[:len(out)-q]
    return out
def glitch(d=0.15):
    n=int(d*SR); s=_rng.standard_normal(n); s=np.round(s*3)/3
    hold=np.repeat(s[::40],40)[:n]; t=np.arange(n)/SR; sq=np.sign(np.sin(2*np.pi*(900+600*np.sin(t*90))*t))*0.6
    return (hold*0.7+sq)*env_ar(n,0.002,0.03)
def zap_down(d=0.35):
    t=np.arange(int(d*SR))/SR; fr=4000*np.exp(-t*12)+80; ph=2*np.pi*np.cumsum(fr)/SR; return np.sign(np.sin(ph))*0.5*np.exp(-t*6)+0.4*np.sin(ph)
def blip(f=880,d=0.12):
    t=np.arange(int(d*SR))/SR; return np.sin(2*np.pi*f*t)*env_ar(len(t),0.004,0.06)+0.5*np.sin(2*np.pi*f*2*t)*env_ar(len(t),0.004,0.04)
def buzz(f=150,d=0.3):
    t=np.arange(int(d*SR))/SR; s=signal.sawtooth(2*np.pi*f*t)*0.6; b,a=signal.butter(2,2000/(SR/2)); return signal.lfilter(b,a,s)*env_ar(len(t),0.005,0.05)
def shimmer(d=1.4,n=22,f0=2200,f1=6000):
    out=np.zeros(int(d*SR))
    for k in range(n):
        f=f0+_rng.random()*(f1-f0); st=_rng.random()*d*0.7; q=sec(st); t=np.arange(len(out)-q)/SR; out[q:]+=np.sin(2*np.pi*f*t)*np.exp(-t*7)
    return out
def taps(times,f=1800,d=0.02):
    return [(t,click(f*(0.8+0.4*_rng.random()),d,0.6)) for t in times]
class Mix:
    def __init__(s,dur,voice_path):
        s.N=sec(dur); s.dur=dur
        raw='/tmp/_v.raw'; subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',voice_path,'-ac','1','-ar',str(SR),'-f','f32le',raw],check=True)
        v=np.fromfile(raw,dtype=np.float32).astype(np.float64); s.V=np.zeros(s.N); s.V[:min(len(v),s.N)]=v[:s.N]; s.vlen=len(v)/SR
        w=int(0.05*SR); e=np.convolve(s.V**2,np.ones(w)/w,'same'); thr=np.max(e)*0.02; act=e>thr
        s.vr=np.sqrt(np.mean(s.V[act]**2)); s.act=act
        s.FX=np.zeros(s.N); s.MUS=np.zeros(s.N); s.events=0
    def add(s,t,sig,g,bus='fx'):
        q=sec(t); 
        if q>=s.N: return
        x=rmsn(sig)*s.vr*10**(g/20); q1=min(s.N,q+len(x)); (s.FX if bus=='fx' else s.MUS)[q:q1]+=x[:q1-q]; s.events+=1
    def silence(s,t0,t1,fade=0.03):
        a,b=sec(t0),sec(t1); f=int(fade*SR); m=np.ones(s.N); m[a:b]=0; m[max(0,a-f):a]=np.linspace(1,0,a-max(0,a-f)); m[b:b+f]=np.linspace(0,1,len(m[b:b+f])); s.FX*=m; s.MUS*=m
    def report(s):
        out=[]; w=int(0.5*SR)
        for i in range(0,s.N-w,w):
            va=s.act[i:i+w].mean()
            if va>0.5:
                vr=np.sqrt(np.mean(s.V[i:i+w]**2))+1e-12; br=np.sqrt(np.mean((s.FX[i:i+w]+s.MUS[i:i+w])**2))+1e-12; out.append((i/SR,20*np.log10(br/vr)))
        return out
    def render(s,path):
        mix=s.V+s.FX+s.MUS; pk=np.max(np.abs(mix)); g=10**(-1/20)/pk; mix*=g
        raw='/tmp/_m.raw'; mix.astype(np.float32).tofile(raw)
        subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','f32le','-ar',str(SR),'-ac','1','-i',raw,'-ac','2','-c:a','pcm_s16le',path],check=True)
        return g
def S(*parts):
    """sum signals of different lengths; parts may be (gain,sig) tuples or sigs"""
    items=[(p if isinstance(p,tuple) else (1.0,p)) for p in parts]
    n=max(len(s) for g,s in items); out=np.zeros(n)
    for g,s in items: out[:len(s)]+=g*s
    return out
