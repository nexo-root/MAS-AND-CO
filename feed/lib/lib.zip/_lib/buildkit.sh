#!/bin/bash
# usage: buildkit.sh <videodir> <duration_seconds>
set -e
V=$1; DUR=$2; K=$V/kit
rm -rf $K && mkdir -p $K/sim
cp $V/sim/index.html $K/sim/ && cp -r $V/sim/js $V/sim/assets $V/sim/fonts $K/sim/
# copy only the three.js files actually imported (recursive)
node -e '
const fs=require("fs"),path=require("path");const root=process.argv[1],dst=process.argv[2];
const map={"three":"node_modules/three/build/three.module.js","three/addons/":"node_modules/three/examples/jsm/"};
const seen=new Set();const q=[];
for(const f of fs.readdirSync(path.join(root,"js")))q.push(path.join(root,"js",f));
const res=(spec,from)=>{if(spec==="three")return path.join(root,map.three);if(spec.startsWith("three/addons/"))return path.join(root,map["three/addons/"],spec.slice(13));if(spec.startsWith("."))return path.resolve(path.dirname(from),spec);return null;};
while(q.length){const f=q.pop();if(seen.has(f))continue;seen.add(f);const s=fs.readFileSync(f,"utf8");const re=/(?:import|export)[^"'"'"']*?from\s*["'"'"']([^"'"'"']+)["'"'"']|import\s*["'"'"']([^"'"'"']+)["'"'"']/g;let m;while((m=re.exec(s))){const sp=m[1]||m[2];const r=res(sp,f);if(r&&fs.existsSync(r))q.push(r);}}
for(const f of seen){if(!f.includes("node_modules"))continue;const rel=path.relative(root,f);const o=path.join(dst,rel);fs.mkdirSync(path.dirname(o),{recursive:true});fs.copyFileSync(f,o);}
// three.module.js may import three.core.js in newer versions
const b=path.join(root,"node_modules/three/build");for(const x of fs.readdirSync(b))if(/^three\.core/.test(x)){fs.copyFileSync(path.join(b,x),path.join(dst,"node_modules/three/build",x));}
fs.copyFileSync(path.join(root,"node_modules/three/LICENSE"),path.join(dst,"node_modules/three/LICENSE"));
console.log("three files:",[...seen].filter(f=>f.includes("node_modules")).length);
' $V/sim $K/sim
cp $V/audio/mix.wav $K/mix.wav
cat > $K/KIT.txt <<EOT
duracion_segundos: $DUR
fps: 30
cuadros: $(python3 -c "print(round($DUR*30))")
viewport: 1080x1920
pagina: sim/index.html
contrato: window.__ready === true cuando termina de cargar; window.renderFrame(t, 'jpeg'|'png') devuelve el cuadro del segundo t en base64 a 1080x1920.
audio: mix.wav (voz + sonidos + musica, ya mezclado, duracion final)
EOT
du -sh $K
