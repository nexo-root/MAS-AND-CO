// usage: node render.cjs <simdir> <outdir> <times_csv> [query]
const { chromium } = require('/usr/local/lib/node_modules/playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const [simdir, outdir, times_, query] = process.argv.slice(2);
const ROOT = path.resolve(simdir);
const MIME = {'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.ttf':'font/ttf','.woff2':'font/woff2','.hdr':'application/octet-stream'};
const frames = times_.split(',').map(s => ({ t: parseFloat(s), name: 't' + parseFloat(s).toFixed(2).replace('.', '_') }));
fs.mkdirSync(outdir, { recursive: true });
const srv = http.createServer((q, r) => { const p = path.join(ROOT, decodeURIComponent(q.url.split('?')[0]));
  fs.readFile(p, (e, d) => { if (e) { r.writeHead(404); r.end(); return; } r.writeHead(200, { 'Content-Type': MIME[path.extname(p)] || 'application/octet-stream' }); r.end(d); }); });
srv.listen(0, '127.0.0.1', async () => {
  const port = srv.address().port; const t0 = Date.now();
  const browser = await chromium.launch({ args: ['--use-angle=swiftshader','--use-gl=angle','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--enable-webgl','--disable-gpu-sandbox','--js-flags=--max-old-space-size=6000'] });
  const page = await browser.newPage({ viewport: { width: 1080, height: 1920 }, deviceScaleFactor: 1 });
  page.on('console', m => console.log('[pg]', m.text()));
  page.on('pageerror', e => console.log('PAGEERROR', e.message));
  await page.goto(`http://127.0.0.1:${port}/index.html${query?('?'+query):''}`);
  await page.waitForFunction(() => window.__ready === true || window.__error, null, { timeout: 600000 });
  const err = await page.evaluate(() => window.__error || null); if (err) { console.log('INIT ERROR', err); process.exit(2); }
  console.log(`init ${((Date.now() - t0) / 1000).toFixed(1)}s`);
  for (const f of frames) { const ts = Date.now();
    const b64 = await page.evaluate(([t]) => window.renderFrame(t, 'jpeg'), [f.t]);
    fs.writeFileSync(path.join(outdir, f.name + '.jpg'), Buffer.from(b64, 'base64'));
    console.log(`${f.name} ${(Date.now() - ts)}ms`); }
  await browser.close(); srv.close(); process.exit(0);
});
