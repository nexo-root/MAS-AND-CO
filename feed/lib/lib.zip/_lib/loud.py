import sys,subprocess,re,numpy as np
# normalize wav to target LUFS (default -14) keeping sample peak <= -1 dBFS
p=sys.argv[1]; tgt=float(sys.argv[2]) if len(sys.argv)>2 else -14.0
def meas(f):
    o=subprocess.run(['ffmpeg','-hide_banner','-i',f,'-af','ebur128=peak=sample','-f','null','-'],capture_output=True,text=True).stderr
    I=float(re.findall(r'I:\s+(-?[\d.]+) LUFS',o)[-1]); pk=float(re.findall(r'Peak:\s+(-?[\d.]+) dBFS',o)[-1]); return I,pk
I,pk=meas(p); g=min(tgt-I,-1.0-pk)
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',p,'-af',f'volume={g:.2f}dB','-c:a','pcm_s16le','/tmp/_n.wav'],check=True)
subprocess.run(['mv','/tmp/_n.wav',p],check=True); I2,pk2=meas(p); print(f'LUFS {I:.1f} -> {I2:.1f}, peak {pk:.1f} -> {pk2:.1f} dBFS (gain {g:.2f} dB)')
