// node events.cjs <simdir> <out.json>
const { chromium } = require('/usr/local/lib/node_modules/playwright');
const http=require('http'),fs=require('fs'),path=require('path');const [simdir,outp]=process.argv.slice(2);const ROOT=path.resolve(simdir);
const MIME={'.html':'text/html','.js':'text/javascript','.json':'application/json','.ttf':'font/ttf','.png':'image/png','.jpg':'image/jpeg'};
const srv=http.createServer((q,r)=>{const p=path.join(ROOT,decodeURIComponent(q.url.split('?')[0]));fs.readFile(p,(e,d)=>{if(e){r.writeHead(404);r.end();return;}r.writeHead(200,{'Content-Type':MIME[path.extname(p)]||'application/octet-stream'});r.end(d);});});
srv.listen(0,'127.0.0.1',async()=>{const b=await chromium.launch({args:['--use-angle=swiftshader','--use-gl=angle','--enable-unsafe-swiftshader']});const pg=await b.newPage({viewport:{width:1080,height:1920}});
 pg.on('pageerror',e=>console.log('PAGEERROR',e.message));await pg.goto(`http://127.0.0.1:${srv.address().port}/index.html?ss=0.25`);await pg.waitForFunction(()=>window.__ready===true||window.__error,null,{timeout:300000});
 const ev=await pg.evaluate(()=>window.__events||{err:window.__error});fs.writeFileSync(outp,JSON.stringify(ev));console.log(JSON.stringify(ev).slice(0,300));await b.close();srv.close();process.exit(0);});
