#!/bin/bash
# nuevo.sh <nombre> : arranca un video nuevo con el esqueleto fijo. Escribí SOLO scene.js, overlay.js, PLANOS.txt y la lista de sonidos.
set -e; N=/home/user/what-if/$1; L=/home/user/what-if/_lib
mkdir -p $N/sim/js $N/sim/assets $N/sim/fonts $N/audio
cp $L/core.js $L/subs.js $L/util.js $L/particles.js $N/sim/js/
cp $L/fonts/* $N/sim/fonts/
[ -d $L/node_modules ] && cp -r $L/node_modules $N/sim/node_modules || (cd $N/sim && npm i three --silent)
echo "listo $N  ·  ahora: scene.js + overlay.js + PLANOS.txt  ·  probar con: bash $L/hoja.sh $N <duracion>  ·  kit: bash $L/buildkit.sh $N <duracion>"
