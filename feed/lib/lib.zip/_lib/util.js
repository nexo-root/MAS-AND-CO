export const clamp=(x,a=0,b=1)=>Math.min(b,Math.max(a,x));
export const lerp=(a,b,u)=>a+(b-a)*u;
export const sstep=(a,b,x)=>{const u=clamp((x-a)/(b-a));return u*u*(3-2*u);};
export const lin=(a,b,x)=>clamp((x-a)/(b-a));
export const E={
  inOut:u=>u<.5?4*u*u*u:1-Math.pow(-2*u+2,3)/2,
  out:u=>1-Math.pow(1-u,3), in:u=>u*u*u,
  out5:u=>1-Math.pow(1-u,5),
  expo:u=>u>=1?1:1-Math.pow(2,-10*u),
  back:u=>{const c1=1.9,c3=c1+1;return 1+c3*Math.pow(u-1,3)+c1*Math.pow(u-1,2);},
  elastic:u=>{if(u<=0)return 0;if(u>=1)return 1;return Math.pow(2,-10*u)*Math.sin((u*10-0.75)*(2*Math.PI)/3)+1;},
  sine:u=>-(Math.cos(Math.PI*u)-1)/2,
};
export function rng(seed){let s=seed>>>0;return()=>{s+=0x6D2B79F5;let t=s;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296;};}
export const hash=n=>{const x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x);};
export function noise1(x){const i=Math.floor(x),f=x-i;const u=f*f*(3-2*f);return lerp(hash(i),hash(i+1),u)*2-1;}
export function keys(t,K,ease){if(t<=K[0][0])return K[0][1];for(let i=1;i<K.length;i++){if(t<=K[i][0]){let u=(t-K[i-1][0])/(K[i][0]-K[i-1][0]);if(ease)u=ease(u);return lerp(K[i-1][1],K[i][1],u);}}return K[K.length-1][1];}
// pulse: 0 before a, rises to 1 at a+r, holds, falls at b over f
export const env=(t,a,b,r=0.15,f=0.15)=>Math.min(sstep(a,a+r,t),1-sstep(b-f,b,t));
