#!/bin/bash
# hoja.sh <videodir> <dur> [query] -> <videodir>/hoja.jpg : 8 cuadros en UNA imagen chica (1080x960, <512 KB). Mirar SOLO esto por vuelta.
# tarda ~2-3 min (8 cuadros por software): correrlo SIEMPRE en segundo plano y después mirar hoja.jpg
set -e; V=$1; DUR=$2; Q=${3:-}
T=$(python3 -c "d=$DUR;print(','.join(f'{d*i/7*0.995:.2f}' for i in range(8)))")
rm -rf $V/_hoja && node /home/user/what-if/_lib/render.cjs $V/sim $V/_hoja "$T" "$Q" >/dev/null
montage $(ls $V/_hoja/*.jpg | sort -V) -tile 4x2 -geometry 270x480+0+0 -background black -quality 72 $V/hoja.jpg
python3 - "$V/_hoja" <<'P'
import sys,glob
from PIL import Image,ImageStat
for f in sorted(glob.glob(sys.argv[1]+"/*.jpg"),key=lambda x:float(x.split("/t")[-1][:-4].replace("_","."))):
    m=sum(ImageStat.Stat(Image.open(f).convert('L').resize((54,96))).mean)
    print(f.split('/')[-1], 'NEGRO?' if m<8 else 'ok', round(m))
P
ls -la $V/hoja.jpg | awk '{print "hoja.jpg", $5, "bytes"}'
