// subtitles strictly from palabras.json: chunks of 1-3 words
const SMALL=new Set(['de','la','el','y','a','en','se','si','lo','te','tu','una','un','los','las','del','al','que','más','ya','no']);
export function clean(p){return p.replace(/[.,:;]+$/,'');}
export function chunk(words,maxW=3){const out=[];let cur=[];
  for(let i=0;i<words.length;i++){const w=words[i];cur.push(i);
    const punct=/[.,:;?!]$/.test(w.p);const next=words[i+1];const gap=next?next.ini-w.fin:9;
    const lowNext=next&&SMALL.has(clean(next.p).toLowerCase());
    let brk=punct||gap>0.32||cur.length>=maxW;
    if(!brk&&cur.length===2&&next&&!lowNext&&SMALL.has(clean(words[cur[0]].p).toLowerCase())===false)brk=false;
    if(brk){out.push(cur);cur=[];}}
  if(cur.length)out.push(cur);
  return out.map((ids,k)=>{const a=words[ids[0]].ini,last=words[ids[ids.length-1]].fin;const nx=out[k+1]?words[out[k+1][0]].ini:last+0.6;
    return {ids,words:ids.map(i=>({...words[i],txt:clean(words[i].p)})),t0:a-0.04,t1:Math.min(nx-0.01,last+0.55)};});}
export function activeChunk(chs,t){for(const c of chs){if(t>=c.t0&&t<c.t1)return c;}return null;}
