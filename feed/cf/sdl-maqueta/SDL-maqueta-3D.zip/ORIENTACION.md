# Cómo calzan las fotos con loteo.json (deducción, 17/11/2026)

Marco del plano (`poligono_plano`): u = a lo largo de D→C (azimut 56°, **noreste**), v = desde D hacia A (azimut 326°, **noroeste**).
Mundo: x = este, y = norte. Mundo = D + rot(+33,94°)·(u, v), con D = (−113,46; −320,16).

## Foto 01 (cenital con el plano encima)

- La manzana con la **ochava** hacia el rombo es la **Mz 06** → está **abajo a la izquierda** de la foto.
- La opuesta en diagonal es la **Mz 01** → **arriba a la derecha**. Ahí se cruzan los dos caminos públicos: es la **esquina A** (ingreso).
- Las otras dos: **Mz 02 arriba a la izquierda** y **Mz 05 abajo a la derecha**.
  (Con 05 arriba a la izquierda la foto sería un espejo, y una foto de dron no puede estar espejada.)
- Es decir, la foto 01 es el plano **girado 90° en sentido horario**:

| En la foto 01 | Rumbo real | En el plano |
|---|---|---|
| arriba | **suroeste** (236°) | hacia u negativo (lado A‑D) |
| derecha | **noroeste** (326°) | v positivo (lado A‑B) |
| abajo | **noreste** (56°) | u positivo (hacia B‑C) |
| izquierda | **sureste** (146°) | v negativo (hacia D‑C) |

  La suposición de FOTOS.md («norte arriba») no se cumple: la foto 01 tiene el **suroeste arriba**.
- El dibujo de los lotes lo confirma: en la foto, cada manzana tiene filas de lotes apilados a izquierda y derecha y dos fajas largas en el medio; en el plano esas fajas (lotes 8‑9 y 17‑18) son horizontales. Girando 90° quedan verticales.
- Calles abiertas hoy (todas coinciden con ESTRUCTURA §7):
  - anillo: camino público SO (lado A‑D) desde A hasta la longitudinal 2; longitudinal 2 hasta la ochava de la Mz 06; la ochava; transversal 2 hasta el camino público NO;
  - cruz: longitudinal 1 y transversal 1;
  - **camino público NO** (lado A‑B), largo y recto: sigue más allá del loteo hacia el noreste y un poco más allá de A hacia el suroeste.
- El rombo del mirador (isla B3) queda **afuera del anillo**: la rotonda todavía no está abierta, solo el claro de la isla.

## Bosques (fotos 01, 02, 03, 09, 10)

| Lado | Qué hay | Por qué |
|---|---|---|
| **Noroeste**, del otro lado del camino público NO | **Pinar en hileras** (copas cónicas parejas, verde azulado, 18‑25 m) | Foto 01: franja oscura rayada a la derecha. Foto 03: pinar a la derecha y al fondo. Foto 09: el camino recto separa pinar y loteo |
| **Suroeste**, del otro lado del camino público SO | **Monte nativo** con árboles blancos secos y lapachos rosados | Foto 01: arriba, con manchas rosadas. Foto 03: a la izquierda |
| Noreste (resto del predio, Mz 09‑20) y sureste (B2) | Monte nativo cerrado | Fotos 01 (abajo) y 02 |
| Alrededor de la rotonda / Mz 07, 11, 03 | Pastizal alto y arbustal bajo, árboles sueltos | Foto 01 abajo a la izquierda (más claro); foto 03 adelante |

- Dentro de la primera etapa: la **Mz 05** conserva bastante monte (foto 01 abajo a la derecha, foto 02 arriba a la derecha); la Mz 02 tiene una mitad con arbustal cerrado; la 01 y la 06 son pastizal con tierra pelada y árboles sueltos.

## Foto 03 (diagonal)

- La ochava con el mirador debajo está **abajo al centro** → la cámara está al **estesureste** de la primera etapa, sobre la zona de la rotonda / Mz 11, a ~170‑200 m de altura, mirando al **oestenoroeste**, hacia la esquina A (que queda arriba al centro, donde está el vehículo rojo).
- Desde A, el camino que sale a la derecha y corre pegado al pinar es el **camino público NO**; el que sale a la izquierda es el **camino público SO**. Bloque de la izquierda = Mz 02, de la derecha = Mz 05 (con monte), cercano = Mz 06.

## Sol

- En la foto 01 las sombras de los árboles caen **hacia arriba de la foto** (= suroeste); el monte de abajo proyecta sombra sobre la calle de su lado de arriba. En la foto 03 las sombras caen hacia la cámara y a la izquierda.
- Conclusión: en las fotos el sol viene del **noreste, bajo** (mañana de invierno). El pedido dice «media tarde»; se dejó el sol **bajo del noreste** (azimut 40°, altura 24°) para que las sombras caigan igual que en las fotos. Se cambia en `config.json → sol`.

## Ingreso

- Cartel en la **esquina A**, en el ángulo entre el camino público NO (que sigue de largo) y el camino SO que entra al loteo (frames de `watch-09`: el cartel está en el rincón de una T).
