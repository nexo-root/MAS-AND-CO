// cams.js: tomas de cámara desde config.json.
// Cada toma: {desde, hasta, posicion:[ini, fin], objetivo:[ini, fin], ease:"continuo"|"suave", fov?}
// posicion/objetivo = [x, y, altura] en metros. marco "mundo" (x este, y norte) o "plano" (u a lo largo de D->C, v hacia A).
// Tomas encadenadas (misma posición donde termina una y empieza la otra) se recorren sin frenar (spline de Catmull-Rom en el tiempo).
// "suave" frena y arranca en esa toma. "mirada": "suave" frena solo el giro de la mirada (el objetivo) en los extremos. Si una toma empieza en otro lugar, hay corte.
import { toWorld } from './geo.js';
import { VERT } from './core.js';
export function makeCams(spec) {
  const marco = spec.marco || 'mundo';
  const P = a => { if (marco === 'plano') { const [x, y] = toWorld(a[0], a[1]); return [x, a[2], -y]; } return [a[0], a[2], -a[1]]; };
  const T = [...spec.tomas].sort((a, b) => a.desde - b.desde);
  for (const t of T) if (t.hasta - t.desde < 1.5) console.warn('toma de menos de 1,5 s', t);
  // cadena de claves
  const K = [];
  T.forEach((t, i) => {
    const p0 = P(t.posicion[0]), p1 = P(t.posicion[1]), o0 = P(t.objetivo[0]), o1 = P(t.objetivo[1]);
    const fov0 = t.fov ? (Array.isArray(t.fov) ? t.fov[0] : t.fov) : null, fov1 = t.fov ? (Array.isArray(t.fov) ? t.fov[1] : t.fov) : null;
    const last = K[K.length - 1];
    const same = last && Math.abs(last.t - t.desde) < 1e-3 && dist(last.p, p0) < 0.01 && dist(last.o, o0) < 0.01;
    const ms = t.mirada === 'suave'; // "mirada": "suave" -> solo el objetivo frena en los extremos de la toma (la cámara sigue)
    if (!same) K.push({ t: t.desde, p: p0, o: o0, fov: fov0, corte: !!last, suave: t.ease === 'suave', ms });
    else { last.suave = last.suave || t.ease === 'suave'; last.ms = last.ms || ms; }
    K.push({ t: t.hasta, p: p1, o: o1, fov: fov1, suave: t.ease === 'suave', ms });
  });
  // tangentes
  for (let i = 0; i < K.length; i++) {
    const a = K[i - 1], b = K[i + 1], k = K[i];
    const borde = !a || !b || k.corte || (b && b.corte) || k.suave;
    k.mp = borde ? [0, 0, 0] : k.p.map((_, j) => (b.p[j] - a.p[j]) / (b.t - a.t));
    k.mo = (borde || k.ms) ? [0, 0, 0] : k.o.map((_, j) => (b.o[j] - a.o[j]) / (b.t - a.t));
  }
  const herm = (a, b, ma, mb, s, dt) => { const s2 = s * s, s3 = s2 * s; return a.map((_, j) => (2 * s3 - 3 * s2 + 1) * a[j] + (s3 - 2 * s2 + s) * dt * ma[j] + (-2 * s3 + 3 * s2) * b[j] + (s3 - s2) * dt * mb[j]); };
  const fovBase = VERT ? (spec.fov_vertical || 70) : (spec.fov || 45);
  const fv = VERT ? (spec.factor_vertical || 1.35) : 1;
  function at(t) {
    let i = 0; while (i < K.length - 2 && t > K[i + 1].t) i++;
    const a = K[i], b = K[Math.min(i + 1, K.length - 1)];
    if (b.corte && t < b.t) { /* tramo vacío entre tomas: quieto */ }
    const dt = Math.max(1e-6, b.t - a.t), s = Math.max(0, Math.min(1, (t - a.t) / dt));
    let p = herm(a.p, b.p, a.mp, b.mp, s, dt), o = herm(a.o, b.o, a.mo, b.mo, s, dt);
    if (b.corte && t < b.t) { p = a.p; o = a.o; }
    if (fv !== 1) p = p.map((x, j) => o[j] + (x - o[j]) * fv);
    const fa = a.fov ?? fovBase, fb = b.fov ?? fovBase; let fov = fa + (fb - fa) * (s * s * (3 - 2 * s));
    if (VERT && (a.fov || b.fov)) fov = fov * (spec.fov_vertical || 70) / (spec.fov || 45);
    return { p, o, fov };
  }
  return { at, dur: K[K.length - 1].t, K };
}
const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);
