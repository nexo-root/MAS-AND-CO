// geo.js: marcos de coordenadas, calles abiertas según el estado y utilidades de polilíneas.
// Marco del PLANO (u,v): u a lo largo de D->C (azimut 56°), v desde D hacia A (azimut 326°). Origen en el vértice D.
// Marco del MUNDO (x,y): x este, y norte. Three.js: X = x, Y = altura, Z = -y.
export const ROT = 33.9429 * Math.PI / 180, CR = Math.cos(ROT), SR = Math.sin(ROT);
export const D = [-113.46, -320.16];
export const toWorld = (u, v) => [D[0] + CR * u - SR * v, D[1] + SR * u + CR * v];
export const toPlan = (x, y) => { const a = x - D[0], b = y - D[1]; return [CR * a + SR * b, -SR * a + CR * b]; };

// ejes de calles (centro) en el marco del plano
export const C = {
  NO: 407.0,      // camino público noroeste (franja 399,89-424,89): calzada a ~7 m del frente de los lotes
  SO: -7.0,       // camino público suroeste (franja -25..0)
  L1: 292.415, L2: 172.18, L3: 87.205,
  T1: 107.47, T2: 227.94, T3: 322.915, T4: 417.89,
  MSE: 3.745, MNE: 496.12,
  ROT: [227.94, 172.18],
};
export const ANCHO = { publica: 6.6, interna: 5.6, anillo: 6.0 };

// Calles abiertas. El camino público NO se dibuja analítico en el shader (sigue kilómetros).
export function calles(estado) {
  const R = [];
  if (estado === 'hoy') {
    // anillo de la primera etapa (Mz 1, 2, 5, 6) con la ochava de la Mz 06
    R.push({ pts: [[C.SO, C.NO], [C.SO, C.L2], [193.55, C.L2], [C.T2, 206.57], [C.T2, C.NO]], w: ANCHO.anillo, r: [0, 14, 9, 9, 0] });
    R.push({ pts: [[C.SO, C.L1], [C.T2, C.L1]], w: ANCHO.interna });
    R.push({ pts: [[C.T1, C.L2], [C.T1, C.NO]], w: ANCHO.interna });
  } else {
    R.push({ pts: [[C.SO, -100], [C.SO, C.NO]], w: ANCHO.publica });
    for (const v of [C.L1, C.L2, C.L3]) R.push({ pts: [[C.SO, v], [C.MNE, v]], w: ANCHO.interna, rot: v === C.L2 });
    for (const u of [C.T1, C.T2, C.T3, C.T4]) R.push({ pts: [[u, C.MSE], [u, C.NO]], w: ANCHO.interna, rot: u === C.T2 });
    R.push({ pts: [[C.SO, C.MSE], [C.MNE, C.MSE], [C.MNE, C.NO]], w: 5.0, r: [0, 12, 0] });
  }
  return R;
}

// redondea las esquinas de una polilínea (r[i] = radio en el vértice i) y la densifica cada ~1 m
export function fillet(pts, r = []) {
  const out = [pts[0]];
  for (let i = 1; i < pts.length - 1; i++) {
    const R = r[i] || 0, p = pts[i], a = pts[i - 1], b = pts[i + 1];
    if (!R) { out.push(p); continue; }
    const d1 = norm([p[0] - a[0], p[1] - a[1]]), d2 = norm([b[0] - p[0], b[1] - p[1]]);
    const cosT = d1[0] * d2[0] + d1[1] * d2[1], th = Math.acos(Math.max(-1, Math.min(1, cosT)));
    const t = R * Math.tan(th / 2);
    const s = [p[0] - d1[0] * t, p[1] - d1[1] * t], e = [p[0] + d2[0] * t, p[1] + d2[1] * t];
    const n = 10; // bezier cuadrática aproxima el arco
    for (let k = 0; k <= n; k++) { const q = k / n, m = 1 - q; out.push([m * m * s[0] + 2 * m * q * p[0] + q * q * e[0], m * m * s[1] + 2 * m * q * p[1] + q * q * e[1]]); }
  }
  out.push(pts[pts.length - 1]);
  return densify(out, 1.0);
}
export function norm(d) { const l = Math.hypot(d[0], d[1]) || 1; return [d[0] / l, d[1] / l]; }
export function densify(pts, step) {
  const o = [pts[0]];
  for (let i = 1; i < pts.length; i++) {
    const a = pts[i - 1], b = pts[i], L = Math.hypot(b[0] - a[0], b[1] - a[1]), n = Math.max(1, Math.ceil(L / step));
    for (let k = 1; k <= n; k++) o.push([a[0] + (b[0] - a[0]) * k / n, a[1] + (b[1] - a[1]) * k / n]);
  }
  return o;
}
// polilínea desplazada a un costado (o > 0 = izquierda del sentido de avance)
export function offset(pts, o) {
  return pts.map((p, i) => {
    const a = pts[Math.max(0, i - 1)], b = pts[Math.min(pts.length - 1, i + 1)];
    const d = norm([b[0] - a[0], b[1] - a[1]]); return [p[0] - d[1] * o, p[1] + d[0] * o];
  });
}
export function centroid(poly) { let x = 0, y = 0; for (const p of poly) { x += p[0]; y += p[1]; } return [x / poly.length, y / poly.length]; }
export function inPoly(p, poly) {
  let c = false; for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i], b = poly[j];
    if (((a[1] > p[1]) !== (b[1] > p[1])) && (p[0] < (b[0] - a[0]) * (p[1] - a[1]) / (b[1] - a[1]) + a[0])) c = !c;
  } return c;
}
