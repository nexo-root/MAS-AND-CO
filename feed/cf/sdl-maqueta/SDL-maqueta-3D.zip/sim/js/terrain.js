// terrain.js: relieve, máscara de calles/desmonte (canvas en el marco del plano) y material del suelo.
import * as THREE from 'three';
import { fbm2, vn2, NOISE } from './glsl.js';
import { toPlan, toWorld, calles, fillet, offset, C, ANCHO, centroid } from './geo.js';
import { rng, sstep } from './k.js';

// ---------- relieve (mundo x,y en metros) ----------
export const CENTRO = toWorld(250, 210);           // centro del predio
const MIR = toWorld(C.ROT[0], C.ROT[1]);          // isla B3 = mirador
export function alturaBase(x, y) {
  const r = Math.hypot(x - CENTRO[0], y - CENTRO[1]);
  let h = 2.6 * (fbm2(x / 430 + 3.1, y / 430 + 7.7, 4) - 0.5) * 2 + 0.6 * (fbm2(x / 70 + 1.3, y / 70 + 2.9, 3) - 0.5);
  h += 36 * sstep(500, 4200, r) * (fbm2(x / 1600 + 11, y / 1600 + 5, 4) - 0.42) * 2;
  h += 1.5 * Math.exp(-((Math.hypot(x - MIR[0], y - MIR[1]) / 60) ** 2));
  return h;
}
// zona donde se recorre la plantación (se conserva para que el sorteo de árboles sea idéntico al de v3).
export const ZONA = { u0: -450, u1: 950, v0: -350, v1: 1050 };
export const PINAR_V = 416;
// ---------- isla (v4, 20/11): el mundo termina a un margen del predio y se funde en la bruma ----------
// núcleo = predio (u 0-500, v 0-400) + camino público SO (25 m) + camino NO (25 m) + Lote B2 (100 m abajo)
export const ISLA = { u0: -25, u1: 500, v0: -100, v1: 425, margen: 110, fundido: 110, onda: 22, pinar_fondo: 100, extra: [] };
export function configurarIsla(cfg) {
  const m = cfg.mundo || {};
  for (const k of ['margen', 'fundido', 'onda', 'pinar_fondo']) if (m[k] != null) ISLA[k] = m[k];
  ISLA.extra = [...(m.extra || []), ...(cfg.isla_extra || [])]; // cajas [u0, v0, u1, v1] que se suman a la isla (p. ej. el camino al pueblo en «totems»)
}
const sdCaja = (u, v, u0, v0, u1, v1) => { const cu = (u0 + u1) / 2, cv = (v0 + v1) / 2, qx = Math.abs(u - cu) - (u1 - u0) / 2, qy = Math.abs(v - cv) - (v1 - v0) / 2; return Math.hypot(Math.max(qx, 0), Math.max(qy, 0)) + Math.min(Math.max(qx, qy), 0); };
export const ondaIsla = (u, v) => ISLA.onda * (Math.sin(u / 97 + 1.3) * Math.sin(v / 83 + 0.7) * 0.6 + Math.sin((u + v) / 51) * 0.4);
// distancia (m) al borde de la isla: negativa adentro. 0 = mitad del fundido.
export function bordeIsla(u, v) {
  let d = sdCaja(u, v, ISLA.u0, ISLA.v0, ISLA.u1, ISLA.v1) - ISLA.margen;
  for (const e of ISLA.extra) d = Math.min(d, sdCaja(u, v, e[0], e[1], e[2], e[3]) - ISLA.margen * 0.6);
  return d + ondaIsla(u, v);
}
// trozo GLSL equivalente (se inyecta en la niebla de TODOS los materiales: suelo, árboles, utilería)
export function glslIsla() {
  const f = n => Number(n).toFixed(3);
  let ex = ''; for (const e of ISLA.extra) ex += ` d=min(d,sdCaja(p,vec4(${f(e[0])},${f(e[1])},${f(e[2])},${f(e[3])}))-${f(ISLA.margen * 0.6)});`;
  return `
float sdCaja(vec2 p,vec4 b){vec2 c=(b.xy+b.zw)*.5,h=(b.zw-b.xy)*.5;vec2 q=abs(p-c)-h;return length(max(q,0.))+min(max(q.x,q.y),0.);}
float islaFundido(vec3 w){vec2 a=vec2(w.x,-w.z)-vec2(-113.46,-320.16);float cr=${f(Math.cos(33.9429 * Math.PI / 180))},sr=${f(Math.sin(33.9429 * Math.PI / 180))};
 vec2 p=vec2(cr*a.x+sr*a.y,-sr*a.x+cr*a.y);
 float d=sdCaja(p,vec4(${f(ISLA.u0)},${f(ISLA.v0)},${f(ISLA.u1)},${f(ISLA.v1)}))-${f(ISLA.margen)};${ex}
 d+=${f(ISLA.onda)}*(sin(p.x/97.+1.3)*sin(p.y/83.+.7)*.6+sin((p.x+p.y)/51.)*.4);
 return smoothstep(${f(-0.45 * ISLA.fundido)},${f(0.6 * ISLA.fundido)},d);}
`;
}
// árboles: se mantienen hasta poco antes del fundido y se ralean adentro de él
export function vivoIsla(u, v) {
  const e = bordeIsla(u, v), F = ISLA.fundido; if (e < -0.6 * F) return true; if (e > 0.15 * F) return false;
  const h = Math.abs(Math.sin(u * 12.9898 + v * 78.233) * 43758.5453) % 1;
  return h > 0.9 * sstep(-0.6 * F, 0.15 * F, e);
}
// y se achican hacia el borde (el monte baja en vez de cortar como una pared)
export function alturaIsla(u, v) { const F = ISLA.fundido; return 1 - 0.55 * sstep(-0.6 * F, 0.15 * F, bordeIsla(u, v)); }
export function cajaIsla() { // rectángulo (marco del plano) que cubre la isla completa con su fundido
  const pad = ISLA.margen + ISLA.fundido + ISLA.onda + 10; let b = [ISLA.u0 - pad, ISLA.v0 - pad, ISLA.u1 + pad, ISLA.v1 + pad];
  for (const e of ISLA.extra) { const p2 = ISLA.margen * 0.6 + ISLA.fundido + ISLA.onda + 10; b = [Math.min(b[0], e[0] - p2), Math.min(b[1], e[1] - p2), Math.max(b[2], e[2] + p2), Math.max(b[3], e[3] + p2)]; }
  return b;
}
export function altura(x, y) { return alturaBase(x, y); }

// ---------- máscara (canvas alineado al plano) ----------
// R calzada · G huellas · B tierra suelta · A desmonte (pastizal en vez de monte)
export const MK = { u0: -220, v1: 640, size: 880, N: 3328 }; // v4: solo la isla (antes 1100 m a 4096 px; misma resolución ≈ 0,26 m/px)
const res = MK.size / MK.N;
const px = (u, v) => [(u - MK.u0) / res, (MK.v1 - v) / res];

function lienzo() { const c = document.createElement('canvas'); c.width = c.height = MK.N; const g = c.getContext('2d'); g.fillStyle = '#000'; g.fillRect(0, 0, MK.N, MK.N); g.lineCap = 'round'; g.lineJoin = 'round'; return [c, g]; }
function trazo(g, pts, w, a = 1) { g.strokeStyle = `rgba(255,255,255,${a})`; g.lineWidth = w / res; g.beginPath(); pts.forEach((p, i) => { const [x, y] = px(p[0], p[1]); i ? g.lineTo(x, y) : g.moveTo(x, y); }); g.stroke(); }
function relleno(g, poly, a = 1, col = 255) { g.fillStyle = `rgba(${col},${col},${col},${a})`; g.beginPath(); poly.forEach((p, i) => { const [x, y] = px(p[0], p[1]); i ? g.lineTo(x, y) : g.moveTo(x, y); }); g.closePath(); g.fill(); }
function mancha(g, u, v, r, a = 1, col = 255) { const [x, y] = px(u, v); g.fillStyle = `rgba(${col},${col},${col},${a})`; g.beginPath(); g.arc(x, y, r / res, 0, Math.PI * 2); g.fill(); }
function canal(c, data, k) { const d = c.getContext('2d').getImageData(0, 0, MK.N, MK.N).data; for (let i = 0, j = k; i < d.length; i += 4, j += 4) data[j] = d[i]; }

export function construirMascara(L, estado) {
  const data = new Uint8Array(MK.N * MK.N * 4);
  const R = calles(estado).map(c => ({ ...c, d: fillet(c.pts, c.r) }));
  const rnd = rng(77);
  const mz = n => L.manzanas.find(m => m.numero === n).poligono_plano;
  const isla = L.rotonda.isla_lote_B3.poligono_plano;
  const etapa1 = [1, 2, 5, 6];
  const lotesDe = (n) => L.lotes.filter(l => l.manzana === n);
  // --- R: calzada
  let [c, g] = lienzo();
  for (const r of R) { trazo(g, r.d, r.w); }
  if (estado === 'proyecto') { // anillo de la rotonda alrededor de la isla
    const [x, y] = px(C.ROT[0], C.ROT[1]); g.strokeStyle = '#fff'; g.lineWidth = 6.2 / res; g.beginPath(); g.arc(x, y, 30.5 / res, 0, Math.PI * 2); g.stroke();
  }
  relleno(g, isla, 1, 0); // la isla nunca es calzada
  if (estado === 'proyecto') { const [x, y] = px(C.ROT[0], C.ROT[1]); g.fillStyle = '#000'; g.beginPath(); g.arc(x, y, 26.6 / res, 0, Math.PI * 2); g.fill(); }
  g.filter = 'blur(1px)'; g.drawImage(c, 0, 0); g.filter = 'none';
  canal(c, data, 0);
  // --- G: huellas de ruedas
  [c, g] = lienzo();
  for (const r of R) for (const o of [-1.0, 1.0]) trazo(g, offset(r.d, o), 0.5, 0.75);
  if (estado === 'proyecto') { const [x, y] = px(C.ROT[0], C.ROT[1]); g.strokeStyle = 'rgba(255,255,255,.7)'; g.lineWidth = 0.5 / res; for (const rr of [29.5, 31.5]) { g.beginPath(); g.arc(x, y, rr / res, 0, Math.PI * 2); g.stroke(); } }
  canal(c, data, 1);
  // --- B: tierra suelta (cordones empujados por la motoniveladora, manchas peladas, mirador)
  [c, g] = lienzo();
  for (const r of R) for (const o of [-1, 1]) trazo(g, offset(r.d, o * (r.w / 2 + 1.1)), 1.7, 0.85);
  const lotesTierra = estado === 'hoy' ? etapa1 : [1, 2, 5, 6, 3, 7, 9, 10];
  for (const n of lotesTierra) {
    const P = mz(n); let bb = bbox(P);
    for (let k = 0; k < (estado === 'hoy' ? 9 : 5); k++) {
      const u = bb[0] + rnd() * (bb[2] - bb[0]), v = bb[1] + rnd() * (bb[3] - bb[1]);
      const rr = 2 + rnd() * 6, aa = 0.3 + rnd() * 0.45;
      for (let j = 0; j < 7; j++) mancha(g, u + (rnd() - .5) * rr * 1.6, v + (rnd() - .5) * rr * 1.6, rr * (0.3 + rnd() * 0.5), aa);
    }
  }
  if (estado === 'hoy') { // lotes pelados de la Mz 01 junto al ingreso (foto 01: anaranjado)
    for (const l of lotesDe(1).filter(l => [15, 16, 17, 18].includes(l.lote))) { const b = bbox(l.poligono_plano); for (let j = 0; j < 40; j++) mancha(g, b[0] + rnd() * (b[2] - b[0]), b[1] + rnd() * (b[3] - b[1]), 2 + rnd() * 4, 0.35); }
    for (const l of lotesDe(6).filter(l => [8, 9].includes(l.lote))) relleno(g, l.poligono_plano, 0.45);
  }
  relleno(g, isla, 0.18); for (let j = 0; j < 30; j++) mancha(g, C.ROT[0] + (rnd() - .5) * 24, C.ROT[1] + (rnd() - .5) * 24, 2 + rnd() * 3, 0.22);
  g.filter = 'blur(3px)'; g.drawImage(c, 0, 0); g.filter = 'none';
  canal(c, data, 2);
  // --- A: desmonte
  [c, g] = lienzo();
  if (estado === 'hoy') {
    // pastizal y arbustal bajo alrededor de la rotonda (fotos 01 y 03)
    // contorno irregular: muchas manchas dentro de tres elipses, con islas de monte adentro
    g.filter = `blur(${Math.round(7 / res)}px)`;
    for (const [cu, cv, ru, rv, n] of [[215, 125, 110, 72, 70], [290, 120, 72, 58, 30], [95, 138, 72, 40, 22]]) for (let k = 0; k < n; k++) {
      const a = rnd() * 6.283, r = Math.sqrt(rnd()); mancha(g, cu + Math.cos(a) * ru * r, cv + Math.sin(a) * rv * r, 10 + rnd() * 22, 0.95);
    }
    for (let k = 0; k < 9; k++) mancha(g, 140 + rnd() * 220, 70 + rnd() * 110, 5 + rnd() * 9, 0.9, 0);
    g.filter = 'none';
    for (const n of etapa1) relleno(g, mz(n));
    // la Mz 05 conserva monte (foto 01 abajo a la derecha / foto 02 arriba a la derecha)
    g.filter = `blur(${Math.round(6 / res)}px)`;
    const b5 = bbox(mz(5));
    for (let k = 0; k < 46; k++) { const u = b5[0] + 6 + rnd() * (b5[2] - b5[0] - 12), v = b5[1] + 6 + rnd() * (b5[3] - b5[1] - 12); mancha(g, u, v, 9 + rnd() * 12, 0.9, 0); } // v3: Mz 05 ~2/3 monte cerrado
    g.filter = 'none';
  } else {
    for (const m of L.manzanas) relleno(g, m.poligono_plano);
    for (const e of L.lotes) if (e.tipo === 'espacio_verde') relleno(g, e.poligono_plano, 1, 0);
    const [x, y] = px(C.ROT[0], C.ROT[1]); g.fillStyle = '#fff'; g.beginPath(); g.arc(x, y, 38 / res, 0, Math.PI * 2); g.fill();
    relleno(g, [[-25, -100], [0, -100], [0, 400], [-25, 400]], 0.9);
    g.filter = `blur(${Math.round(18 / res)}px)`; elipse(g, 200, 118, 120, 70, 0.6); g.filter = 'none';
  }
  for (const r of R) trazo(g, r.d, r.w + 7.5);
  mancha(g, C.ROT[0], C.ROT[1], 20, 1);
  g.filter = 'blur(2px)'; g.drawImage(c, 0, 0); g.filter = 'none';
  canal(c, data, 3);
  c.width = c.height = 1;
  const tex = new THREE.DataTexture(data, MK.N, MK.N, THREE.RGBAFormat, THREE.UnsignedByteType);
  tex.generateMipmaps = true; tex.minFilter = THREE.LinearMipmapLinearFilter; tex.magFilter = THREE.LinearFilter; tex.anisotropy = 8; tex.needsUpdate = true;
  // lectura desde JS (para no plantar árboles en la calle)
  const leer = (u, v, k) => {
    const x = Math.floor((u - MK.u0) / res), y = Math.floor((MK.v1 - v) / res);
    let val = (x < 0 || y < 0 || x >= MK.N || y >= MK.N) ? 0 : data[(y * MK.N + x) * 4 + k] / 255;
    // camino público NO (analítico, igual que en el shader)
    const dn = Math.abs(v - C.NO);
    if (k === 0 && dn < 3.6 && u > -1100 && u < 2300) val = 1;
    if (k === 3 && v > 399.5 && v < 414 && u > -1100 && u < 2300) val = 1;
    if (k === 2 && dn > 3.3 && dn < 5.6 && u > -1100 && u < 2300) val = Math.max(val, 0.8);
    return val;
  };
  return { tex, leer, calles: R };
}
function elipse(g, u, v, ru, rv, a) { const [x, y] = px(u, v); g.fillStyle = `rgba(255,255,255,${a})`; g.beginPath(); g.ellipse(x, y, ru / res, rv / res, 0, 0, Math.PI * 2); g.fill(); }
export function bbox(P) { let a = [1e9, 1e9, -1e9, -1e9]; for (const p of P) { a[0] = Math.min(a[0], p[0]); a[1] = Math.min(a[1], p[1]); a[2] = Math.max(a[2], p[0]); a[3] = Math.max(a[3], p[1]); } return a; }

// ---------- líneas de lotes y resaltado (canvas aparte, más fino) ----------
export const LK = { u0: -6, v0: -6, w: 512, h: 432, W: 4096 };
LK.H = Math.round(LK.W * LK.h / LK.w); LK.res = LK.w / LK.W;
const lpx = (u, v) => [(u - LK.u0) / LK.res, (LK.v0 + LK.h - v) / LK.res];
function lienzoL() { const c = document.createElement('canvas'); c.width = LK.W; c.height = LK.H; const g = c.getContext('2d'); g.fillStyle = '#000'; g.fillRect(0, 0, LK.W, LK.H); g.lineJoin = 'round'; return [c, g]; }
function polyL(g, P) { g.beginPath(); P.forEach((p, i) => { const [x, y] = lpx(p[0], p[1]); i ? g.lineTo(x, y) : g.moveTo(x, y); }); g.closePath(); }
export function construirLineas(L) {
  const [c, g] = lienzoL();
  g.strokeStyle = 'rgb(255,0,0)'; g.lineWidth = 0.32 / LK.res;
  for (const l of L.lotes) { polyL(g, l.poligono_plano); g.stroke(); }
  g.strokeStyle = 'rgb(0,255,0)'; g.lineWidth = 0.55 / LK.res;
  for (const m of L.manzanas) { polyL(g, m.poligono_plano); g.stroke(); }
  polyL(g, L.rotonda.isla_lote_B3.poligono_plano); g.stroke();
  const t = new THREE.CanvasTexture(c); t.anisotropy = 8; t.colorSpace = THREE.NoColorSpace; return t;
}
// resaltar: [{mz, lotes:[..], color, rotulo}]
export function construirResaltado(L, resaltar) {
  const [c, g] = lienzoL();
  const grupos = [];
  for (const R of resaltar || []) {
    const col = new THREE.Color(R.color || '#3CCFFF'); const rgb = `${Math.round(col.r * 255)},${Math.round(col.g * 255)},${Math.round(col.b * 255)}`;
    const lotes = L.lotes.filter(l => l.manzana === R.mz && (l.tipo === 'lote' || (R.lotes || []).includes(l.lote)) && (!R.lotes || !R.lotes.length || R.lotes.includes(l.lote)));
    if (!lotes.length) { console.warn('resaltar: no existe', R); continue; }
    for (const l of lotes) { g.fillStyle = `rgba(${rgb},0.34)`; polyL(g, l.poligono_plano); g.fill(); }
    for (const l of lotes) { g.strokeStyle = `rgb(${rgb})`; g.lineWidth = 0.6 / LK.res; polyL(g, l.poligono_plano); g.stroke(); }
    // número del lote, derecho en el marco del plano
    for (const l of lotes) {
      const bb = bbox(l.poligono_plano); const cu = (bb[0] + bb[2]) / 2, cv = (bb[1] + bb[3]) / 2;
      const s = Math.min(bb[2] - bb[0], bb[3] - bb[1]) * 0.55; const [x, y] = lpx(cu, cv);
      g.font = `700 ${Math.round(s / LK.res)}px Mont`; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillStyle = 'rgba(255,255,255,0.95)'; g.fillText(String(l.lote), x, y);
    }
    const pts = lotes.flatMap(l => l.poligono_plano);
    grupos.push({ ...R, color: R.color || '#3CCFFF', centro: centroid(lotes.map(l => centroid(l.poligono_plano))), bbox: bbox(pts), lotesPlan: lotes.map(l => l.poligono_plano) });
  }
  const t = new THREE.CanvasTexture(c); t.anisotropy = 8; t.colorSpace = THREE.NoColorSpace; return { tex: t, grupos };
}

// ---------- mallas del suelo ----------
export function mallaSuelo() {
  // v4: solo la isla (marco del plano, cada ~2,5 m). Afuera, un plano chato del color de la bruma (scene.js).
  const [u0, v0, u1, v1] = cajaIsla(); const P = 2.5;
  const nu = Math.ceil((u1 - u0) / P), nv = Math.ceil((v1 - v0) / P);
  const pos = new Float32Array((nu + 1) * (nv + 1) * 3), idx = [];
  let i = 0;
  for (let j = 0; j <= nv; j++) for (let k = 0; k <= nu; k++) { const u = u0 + k * (u1 - u0) / nu, v = v0 + j * (v1 - v0) / nv; const [x, y] = toWorld(u, v); pos[i++] = x; pos[i++] = alturaBase(x, y); pos[i++] = -y; }
  for (let j = 0; j < nv; j++) for (let k = 0; k < nu; k++) { const a = j * (nu + 1) + k, b = a + nu + 1; idx.push(a, b, a + 1, a + 1, b, b + 1); }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setIndex(idx); g.computeVertexNormals();
  if (g.attributes.normal.getY(0) < 0) { g.index.array.reverse(); g.computeVertexNormals(); }
  return g;
}

export function materialSuelo({ mask, lineas, resaltado, texturas }) {
  const L = c => new THREE.Color(c);
  const U = {
    uMask: { value: mask }, uMK: { value: new THREE.Vector4(MK.u0, MK.v1, MK.size, 0) },
    uLin: { value: lineas }, uHl: { value: resaltado }, uLK: { value: new THREE.Vector4(LK.u0, LK.v0, LK.w, LK.h) },
    uLinA: { value: 0 }, uHL: { value: 0 },
    uRot: { value: new THREE.Vector4(Math.cos(33.9429 * Math.PI / 180), Math.sin(33.9429 * Math.PI / 180), -113.46, -320.16) },
    uSoil: { value: texturas.soil }, uSoilN: { value: texturas.soilN }, uGrass: { value: texturas.grass },
    cCalz: { value: L('#84553c') }, cSuelta: { value: L('#5e4232') }, cP1: { value: L('#776b55') }, cP2: { value: L('#55603a') }, cP3: { value: L('#3c4327') }, cP4: { value: L('#5e4a40') }, cZ1: { value: L('#75705c') }, cZ2: { value: L('#566042') },
    cMonte: { value: L('#2a3020') }, cCopa1: { value: L('#2c3a1c') }, cCopa2: { value: L('#56622f') }, cPino: { value: L('#3d4c43') }, cCampo1: { value: L('#8c9160') }, cCampo2: { value: L('#6c7a42') },
  };
  const m = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.96, metalness: 0 });
  m.onBeforeCompile = sh => {
    Object.assign(sh.uniforms, U);
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWP;')
      .replace('#include <project_vertex>', '#include <project_vertex>\nvWP=(modelMatrix*vec4(transformed,1.)).xyz;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>
varying vec3 vWP;
uniform sampler2D uMask,uLin,uHl,uSoil,uSoilN,uGrass;uniform vec4 uMK,uLK,uRot;uniform float uLinA,uHL;
uniform vec3 cCalz,cSuelta,cP1,cP2,cP3,cP4,cZ1,cZ2,cMonte,cCopa1,cCopa2,cPino,cCampo1,cCampo2;
${NOISE}
vec2 toPlan(vec2 w){vec2 a=w-uRot.zw;return vec2(uRot.x*a.x+uRot.y*a.y,-uRot.y*a.x+uRot.x*a.y);}
vec3 planDir(vec2 d){return vec3(uRot.x*d.x-uRot.y*d.y,0.,-(uRot.y*d.x+uRot.x*d.y));}
vec2 hash22(vec2 p){p=vec2(dot(p,vec2(127.1,311.7)),dot(p,vec2(269.5,183.3)));return fract(sin(p)*43758.5453);}
// celdas (copas): devuelve distancia al centro más cercano y el vector hacia él
vec4 celdas(vec2 p,float jit){vec2 i=floor(p),f=fract(p);float best=9.;vec2 bv=vec2(0);float id=0.;
 for(int y=-1;y<=1;y++)for(int x=-1;x<=1;x++){vec2 g=vec2(x,y);vec2 o=hash22(i+g);vec2 r=g+.5+(o-.5)*jit-f;float d=dot(r,r);if(d<best){best=d;bv=r;id=o.x;}}
 return vec4(sqrt(best),bv,id);}
`).replace('#include <color_fragment>', `#include <color_fragment>
 vec2 pl=toPlan(vec2(vWP.x,-vWP.z));
 vec2 muv=vec2((pl.x-uMK.x)/uMK.z,(uMK.y-pl.y)/uMK.z);
 vec4 mk=(muv.x>0.&&muv.y>0.&&muv.x<1.&&muv.y<1.)?texture2D(uMask,muv):vec4(0.);
 float inNO=step(-1100.,pl.x)*step(pl.x,2300.)*(1.-smoothstep(2200.,2300.,pl.x));
 float dNO=abs(pl.y-407.0);
 float eN=(vn2(pl*0.6)-.5)*0.7;
 mk.r=max(mk.r,inNO*(1.-smoothstep(3.0,3.5,dNO+eN*.6)));
 mk.g=max(mk.g,inNO*(1.-smoothstep(0.15,0.32,abs(dNO-1.0)))*.75);
 mk.b=max(mk.b,inNO*smoothstep(3.2,3.7,dNO)*(1.-smoothstep(4.9,5.8,dNO+eN))*.85);
 mk.a=max(mk.a,inNO*step(399.5,pl.y)*(1.-smoothstep(412.,415.,pl.y)));
 float n1=fbm2(pl*0.33),n2=fbm2(pl*0.075+3.7),n3=fbm2(pl*0.017+9.1),n4=vn2(pl*1.7);
 // pastizal en matas, paja y verde
 float gl=dot(texture2D(uGrass,pl/9.).rgb,vec3(.3,.59,.11));
 vec3 past=mix(cP1,cP2,smoothstep(.32,.68,n2+(n1-.5)*.55+(n3-.5)*.5));
 past=mix(past,cP3,smoothstep(.56,.78,n1+(n4-.5)*.25)*.75);
 past=mix(past,cP4,smoothstep(.55,.8,fbm2(pl*0.045+11.))*.7); // pasto quemado/seco gris
 float e1=step(-2.,pl.x)*step(pl.x,237.)*step(163.,pl.y)*step(pl.y,402.);
 vec3 alto=mix(cZ1,cZ2,smoothstep(.3,.7,n2+(n1-.5)*.8));alto=mix(alto,cP3,smoothstep(.6,.8,n1)*.5);
 past=mix(alto,past,e1);
 past*=0.8+0.6*gl;
 vec3 sueloMonte=cMonte*(0.8+0.4*n1);
 float wp=smoothstep(.3,.7,mk.a+(n2-.5)*.45);
 vec3 col=mix(sueloMonte,past,wp);
 // tierra suelta y calzada
 vec3 st=texture2D(uSoil,pl/2.2).rgb;float sl=dot(st,vec3(.3,.59,.11));
 vec3 suelta=cSuelta*(0.55+1.5*sl)*(0.85+0.3*n1);
 float wb=smoothstep(.3,.62,mk.b+(n1-.5)*.7+(n4-.5)*.3);
 col=mix(col,suelta,wb);
 vec3 st2=texture2D(uSoil,pl/3.1+.37).rgb;float sl2=dot(st2,vec3(.3,.59,.11));
 vec3 calz=cCalz*(0.7+1.0*sl2)*(0.9+0.2*n2);
 calz*=1.-mk.g*.22;
 float wr=smoothstep(.35,.62,mk.r+(n4-.5)*.18);
 col=mix(col,calz,wr);
 // líneas de lotes (proyecto) y resaltado
 vec2 luv=vec2((pl.x-uLK.x)/uLK.z,(pl.y-uLK.y)/uLK.w);
 vec3 hlE=vec3(0.);
 if(luv.x>0.&&luv.y>0.&&luv.x<1.&&luv.y<1.){
   vec4 li=texture2D(uLin,luv);float la=clamp(li.r*.8+li.g,0.,1.)*uLinA;col=mix(col,vec3(.82,.8,.74),la);hlE+=vec3(.05)*la;
   vec3 hl=texture2D(uHl,luv).rgb;float ha=max(hl.r,max(hl.g,hl.b));
   col=mix(col,col*.55+hl*.5,smoothstep(.02,.35,ha)*uHL);hlE+=hl*uHL*.32;
 }
 diffuseColor.rgb=col;
`).replace('#include <normal_fragment_maps>', `#include <normal_fragment_maps>
 {vec3 nm=texture2D(uSoilN,pl/3.1+.37).xyz*2.-1.;
  vec3 dW=planDir(nm.xy)*0.55*wr;
  dW+=planDir(vec2(vn2(pl*2.1)-.5,vn2(pl*2.1+5.)-.5))*0.35*(1.-wr);
  normal=normalize(normal+(viewMatrix*vec4(dW,0.)).xyz);}
`).replace('#include <emissivemap_fragment>', '#include <emissivemap_fragment>\n totalEmissiveRadiance+=hlE;');
  };
  m.customProgramCacheKey = () => 'suelo-v4';
  m.userData.u = U;
  return m;
}
