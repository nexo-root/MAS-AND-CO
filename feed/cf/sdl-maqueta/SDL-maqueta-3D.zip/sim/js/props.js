// props.js: utilería real. Cartel de venta en el ingreso (marco de madera + poste) y auto blanco para escala.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { toWorld } from './geo.js';
import { altura } from './terrain.js';
const box = (w, h, d, x, y, z) => { const g = new THREE.BoxGeometry(w, h, d); g.translate(x, y, z); return g; };
function ubicar(obj, u, v, rumboPlano) { // rumboPlano: ángulo en el plano hacia donde mira el frente (rad, 0 = +u)
  const [x, y] = toWorld(u, v); obj.position.set(x, altura(x, y) - 0.05, -y);
  const a = rumboPlano + 33.9429 * Math.PI / 180; // a mundo
  obj.rotation.y = a + Math.PI / 2; // el frente del objeto es +Z local
  return obj;
}
function texCartel() {
  const c = document.createElement('canvas'); c.width = 512; c.height = 680; const g = c.getContext('2d');
  g.fillStyle = '#f2f0ea'; g.fillRect(0, 0, 512, 680);
  g.fillStyle = '#2b3a2e'; g.fillRect(0, 0, 512, 70);
  g.fillStyle = '#fff'; g.font = '700 30px Mont'; g.textAlign = 'center'; g.fillText('SOLARES DE LORETO', 256, 46);
  g.strokeStyle = '#7d8a80'; g.lineWidth = 2; // planito de manzanas
  for (let i = 0; i < 4; i++) for (let j = 0; j < 5; j++) { g.strokeRect(46 + j * 86, 110 + i * 105, 72, 88); for (let k = 1; k < 4; k++) { g.beginPath(); g.moveTo(46 + j * 86, 110 + i * 105 + k * 22); g.lineTo(118 + j * 86, 110 + i * 105 + k * 22); g.stroke(); } }
  g.fillStyle = '#5fae6a'; g.fillRect(46, 545, 90, 40);
  g.fillStyle = '#2b3a2e'; g.font = '600 26px Mont'; g.fillText('LOTES EN VENTA', 300, 575);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t;
}
export function utileria(cfg) {
  const G = new THREE.Group();
  const madera = new THREE.MeshStandardMaterial({ color: '#6e5a45', roughness: 0.9 });
  // cartel en la esquina A, en el ángulo entre los dos caminos públicos, mirando al cruce
  const cartel = new THREE.Group();
  const marco = mergeGeometries([
    box(0.14, 2.9, 0.14, -0.95, 1.45, 0), box(0.14, 2.9, 0.14, 0.95, 1.45, 0),
    box(2.1, 0.12, 0.1, 0, 2.75, 0.04), box(2.1, 0.12, 0.1, 0, 0.62, 0.04),
    ...[0, 1, 2, 3, 4, 5].map(k => box(0.18, 0.08, 0.06, -1.13 - 0.0, 0.8 + k * 0.35, 0.05)),
    ...[0, 1, 2, 3, 4, 5].map(k => box(0.18, 0.08, 0.06, 1.13, 0.8 + k * 0.35, 0.05)),
  ]);
  const mm = new THREE.Mesh(marco, madera); mm.castShadow = mm.receiveShadow = true; cartel.add(mm);
  const panel = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 2.05), new THREE.MeshStandardMaterial({ map: texCartel(), roughness: 0.7 }));
  panel.position.set(0, 1.68, 0.1); panel.castShadow = true; cartel.add(panel);
  const dorso = new THREE.Mesh(new THREE.PlaneGeometry(1.7, 2.1), madera); dorso.position.set(0, 1.68, 0.06); dorso.rotation.y = Math.PI; cartel.add(dorso);
  G.add(ubicar(cartel, 3.2, 396.0, Math.atan2(1, -1)));
  const poste = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.12, 4.2, 8).translate(0, 2.0, 0), madera); poste.castShadow = true;
  G.add(ubicar(poste, 5.6, 397.6, 0));
  // auto blanco de escala (fotos 03 y 05), estacionado sobre la longitudinal 1
  if (cfg.auto !== false) {
    const a = new THREE.Group();
    const blanco = new THREE.MeshStandardMaterial({ color: '#e9ebec', roughness: 0.35, metalness: 0.2 });
    const vidrio = new THREE.MeshStandardMaterial({ color: '#1d2329', roughness: 0.1, metalness: 0.5 });
    const goma = new THREE.MeshStandardMaterial({ color: '#191919', roughness: 0.9 });
    const b = new THREE.Mesh(mergeGeometries([box(1.76, 0.62, 4.35, 0, 0.62, 0)]), blanco);
    const cab = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.56, 2.3).translate(0, 1.2, -0.25), vidrio);
    const techo = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.06, 1.9).translate(0, 1.5, -0.3), blanco);
    const rg = []; for (const [x, z] of [[-0.8, 1.35], [0.8, 1.35], [-0.8, -1.35], [0.8, -1.35]]) rg.push(new THREE.CylinderGeometry(0.33, 0.33, 0.24, 14).rotateZ(Math.PI / 2).translate(x, 0.33, z));
    const ru = new THREE.Mesh(mergeGeometries(rg), goma);
    for (const m of [b, cab, techo, ru]) { m.castShadow = true; m.receiveShadow = true; a.add(m); }
    const [u, v, r] = cfg.auto_plano || [150, 293.6, 0];
    G.add(ubicar(a, u, v, r));
  }
  return G;
}
