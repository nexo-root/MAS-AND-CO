// core.js: renderer, composición y salida del cuadro (base: kit del tanque, sin glitch ni flash)
import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
const _q = new URLSearchParams(location.search);
export const VERT = (_q.get('formato') || window.__FORMATO || 'horizontal') === 'vertical';
export const OW = VERT ? 1080 : 1920, OH = VERT ? 1920 : 1080;
// grano fino, viñeta suave, piso de negro (nunca negro puro) y curva de contraste leve
const Final = {
  uniforms: { tDiffuse: { value: null }, uT: { value: 0 }, uGrain: { value: 0.022 }, uVig: { value: 0.22 }, uLift: { value: 0.018 }, uSat: { value: 1.04 } },
  vertexShader: `varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,
  fragmentShader: `uniform sampler2D tDiffuse;uniform float uT,uGrain,uVig,uLift,uSat;varying vec2 vUv;
float h(vec2 p){return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453);}
void main(){vec3 c=texture2D(tDiffuse,vUv).rgb;
 float l=dot(c,vec3(.299,.587,.114));c=mix(vec3(l),c,uSat);
 c=c+(c-c*c)*0.06;                       // contraste suave en medios
 vec2 d=vUv-.5;float v=smoothstep(1.0,0.3,length(d*vec2(1.,.85)));c*=mix(1.,v,uVig);
 c=uLift+c*(1.-uLift);
 float g=h(vUv*vec2(1123.,1997.)+fract(uT*7.13))+h(vUv*vec2(733.,1511.)+fract(uT*3.71));
 c+=(g-1.)*uGrain*(0.6+0.4*(1.-l));
 gl_FragColor=vec4(clamp(c,0.,1.),1.);}`
};
const Clean = { uniforms: { tDiffuse: { value: null } }, vertexShader: Final.vertexShader,
  fragmentShader: `uniform sampler2D tDiffuse;varying vec2 vUv;void main(){vec3 c=texture2D(tDiffuse,vUv).rgb;if(!(c.r==c.r)||!(c.g==c.g)||!(c.b==c.b)||isinf(c.r)||isinf(c.g)||isinf(c.b))c=vec3(0.);gl_FragColor=vec4(clamp(c,0.,40.),1.);}` };
export function makeCore(o = {}) {
  const SS = parseFloat(_q.get('ss') || o.ss || 1.5);
  const W = Math.round(OW * SS), H = Math.round(OH * SS);
  const renderer = new THREE.WebGLRenderer({ antialias: false, preserveDrawingBuffer: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(1); renderer.setSize(W, H, false);
  renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = o.exposure ?? 1.0;
  renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap; renderer.shadowMap.autoUpdate = true;
  const scene = new THREE.Scene();
  const cam = new THREE.PerspectiveCamera(45, OW / OH, 1.0, 60000);
  const rt = new THREE.WebGLRenderTarget(W, H, { type: THREE.HalfFloatType, samples: 4 });
  const comp = new EffectComposer(renderer, rt); comp.setSize(W, H);
  comp.addPass(new RenderPass(scene, cam));
  comp.addPass(new ShaderPass(Clean));
  const bloom = new UnrealBloomPass(new THREE.Vector2(W / 2, H / 2), 0.12, 0.6, 1.6); comp.addPass(bloom);
  comp.addPass(new OutputPass());
  const fin = new ShaderPass(Final); comp.addPass(fin);
  const out = document.createElement('canvas'); out.width = OW; out.height = OH; const octx = out.getContext('2d');
  octx.imageSmoothingEnabled = true; octx.imageSmoothingQuality = 'high';
  const ov = document.createElement('canvas'); ov.width = OW; ov.height = OH; const ctx = ov.getContext('2d');
  function frame(fmt, { t = 0, drawOverlay } = {}) {
    fin.uniforms.uT.value = t; comp.render();
    octx.drawImage(renderer.domElement, 0, 0, W, H, 0, 0, OW, OH);
    if (drawOverlay) { ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, OW, OH); drawOverlay(ctx); octx.drawImage(ov, 0, 0); }
    return out.toDataURL(fmt === 'png' ? 'image/png' : 'image/jpeg', 0.94).split(',')[1];
  }
  return { renderer, scene, cam, comp, fin, out, octx, ov, ctx, frame, SS, W, H };
}
export async function loadFont(name, url, desc = {}) { const f = new FontFace(name, `url(${url})`, desc); await f.load(); document.fonts.add(f); return f; }
