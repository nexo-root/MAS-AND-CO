// oferta.js: video de OFERTA de lotes (secuencias "oferta" y "oferta_general").
// Se activa cuando la secuencia trae "guion". Datos de paquetes y precios en config.json -> "oferta".
// Pinta su propio resaltado en el suelo (mismo lienzo y shader que terrain.js, pero con un alfa por lote y por segundo)
// y dibuja rótulos, líneas finas y textos en el overlay 2D. No toca terreno, calles ni vegetación.
import * as THREE from 'three';
import { OW, OH, VERT } from './core.js';
import { toWorld, centroid } from './geo.js';
import { altura, LK, bbox } from './terrain.js';
import { sstep, clamp } from './k.js';

const lpx = (u, v) => [(u - LK.u0) / LK.res, (LK.v0 + LK.h - v) / LK.res];
const rgbDe = c => { const k = new THREE.Color(c); return [k.r * 255, k.g * 255, k.b * 255]; };
const mezcla = (a, b, u) => a.map((x, i) => Math.round(x + (b[i] - x) * u));
// alfa de una ventana [desde, hasta] con fundido de entrada y salida
const ventana = (t, d, h, f = 0.8) => sstep(d, d + f, t) * (h == null ? 1 : 1 - sstep(h - f, h, t));

export function armarOferta({ cfg, L, mat, sec }) {
  const O = cfg.oferta || {}, G = sec.guion || {};
  const cDisp = rgbDe(O.color_disponible || '#3CCFFF'), cPaq = rgbDe(O.color_paquete || '#F0D060');
  const ACENTO = O.color_paquete || '#F0D060';
  const buscar = (mz, n) => L.lotes.find(l => l.manzana === mz && l.lote === n);
  // ---- lotes: disponibles (celeste tenue) y paquetes del guion (dorado)
  const lotes = new Map(); // clave "mz-lote" -> {pol, disp, paq}
  const tomar = (mz, n) => { const k = mz + '-' + n; if (!lotes.has(k)) { const l = buscar(mz, n); if (!l) { console.warn('oferta: no existe', mz, n); return null; } lotes.set(k, { pol: l.poligono_plano, n, disp: false, paq: null }); } return lotes.get(k); };
  if (G.disponibles !== false) for (const d of (O.disponibles || [])) for (const n of d.lotes) { const o = tomar(d.mz, n); if (o) o.disp = true; }
  const paquetes = (G.paquetes || []).map(p => {
    const P = { ...(O.paquetes || {})[p.id], ...p };
    P.items = P.lotes.map(n => tomar(P.mz, n)).filter(Boolean); P.items.forEach(o => o.paq = P);
    P.centro = centroid(P.items.map(o => centroid(o.pol)));
    const [x, y] = toWorld(...P.centro); P.ancla = [x, altura(x, y) + 0.5, -y];
    for (const o of P.items) { const w3 = (u, v) => { const [x, y] = toWorld(u, v); return [x, altura(x, y) + 0.5, -y]; }; const bb = bbox(o.pol); o.ancla = w3(...centroid(o.pol)); o.diag = [w3(bb[0], bb[1]), w3(bb[2], bb[3])]; }
    P.esq = P.esquina ? P.items.find(o => o.n === P.esquina) : null;
    if (P.esq) { const c = centroid(P.esq.pol); const [ex, ey] = toWorld(...c); P.anclaEsq = [ex, altura(ex, ey) + 0.5, -ey]; }
    return P;
  });
  const D = G.disponibles || {};
  const aDisp = t => D.desde == null ? 0 : ventana(t, D.desde, D.hasta, D.fundido ?? 1.2) * (D.alfa ?? 0.5);
  const aPaq = (P, t) => Math.max(ventana(t, P.desde, P.hasta, P.fundido ?? 1.0), G.todos_desde == null ? 0 : sstep(G.todos_desde, G.todos_desde + 1.2, t)); // "hasta": vuelve a celeste; "todos_desde": en el cierre se encienden todos

  // ---- lienzo del resaltado (mismo marco que construirResaltado de terrain.js)
  const cv = document.createElement('canvas'); cv.width = LK.W; cv.height = LK.H; const g = cv.getContext('2d'); g.lineJoin = 'round';
  const tex = new THREE.CanvasTexture(cv); tex.anisotropy = 8; tex.colorSpace = THREE.NoColorSpace;
  const poly = P => { g.beginPath(); P.forEach((p, i) => { const [x, y] = lpx(p[0], p[1]); i ? g.lineTo(x, y) : g.moveTo(x, y); }); g.closePath(); };
  let clave = '';
  function pintar(t) {
    const ad = aDisp(t), aps = paquetes.map(P => aPaq(P, t));
    const k = [ad, ...aps].map(a => Math.round(a * 96)).join(',');
    if (k === clave) return; clave = k;
    g.globalAlpha = 1; g.fillStyle = '#000'; g.fillRect(0, 0, LK.W, LK.H);
    const capas = [];
    for (const o of lotes.values()) {
      const ap = o.paq ? aps[paquetes.indexOf(o.paq)] : 0, a0 = o.disp ? ad : 0;
      if (ap < 0.004 && a0 < 0.004) continue;
      // de celeste tenue a dorado pleno
      const col = ap > 0 ? (a0 > 0 ? mezcla(cDisp, cPaq, ap) : cPaq) : cDisp;
      const fill = a0 * 0.32 * (1 - ap) + ap * 0.40, borde = Math.max(a0 * 0.75 * (1 - ap), ap);
      capas.push({ o, col, fill, borde, ap });
    }
    for (const c of capas) { g.fillStyle = `rgba(${c.col},${c.fill})`; poly(c.o.pol); g.fill(); }
    for (const c of capas) { g.strokeStyle = `rgba(${c.col},${c.borde})`; g.lineWidth = (c.ap > 0 ? 0.55 : 0.45) / LK.res; poly(c.o.pol); g.stroke(); }
    // (los números de los lotes van como fichas 2D nítidas en el overlay: en el suelo los tapaban los árboles)
    tex.needsUpdate = true;
  }
  const U = mat.userData.u;
  function update(t) { pintar(t); U.uHl.value = tex; U.uHL.value = 1; }

  // ---- overlay 2D
  const S = VERT ? 1.25 : 1, M = 64 * S;
  const FN = { titulo: f => `700 ${f}px Georgia`, sub: f => `500 ${f}px Mont`, dato: f => `500 ${f}px Mont`, chico: f => `500 ${f}px Mont`, etiqueta: f => `600 ${f}px Mont`, grande: f => `700 ${f}px Mont`, precio: f => `700 ${f}px Mont` };
  const TAM = { titulo: VERT ? 70 : 64, sub: 32, dato: 27, chico: 24, etiqueta: 22, grande: 40, precio: 48 };
  const COLOR = { titulo: '#FFFFFF', sub: 'rgba(255,255,255,0.92)', dato: 'rgba(245,245,240,0.88)', chico: 'rgba(245,245,240,0.80)', etiqueta: ACENTO, grande: '#FFFFFF', precio: ACENTO };
  const espaciado = (ctx, txt, ls) => { ctx.letterSpacing = ls ? `${ls}px` : '0px'; return ctx.measureText(txt).width; };
  function medirLineas(ctx, lineas) {
    return lineas.map(([est, txt]) => { const f = Math.round(TAM[est] * S); ctx.font = FN[est](f); const ls = est === 'etiqueta' ? 3 * S : 0; return { est, txt, f, ls, w: espaciado(ctx, txt, ls) }; });
  }
  // corta en " · " los renglones que no entran en el ancho
  function partir(ctx, ls, maxW) {
    const out = [];
    for (const l of ls) {
      if (l.w <= maxW || !l.txt.includes(' · ')) { out.push(l); continue; }
      ctx.font = FN[l.est](l.f); let cur = '';
      for (const p of l.txt.split(' · ')) { const prueba = cur ? cur + ' · ' + p : p; if (cur && espaciado(ctx, prueba, l.ls) > maxW) { out.push({ ...l, txt: cur, w: espaciado(ctx, cur, l.ls) }); cur = p; } else cur = prueba; }
      if (cur) out.push({ ...l, txt: cur, w: espaciado(ctx, cur, l.ls) });
    }
    return out;
  }
  // fichas con el número de cada lote del paquete (y la marca de esquina), solo cuando el lote se ve grande
  function fichas(ctx, P, a, proj) {
    ctx.save(); ctx.textBaseline = 'middle'; ctx.textAlign = 'center';
    for (const o of P.items) {
      const p = proj(...o.ancla), d0 = proj(...o.diag[0]), d1 = proj(...o.diag[1]); if (!p.ok || !d0.ok || !d1.ok) continue;
      const tam = Math.hypot(d1.x - d0.x, d1.y - d0.y), b = a * sstep(90 * S, 130 * S, tam); if (b < 0.01) continue;
      const f = Math.round(26 * S), txt = String(o.n); ctx.font = `700 ${f}px Mont`; ctx.letterSpacing = '0px';
      const tw = ctx.measureText(txt).width, w = Math.max(tw + 22 * S, f * 1.55), h = f * 1.45;
      ctx.globalAlpha = b; ctx.shadowColor = 'rgba(0,0,0,0.55)'; ctx.shadowBlur = 10 * S; ctx.fillStyle = 'rgba(10,10,10,0.74)'; rr(ctx, p.x - w / 2, p.y - h / 2, w, h, h / 2); ctx.fill();
      ctx.shadowBlur = 0; ctx.strokeStyle = ACENTO; ctx.lineWidth = 1.6 * S; rr(ctx, p.x - w / 2, p.y - h / 2, w, h, h / 2); ctx.stroke();
      ctx.fillStyle = '#FFFFFF'; ctx.fillText(txt, p.x, p.y + 1);
      if (o === P.esq && P.marca_esquina) {
        const f2 = Math.round(17 * S); ctx.font = `600 ${f2}px Mont`; ctx.letterSpacing = `${2 * S}px`;
        const t2 = ctx.measureText(P.marca_esquina).width, w2 = t2 + 20 * S, h2 = f2 + 12 * S, y2 = p.y + h / 2 + 8 * S;
        ctx.fillStyle = 'rgba(10,10,10,0.74)'; rr(ctx, p.x - w2 / 2, y2, w2, h2, 4 * S); ctx.fill();
        ctx.fillStyle = ACENTO; ctx.fillText(P.marca_esquina, p.x + S, y2 + h2 / 2 + 1); ctx.letterSpacing = '0px';
      }
    }
    ctx.restore();
  }
  // bloque de texto libre (títulos, datos): sombra, sin caja, raya de acento arriba
  function bloque(ctx, B, a) {
    const pos = (VERT ? B.pos_vertical : B.pos) || B.pos || [0, 0];
    let x = M + pos[0] * OW, y = M + pos[1] * OH; const centrado = B.alinear === 'centro';
    const ls = partir(ctx, medirLineas(ctx, B.lineas), centrado ? OW - 2 * M : OW - M - x);
    ctx.save();
    { // velo oscuro suave detrás del texto (legible sobre suelo claro)
      const wv = Math.max(...ls.map(l => l.w)) + 160 * S, hv = ls.reduce((s, l) => s + l.f * 1.5, 0) + 120 * S, cx0 = centrado ? OW / 2 : x + wv * 0.32, cy0 = y + hv * 0.45;
      const gr = ctx.createRadialGradient(cx0, cy0, 0, cx0, cy0, wv * 0.75); gr.addColorStop(0, 'rgba(6,8,6,0.42)'); gr.addColorStop(1, 'rgba(6,8,6,0)');
      ctx.globalAlpha = a; ctx.fillStyle = gr; ctx.save(); ctx.translate(cx0, cy0); ctx.scale(1, hv / wv * 1.25); ctx.translate(-cx0, -cy0); ctx.fillRect(cx0 - wv, cy0 - wv, wv * 2, wv * 2); ctx.restore();
    }
    ctx.globalAlpha = a; ctx.textBaseline = 'alphabetic'; ctx.shadowColor = 'rgba(0,0,0,0.7)'; ctx.shadowBlur = 18 * S;
    if (B.raya !== false) { ctx.fillStyle = ACENTO; const rw = 56 * S; ctx.fillRect(centrado ? OW / 2 - rw / 2 : x, y, rw, 3 * S); y += 14 * S; }
    for (const l of ls) {
      y += l.f * 1.12; ctx.font = FN[l.est](l.f); ctx.letterSpacing = l.ls ? `${l.ls}px` : '0px'; ctx.fillStyle = COLOR[l.est];
      ctx.textAlign = centrado ? 'center' : 'left'; ctx.fillText(l.txt, centrado ? OW / 2 : x, y); y += l.f * 0.38;
    }
    ctx.restore();
  }
  // leyenda: cuadradito de color + texto
  function leyenda(ctx, B, a) {
    const pos = (VERT ? B.pos_vertical : B.pos) || [0, 0]; const x = M + pos[0] * OW, y = M + pos[1] * OH;
    ctx.save(); ctx.globalAlpha = a; ctx.shadowColor = 'rgba(0,0,0,0.65)'; ctx.shadowBlur = 14 * S; ctx.textBaseline = 'middle';
    let yy = y; for (const it of B.items) {
      const f = Math.round(22 * S), q = 18 * S; ctx.fillStyle = it.color; ctx.globalAlpha = a * 0.85; ctx.fillRect(x, yy - q / 2, q, q);
      ctx.globalAlpha = a; ctx.strokeStyle = it.color; ctx.lineWidth = 1.5 * S; ctx.strokeRect(x, yy - q / 2, q, q);
      ctx.font = `500 ${f}px Mont`; ctx.fillStyle = 'rgba(245,245,240,0.92)'; ctx.textAlign = 'left'; ctx.fillText(it.texto, x + q + 12 * S, yy + 1); yy += f * 1.7;
    }
    ctx.restore();
  }
  // rótulo de un paquete: caja oscura con raya dorada, posición fija en pantalla y línea fina hasta el grupo
  function rotulo(ctx, P, a, proj) {
    const p = proj(...P.ancla); if (!p.ok) return;
    const lineas = [['etiqueta', P.titulo.toUpperCase()], ['grande', P.linea], ['dato', P.dato]];
    if (P.nota) lineas.push(['chico', P.nota]);
    lineas.push(['precio', P.precio]);
    const ls = medirLineas(ctx, lineas), pad = 22 * S, gap = 8 * S;
    const w = Math.max(...ls.map(l => l.w)) + pad * 2 + 6 * S, h = ls.reduce((s, l) => s + l.f * 1.18, 0) + gap * (ls.length - 1) + pad * 1.7;
    const pos = (VERT ? P.rotulo_vertical : P.rotulo_horizontal) || (VERT ? [0.5, 0.0] : [0.0, 0.18]);
    let bx = M + pos[0] * (OW - 2 * M - w), by = M + pos[1] * (OH - 2 * M - h);
    bx = clamp(bx, M, OW - M - w); by = clamp(by, M, OH - M - h);
    ctx.save(); ctx.globalAlpha = a;
    // línea fina: desde el borde de la caja más cercano al grupo
    const ex = clamp(p.x, bx, bx + w), ey = clamp(p.y, by, by + h);
    const [lx, ly] = [ex, ey];
    ctx.strokeStyle = 'rgba(255,255,255,0.9)'; ctx.lineWidth = 1.5 * S; ctx.shadowColor = 'rgba(0,0,0,0.6)'; ctx.shadowBlur = 6 * S;
    ctx.beginPath(); ctx.moveTo(lx, ly); ctx.lineTo(p.x, p.y); ctx.stroke();
    ctx.fillStyle = ACENTO; ctx.beginPath(); ctx.arc(p.x, p.y, 6 * S, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = 'rgba(10,10,10,0.7)'; ctx.lineWidth = 1.5 * S; ctx.stroke();
    // caja
    ctx.shadowColor = 'rgba(0,0,0,0.5)'; ctx.shadowBlur = 22 * S; ctx.fillStyle = 'rgba(10,10,10,0.66)'; rr(ctx, bx, by, w, h, 8 * S); ctx.fill();
    ctx.shadowBlur = 0; ctx.fillStyle = ACENTO; ctx.fillRect(bx, by + 10 * S, 4 * S, h - 20 * S);
    ctx.strokeStyle = 'rgba(212,175,55,0.45)'; ctx.lineWidth = 1 * S; rr(ctx, bx + 0.5, by + 0.5, w - 1, h - 1, 8 * S); ctx.stroke();
    let y = by + pad * 0.85; ctx.textBaseline = 'alphabetic'; ctx.textAlign = 'left';
    for (const l of ls) { y += l.f * 1.0; ctx.font = FN[l.est](l.f); ctx.letterSpacing = l.ls ? `${l.ls}px` : '0px'; ctx.fillStyle = COLOR[l.est]; ctx.fillText(l.txt, bx + pad + 6 * S, y); y += l.f * 0.18 + gap; }
    ctx.letterSpacing = '0px'; ctx.restore();
  }
  function draw(ctx, t, proj) {
    for (const B of (G.textos || [])) { const a = ventana(t, B.desde, B.hasta, B.fundido ?? 0.8); if (a > 0.003) (B.items ? leyenda : bloque)(ctx, B, a); }
    // fichas solo mientras se presenta el paquete (en el cierre, de lejos, ensucian)
    for (const P of paquetes) { const a = Math.min(aPaq(P, t), P.rotulo ? ventana(t, P.desde, P.rotulo[1] + 0.4, 0.7) : 1); if (a > 0.01) fichas(ctx, P, a, proj); }
    for (const P of paquetes) if (P.rotulo) { const a = ventana(t, P.rotulo[0], P.rotulo[1], 0.7); if (a > 0.003) rotulo(ctx, P, a, proj); }
  }
  return { update, draw, paquetes };
}
function rr(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
