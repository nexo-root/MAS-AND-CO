// main.js: carga config + loteo, arma la maqueta y expone el contrato de render.
// window.__ready = true · window.renderFrame(t,'jpeg'|'png') -> base64 · window.__DUR
// URL: ?formato=vertical · ?estado=hoy|proyecto · ?secuencia=paneo|foto01|foto03|cartel|totems · ?obras=totems|no · ?config=otra.json · ?ss=1.5
import * as THREE from 'three';
import { makeCore, loadFont, OW, OH } from './core.js';
import { build } from './scene.js';
import { makeOverlay } from './overlay.js';
(async () => {
  try {
    const q = new URLSearchParams(location.search);
    const J = async u => (await fetch(u, { cache: 'no-store' })).json();
    const [cfg, L] = await Promise.all([J(q.get('config') || 'config.json'), J('loteo.json')]);
    if (q.get('secuencia')) cfg.secuencia = q.get('secuencia');
    const aj = (cfg.camaras[cfg.secuencia || 'paneo'] || {}).ajustes; if (aj) Object.assign(cfg, aj); // la secuencia puede fijar estado, obras, sol...
    if (q.get('estado')) cfg.estado = q.get('estado');
    if (q.get('obras')) cfg.obras = q.get('obras') === 'no' ? null : q.get('obras');
    await loadFont('Mont', 'fonts/Montserrat.ttf', { weight: '100 900' });
    const core = makeCore({ exposure: cfg.exposicion ?? 1.0 });
    const sc = await build(core, cfg, L);
    const sec = cfg.camaras[cfg.secuencia || 'paneo'];
    const v = new THREE.Vector3();
    const proj = (x, y, z) => { v.set(x, y, z).applyMatrix4(core.cam.matrixWorldInverse); const ok = v.z < -0.05; v.applyMatrix4(core.cam.projectionMatrix); return { x: (v.x * .5 + .5) * OW, y: (-v.y * .5 + .5) * OH, ok }; };
    const textos = sec.sin_textos ? {} : cfg;
    const ov = makeOverlay({ grupos: sec.sin_textos ? [] : sc.grupos, cfg: textos, proj });
    const DUR = Math.ceil((sec.duracion ?? (sc.cams.dur + (sec.cola ?? 0))) * 30) / 30;
    window.__DUR = DUR; window.__FMT = { w: OW, h: OH, fps: 30 };
    const hl = t => (sec.sin_textos && !sec.resaltar) ? 0 : ov.alfaResaltado(t);
    if (sc.oferta) window.renderFrame = (t, fmt = 'jpeg') => { t = Math.max(0, Math.min(t, DUR - 1 / 60)); sc.update(t, 0); return core.frame(fmt, { t, drawOverlay: ctx => sc.oferta.draw(ctx, t, proj) }); };
    else window.renderFrame = sc.obras ? sc.obras.renderizador({ sc, ov, sec, hl, DUR }) : (t, fmt = 'jpeg') => { t = Math.max(0, Math.min(t, DUR - 1 / 60)); sc.update(t, hl(t)); return core.frame(fmt, { t, drawOverlay: ctx => ov.draw(ctx, t) }); };
    window.__probe = t => { sc.update(t, hl(t)); return { cam: sc.st.cam }; };
    window.__info = { dur: DUR, cuenta: sc.cuenta, sol: sc.sunHDR, rotY: sc.rotY, info: core.renderer.info.render };
    window.__tri = () => { let t = 0; core.scene.traverse(o => { if (o.isMesh && o.visible) { const g = o.geometry; t += (g.index ? g.index.count : g.attributes.position.count) / 3 * (o.isInstancedMesh ? o.count : 1); } }); return t; }; // triángulos de la escena (medir.cjs)
    window.__ready = true;
  } catch (e) { window.__error = String(e && e.stack || e); console.log('ERR ' + window.__error); }
})();
