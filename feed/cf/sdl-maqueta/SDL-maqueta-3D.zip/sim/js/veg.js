// veg.js: pinar en hileras, monte nativo (con árboles blancos secos y lapachos), árboles sueltos en los lotes, matas y piedras.
import * as THREE from 'three';
import { mergeGeometries, mergeVertices } from 'three/addons/utils/BufferGeometryUtils.js';
import { fbm2, vn2 } from './glsl.js';
import { toWorld, toPlan, C, inPoly } from './geo.js';
import { altura, ZONA, PINAR_V, bbox, ISLA, vivoIsla, alturaIsla } from './terrain.js';
import { rng, sstep } from './k.js';

const NOISE3 = `float vh(vec3 p){p=fract(p*vec3(.1031,.1030,.0973));p+=dot(p,p.yzx+33.33);return fract((p.x+p.y)*p.z);}
float vn(vec3 p){vec3 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);
 return mix(mix(mix(vh(i),vh(i+vec3(1,0,0)),f.x),mix(vh(i+vec3(0,1,0)),vh(i+vec3(1,1,0)),f.x),f.y),mix(mix(vh(i+vec3(0,0,1)),vh(i+vec3(1,0,1)),f.x),mix(vh(i+vec3(0,1,1)),vh(i+vec3(1,1,1)),f.x),f.y),f.z);}`;
// material de follaje: grumos de hojas por ruido de mundo (para que no parezca plastilina de cerca)
function matFollaje(key, { grumo = 1.3, amp = 0.55, rough = 0.92, bump = 0.5 } = {}) {
  const m = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: rough, metalness: 0 });
  m.onBeforeCompile = sh => {
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vW;')
      .replace('#include <project_vertex>', '#include <project_vertex>\n#ifdef USE_INSTANCING\nvW=(modelMatrix*instanceMatrix*vec4(transformed,1.)).xyz;\n#else\nvW=(modelMatrix*vec4(transformed,1.)).xyz;\n#endif');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nvarying vec3 vW;\n' + NOISE3)
      .replace('#include <color_fragment>', `#include <color_fragment>
 float g1=vn(vW*${grumo.toFixed(3)}),g2=vn(vW*${(grumo * 3.1).toFixed(3)}+7.);
 diffuseColor.rgb*=(1.-${amp.toFixed(3)})+${(amp * 1.25).toFixed(3)}*(g1*.7+g2*.3);
 diffuseColor.rgb*=mix(.55,1.,smoothstep(.25,.6,g1));`)
      .replace('#include <normal_fragment_maps>', `#include <normal_fragment_maps>
 {float e=.35;vec3 q=vW*${(grumo * 2.0).toFixed(3)};vec3 gr=vec3(vn(q+vec3(e,0,0))-vn(q-vec3(e,0,0)),vn(q+vec3(0,e,0))-vn(q-vec3(0,e,0)),vn(q+vec3(0,0,e))-vn(q-vec3(0,0,e)));
  normal=normalize(normal+(viewMatrix*vec4(gr*${bump.toFixed(3)}*2.,0.)).xyz);}`);
  };
  m.customProgramCacheKey = () => 'fol:' + key;
  return m;
}
function colorear(g, f) { const p = g.attributes.position, c = new Float32Array(p.count * 3); for (let i = 0; i < p.count; i++) { const k = f(p.getX(i), p.getY(i), p.getZ(i)); c[i * 3] = k[0]; c[i * 3 + 1] = k[1]; c[i * 3 + 2] = k[2]; } g.setAttribute('color', new THREE.BufferAttribute(c, 3)); return g; }
function blob(r, seed, { det = 1, rough = 0.28, sy = 0.75 } = {}) {
  let g = new THREE.IcosahedronGeometry(r, det); g.deleteAttribute('normal'); g.deleteAttribute('uv'); g = mergeVertices(g);
  const p = g.attributes.position, R = rng(seed);
  const o = [R() * 9, R() * 9, R() * 9];
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i), z = p.getZ(i), l = Math.hypot(x, y, z);
    const n = fbm2(x / r * 1.3 + o[0] + z / r * 0.7, y / r * 1.3 + o[1] + z / r * 0.4, 3);
    const k = 1 + (n - 0.5) * 2 * rough; p.setXYZ(i, x * k, y * k * sy, z * k);
  }
  g.computeVertexNormals(); const gn = g.attributes.normal;
  // normales medio «esféricas»: la copa se ilumina como volumen pero conserva los grumos
  const nn = new Float32Array(p.count * 3);
  for (let i = 0; i < p.count; i++) { const x = p.getX(i), y = p.getY(i) / sy, z = p.getZ(i), l = Math.hypot(x, y, z) || 1; const a = x / l * .55 + gn.getX(i) * .45, b2 = y / l * .55 + gn.getY(i) * .45, c = z / l * .55 + gn.getZ(i) * .45; const m = Math.hypot(a, b2, c) || 1; nn[i * 3] = a / m; nn[i * 3 + 1] = b2 / m; nn[i * 3 + 2] = c / m; }
  g.setAttribute('normal', new THREE.BufferAttribute(nn, 3));
  return g;
}
function cil(a, b, r0, r1, seg = 5) {
  const A = new THREE.Vector3(...a), B = new THREE.Vector3(...b), d = B.clone().sub(A), L = d.length();
  const g = new THREE.CylinderGeometry(r1, r0, L, seg, 1, true); g.translate(0, L / 2, 0);
  g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.normalize())); g.translate(...a);
  g.deleteAttribute('uv'); return g;
}
const ao = (y0, y1, lo = 0.5) => (x, y, z) => { const k = lo + (1 - lo) * sstep(y0, y1, y); return [k, k, k]; };

// ---------- geometrías (altura total = 1; la instancia escala) ----------
function geoPino(seed) {
  const R = rng(seed), prof = [[0.0, 0.36], [0.07, 0.37], [0.1, 0.47], [0.095, 0.6], [0.075, 0.74], [0.045, 0.88], [0.0, 1.0]];
  const pts = prof.map(([r, y]) => new THREE.Vector2(r * (0.9 + R() * 0.2), y));
  let crown = new THREE.LatheGeometry(pts, 7); crown.deleteAttribute('uv'); crown = mergeVertices(crown);
  const p = crown.attributes.position; for (let i = 0; i < p.count; i++) { const y = p.getY(i); const k = 1 + (R() - 0.5) * 0.25 * sstep(0.36, 0.5, y); p.setX(i, p.getX(i) * k); p.setZ(i, p.getZ(i) * k); }
  crown.computeVertexNormals(); colorear(crown, ao(0.36, 0.95, 0.42));
  const tr = cil([0, -0.05, 0], [0, 0.42, 0], 0.013, 0.008, 5); tr.computeVertexNormals(); colorear(tr, () => [0.42, 0.33, 0.3]);
  return mergeGeometries([crown, tr]);
}
function geoCopa(seed, det = 1) { // copa de monte: varios grumos irregulares (no una bola). det 0 = versión liviana para el margen
  const R = rng(seed), G = [], n = 4 + Math.floor(R() * 4);
  for (let k = 0; k < n; k++) {
    const r = k === 0 ? 0.36 : 0.18 + R() * 0.16, a = R() * 6.28, d = k === 0 ? 0 : 0.18 + R() * 0.3;
    const b = blob(r, seed * 7 + k, { sy: 0.62, rough: 0.42, det }); b.translate(Math.cos(a) * d, 0.7 + (R() - 0.4) * 0.22 - d * 0.25, Math.sin(a) * d); G.push(b);
  }
  const g = mergeGeometries(G); colorear(g, ao(0.35, 0.95, 0.38));
  const tr = cil([0, -0.05, 0], [0, 0.55, 0], 0.035, 0.02, 5); tr.computeVertexNormals(); colorear(tr, () => [0.32, 0.27, 0.22]);
  return mergeGeometries([g, tr]);
}
function geoSuelto(seed) { // árbol fino que quedó en pie en el lote (6-10 m)
  const R = rng(seed), G = [];
  const tr = cil([0, -0.05, 0], [(R() - .5) * .06, 0.62, (R() - .5) * .06], 0.022, 0.012, 5); tr.computeVertexNormals(); colorear(tr, () => [0.4, 0.34, 0.28]); G.push(tr);
  for (let k = 0; k < 3; k++) { const b = blob(0.13 + R() * 0.08, seed * 13 + k, { sy: 0.75, rough: 0.35 }); b.translate((R() - .5) * 0.22, 0.68 + R() * 0.24, (R() - .5) * 0.22); colorear(b, ao(0.55, 1, 0.5)); G.push(b); }
  return mergeGeometries(G);
}
function geoSeco(seed) { // árbol blanco seco, sin hojas
  const R = rng(seed), G = [];
  const top = [(R() - .5) * .05, 0.5, (R() - .5) * .05];
  G.push(cil([0, -0.05, 0], top, 0.022, 0.014, 6));
  for (let k = 0; k < 6; k++) {
    const a = k / 6 * 6.28 + R(), up = 0.45 + R() * 0.45, L = 0.22 + R() * 0.25;
    const s = [top[0], top[1] - R() * 0.12, top[2]], e = [s[0] + Math.cos(a) * L * (1 - up * .5), s[1] + L * up + 0.1, s[2] + Math.sin(a) * L * (1 - up * .5)];
    G.push(cil(s, e, 0.009, 0.003, 4));
    const e2 = [e[0] + Math.cos(a + 0.8) * 0.1, e[1] + 0.1, e[2] + Math.sin(a + 0.8) * 0.1]; G.push(cil(e, e2, 0.004, 0.0015, 3));
  }
  const g = mergeGeometries(G); g.computeVertexNormals(); colorear(g, ao(0, 0.8, 0.75)); return g;
}
function geoMata(seed) { // mata: varios grumos chicos, no una bola
  const R = rng(seed), G = [];
  for (let k = 0; k < 5; k++) { const b = blob(0.22 + R() * 0.14, seed * 5 + k, { sy: 0.9, rough: 0.5 }); const a = R() * 6.28, d = k ? 0.18 + R() * 0.2 : 0; b.translate(Math.cos(a) * d, 0.2 + R() * 0.25, Math.sin(a) * d); G.push(b); }
  const g = mergeGeometries(G); colorear(g, ao(-0.05, 0.6, 0.45)); return g; }
function geoPiedra(seed) { const g = blob(0.5, seed, { sy: 0.45, rough: 0.55, det: 1 }); g.computeVertexNormals(); colorear(g, () => [1, 1, 1]); return g; }

// ---------- plantación ----------
class Lote {
  constructor(geos, mat, sombra = true) { this.geos = geos; this.mat = mat; this.items = geos.map(() => []); this.sombra = sombra; }
  add(k, x, y, z, s, sy, ry, col) { this.items[k % this.geos.length].push([x, y, z, s, sy, ry, col]); }
  meshes() {
    const out = [], m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), cc = new THREE.Color();
    this.geos.forEach((g, k) => {
      const it = this.items[k]; if (!it.length) return;
      const im = new THREE.InstancedMesh(g, this.mat, it.length);
      it.forEach(([x, y, z, s, sy, ry, col], i) => {
        e.set(0, ry, 0); q.setFromEuler(e); m4.compose(new THREE.Vector3(x, y, z), q, new THREE.Vector3(s[0], sy, s[1])); im.setMatrixAt(i, m4);
        cc.copy(col); im.setColorAt(i, cc);
      });
      im.castShadow = this.sombra; im.receiveShadow = true; im.frustumCulled = false; out.push(im);
    });
    return out;
  }
  get count() { return this.items.reduce((a, b) => a + b.length, 0); }
}
const lin = h => new THREE.Color(h);
function variar(c, R, k = 0.12) { const o = c.clone(); const f = 1 + (R() - 0.5) * 2 * k; o.multiplyScalar(f); return o; }

export function plantar(L, mask, estado) {
  const R = rng(1234);
  const grupo = new THREE.Group();
  const fol = matFollaje('copa', { grumo: 1.1, amp: 0.4, bump: 0.7 }), folP = matFollaje('pino', { grumo: 1.4, amp: 0.45, bump: 0.6 });
  const mader = matFollaje('seco', { grumo: 3, amp: 0.2, rough: 0.8, bump: 0.1 });
  const pinos = new Lote([0, 1, 2].map(k => geoPino(11 + k)), folP);
  const copas = new Lote([0, 1, 2, 3, 4].map(k => geoCopa(31 + k)), fol);
  const copasL = new Lote([0, 1, 2, 3, 4].map(k => geoCopa(31 + k, 0)), fol); // v4: margen (lejos del loteo), menos triángulos
  const sueltos = new Lote([0, 1, 2].map(k => geoSuelto(51 + k)), fol);
  const secos = new Lote([0, 1, 2].map(k => geoSeco(71 + k)), mader);
  const matas = new Lote([0, 1, 2, 3].map(k => geoMata(91 + k)), matFollaje('mata', { grumo: 2.2, amp: 0.5, bump: 0.4 }));
  const roca = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.8, metalness: 0, flatShading: true });
  const piedras = new Lote([0, 1, 2].map(k => geoPiedra(111 + k)), roca);
  const lee = mask.leer;
  const mz = n => L.manzanas.find(m => m.numero === n).poligono_plano;
  const etapa1 = [1, 2, 5, 6].map(mz);
  const enEtapa1 = (u, v) => etapa1.some(P => inPoly([u, v], P));
  const en02bajo = (u, v) => inPoly([u, v], mz(2)) && v < 232;
  // v4: el sorteo (R) es el mismo de v3, así que adentro de la isla cada árbol queda donde estaba; afuera no se planta.
  const lejos = (u, v) => u < -25 - 45 || u > 500 + 45 || v < -100 - 45 || v > 425 + 45;
  const pon = (lote, k, u, v, s, sy, col, hund = 0.3) => {
    const ry = R() * 6.283;
    if (!vivoIsla(u, v)) return;
    if (lote === pinos) { // pinar: solo la franja junto al camino público; los últimos 60 m se ralean y bajan
      const fp = sstep(425 + ISLA.pinar_fondo - 60, 425 + ISLA.pinar_fondo, v);
      if (fp >= 1 || Math.abs(Math.sin(u * 3.7 + v * 9.1) * 9631.7) % 1 < fp * 0.85) return;
      sy *= 1 - 0.45 * fp;
    }
    if (lote === matas && s[0] < 1.0) return;                     // matas muy chicas: no se ven
    if (lote === copas && lejos(u, v)) lote = copasL;
    if (lote.mat !== roca) sy *= alturaIsla(u, v);
    const [x, y] = toWorld(u, v); lote.add(k, x, altura(x, y) - hund, -y, s, sy, ry, col);
  };

  // --- pinar: hileras paralelas al camino público NO, rodales de alturas parejas
  const cPino = lin('#4a5a4e');
  for (let v = PINAR_V + 1.5; v < ZONA.v1; v += 3.7) {
    for (let u = ZONA.u0; u < ZONA.u1; u += 2.9) {
      if (R() < 0.05) continue;
      const uu = u + (R() - .5) * 0.7, vv = v + (R() - .5) * 0.5;
      const hs = 18.5 + 6 * fbm2(uu / 220 + 4, vv / 220 + 1, 3);
      const h = hs * (0.9 + R() * 0.18), w = h * (0.95 + R() * 0.25);
      const col = variar(cPino, R, 0.1); col.offsetHSL((fbm2(uu / 90, vv / 90, 2) - .5) * 0.03, 0, 0);
      pon(pinos, Math.floor(R() * 3), uu, vv, [w, w], h, col);
    }
  }
  // --- monte nativo
  const pal = ['#26341a', '#334621', '#41552a', '#536530', '#6b7a36', '#4f5a2c', '#7c8640'].map(lin);
  const cSeco = lin('#cfcbbf'), cLap = [lin('#c67ea6'), lin('#b98ab9')];
  const paso = 4.4; // v2: monte más denso (feedback Juan Diego 18/11)
  for (let v = ZONA.v0; v < PINAR_V - 2; v += paso) for (let u = ZONA.u0; u < ZONA.u1; u += paso) {
    const uu = u + (R() - .5) * paso * 0.9, vv = v + (R() - .5) * paso * 0.9;
    if (lee(uu, vv, 0) > 0.02 || lee(uu, vv, 2) > 0.4) continue;
    const a = lee(uu, vv, 3) + (fbm2(uu / 25, vv / 25, 3) - .5) * 0.35;
    const enLoteo = uu > 0 && uu < 500 && vv > 0 && vv < 400;
    if (a > 0.45) { // desmonte: árboles sueltos que quedaron en pie
      const prob = enEtapa1(uu, vv) ? 0.02 : 0.05; // v3: videos /watch 19/11 — etapa 1 casi pelada (~30-35 árboles sueltos)
      if (a < 0.9 || R() < prob) {
        if (a > 0.9 || R() < 0.08) {
          const h = 6 + R() * 4.5, seco = R() < (enEtapa1(uu, vv) ? 0.55 : 0.25);
          if (seco) pon(secos, Math.floor(R() * 3), uu, vv, [h, h], h, variar(cSeco, R, 0.06));
          else pon(sueltos, Math.floor(R() * 3), uu, vv, [h, h], h, variar(pal[Math.floor(R() * pal.length)], R, 0.1));
        }
      }
      continue;
    }
    const so = uu < -25; // monte del lado suroeste: más árboles blancos y lapachos
    const tipo = R();
    const pSeco = (so ? 0.13 : 0.05) * (0.5 + fbm2(uu / 60, vv / 60, 2));
    const pLap = so ? 0.02 * sstep(0.45, 0.7, fbm2(uu / 120 + 3, vv / 120, 2)) * 3 : 0.004;
    const chico = enLoteo && (enEtapa1(uu, vv) || en02bajo(uu, vv)) ? 0.62 : 1;
    const hc = (10 + 7 * fbm2(uu / 140 + 9, vv / 140 + 2, 3)) * chico;
    if (tipo < pSeco) { const h = hc * (0.9 + R() * 0.5); pon(secos, Math.floor(R() * 3), uu, vv, [h * 0.9, h * 0.9], h, variar(cSeco, R, 0.07)); continue; }
    const h = hc * (0.75 + R() * 0.5) * (R() < 0.03 ? 1.35 : 1);
    const w = (5.5 + R() * 5.5) * Math.sqrt(chico);
    let col;
    if (tipo < pSeco + pLap) col = variar(cLap[Math.floor(R() * 2)], R, 0.08);
    else { const z = fbm2(uu / 70 + 5, vv / 70 + 8, 3) + (R() - .5) * 0.35; col = variar(pal[Math.max(0, Math.min(pal.length - 1, Math.floor(z * pal.length * 1.1 - 0.4)))], R, 0.1); }
    pon(copas, Math.floor(R() * 5), uu, vv, [w, w * (0.85 + R() * 0.3)], h, col, 0.5);
  }
  // --- matas y pastizal alto en el desmonte
  const cMata = ['#56662c', '#6a7733', '#7f7f45', '#465626', '#8a8456', '#5f6c3a'].map(lin);
  for (let v = -120; v < 412; v += 2.6) for (let u = -40; u < 520; u += 2.6) {
    const uu = u + (R() - .5) * 2.4, vv = v + (R() - .5) * 2.4;
    const a = lee(uu, vv, 3); if (a < 0.55) continue;
    if (lee(uu, vv, 0) > 0.01 || lee(uu, vv, 2) > 0.45) continue;
    const e1 = enEtapa1(uu, vv);
    let p = e1 ? 0.2 : 0.32; if (en02bajo(uu, vv)) p = 0.6;
    if (estado === 'proyecto' && !e1) p = 0.1;
    p *= 0.6 + 0.8 * fbm2(uu / 18, vv / 18, 2);
    if (R() > p) continue;
    const s = (e1 ? 0.7 + R() * 2.2 : 1.2 + R() * 2.8), sy = s * (0.5 + R() * 0.6);
    pon(matas, Math.floor(R() * 4), uu, vv, [s, s * (0.8 + R() * 0.4)], sy, variar(cMata[Math.floor(R() * cMata.length)], R, 0.12), 0.15);
  }
  // --- piedra basáltica que asoma en el mirador (isla B3)
  const isla = L.rotonda.isla_lote_B3.poligono_plano; const bi = bbox(isla);
  const lajas = new Lote([0, 1].map(k => { const g = blob(1, 131 + k, { sy: 0.32, rough: 0.6, det: 1 }); colorear(g, () => [1, 1, 1]); return g; }), roca);
  for (let k = 0; k < 22; k++) { const a = R() * 6.28, d = R() * 15; const s = 3 + R() * 5; pon(lajas, k, C.ROT[0] + Math.cos(a) * d, C.ROT[1] + Math.sin(a) * d, [s, s * (0.6 + R() * 0.5)], 1.5 + R() * 1.6, variar(lin('#544a44'), R, 0.15), 0.9); }
  for (let k = 0; k < 160; k++) {
    const u = bi[0] + R() * (bi[2] - bi[0]), v = bi[1] + R() * (bi[3] - bi[1]);
    if (!inPoly([u, v], isla)) continue;
    const dc = Math.hypot(u - C.ROT[0], v - C.ROT[1]); if (dc > 15 && R() < 0.7) continue;
    const s = 0.8 + R() * (dc < 10 ? 4.2 : 1.8);
    pon(piedras, Math.floor(R() * 3), u, v, [s * (0.8 + R() * 0.5), s], s * (0.5 + R() * 0.4), variar(lin('#57504a'), R, 0.18), s * 0.22);
  }
  for (const lt of [pinos, copas, copasL, sueltos, secos, matas, piedras, lajas]) for (const m of lt.meshes()) grupo.add(m);
  grupo.userData.cuenta = { pinos: pinos.count, monte: copas.count, monte_margen: copasL.count, sueltos: sueltos.count, secos: secos.count, matas: matas.count, piedras: piedras.count };
  return grupo;
}
