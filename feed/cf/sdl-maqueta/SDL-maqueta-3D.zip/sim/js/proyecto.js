// proyecto.js: obras del PROYECTO FUTURO (se activan con "obras": "totems" en config o ?obras=totems).
//   1. Tótem del pueblo sobre el camino público largo (monolito de arenisca roja, letras doradas y flecha hacia el loteo).
//   2. Portal de ingreso en la esquina A: dos pilares de piedra con dintel "SOLARES DE LORETO" / "LOTEO" y luces cálidas al pie.
//      En este estado se saca el cartel de venta de madera.
//   3. Mirador en la isla B3: plazoleta de piedra con borde de basalto, árbol grande, dos bancos de piedra y el Cristo
//      con los brazos abiertos sobre pedestal, mirando hacia el arroyo Yabebirí.
// Todo se configura en config.json -> "proyecto" (posiciones en el marco del plano, rumbos en grados de brújula: 0 norte, 90 este).
import * as THREE from 'three';
import { mergeGeometries, mergeVertices } from 'three/addons/utils/BufferGeometryUtils.js';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { TTFLoader } from 'three/addons/loaders/TTFLoader.js';
import { Font } from 'three/addons/loaders/FontLoader.js';
import { toWorld, toPlan, C, ROT } from './geo.js';
import { altura, MK } from './terrain.js';
import { rng, sstep, clamp } from './k.js';
import { NOISE, fbm2 } from './glsl.js';
import { OW, OH, VERT } from './core.js';
import { BokehPass } from 'three/addons/postprocessing/BokehPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';

const D2R = Math.PI / 180;
export const DEF = {
  totem_pueblo: { plano: [-270, 397.6], rumbo: 291, lineas: ['SOLARES', 'DE', 'LORETO'], flecha: true },
  portal: { plano: [-7, 395.0], rumbo: 326, titulo: 'SOLARES DE LORETO', sub: 'LOTEO', luces: true },
  mirador: { rumbo_cristo: 56, cristo_alto: 5.0, arbol: true, bancos: true },
  textos: {
    titulo: { desde: 0.6, hasta: 5.4, texto: 'Solares de Loreto' },
    cierre: { desde: 35.8, titulo: 'Solares de Loreto', sub: 'Loreto, Misiones' },
    aviso: 'Imagen ilustrativa del proyecto', acento: '#F0D060',
  },
};
const mezclar = (a, b) => { const o = { ...a }; for (const k in b || {}) o[k] = (b[k] && typeof b[k] === 'object' && !Array.isArray(b[k])) ? mezclar(a[k] || {}, b[k]) : b[k]; return o; };
// rumbo de brújula -> giro de three (el frente del objeto es +Z local; +X local queda a la derecha de quien lo mira de frente)
const angPlano = rumbo => (56 - rumbo) * D2R;
const giro = rumbo => angPlano(rumbo) + ROT + Math.PI / 2;
// punto local (lx, lz) de un objeto en (u, v) con rumbo -> plano
function localAPlano(u, v, rumbo, lx, lz) { const a = angPlano(rumbo), c = Math.cos(a), s = Math.sin(a); return [u + lz * c - lx * s, v + lz * s + lx * c]; }
function sueloPlano(u, v) { const [x, y] = toWorld(u, v); return altura(x, y); }
function huella(u, v, rumbo, w, d, n = 4) { // min y max del relieve bajo una huella w x d
  let lo = 1e9, hi = -1e9;
  for (let i = 0; i <= n; i++) for (let j = 0; j <= n; j++) { const [pu, pv] = localAPlano(u, v, rumbo, (i / n - .5) * w, (j / n - .5) * d); const h = sueloPlano(pu, pv); lo = Math.min(lo, h); hi = Math.max(hi, h); }
  return [lo, hi];
}

// ---------------------------------------------------------------- materiales
// Piedra procedural (sillería, solado, liso de estatua). Coordenadas del objeto (sin escala), triplanar simple,
// color por bloque, pátina, líquenes, humedad al pie y relieve de juntas (normal perturbada por derivadas de pantalla).
const PIEDRA = { bloques: 0, liso: 1, solado: 2 };
function matPiedra(key, o) {
  const U = {
    uC1: { value: new THREE.Color(o.c1) }, uC2: { value: new THREE.Color(o.c2) }, uJ: { value: new THREE.Color(o.junta || '#3a2c24') },
    uB: { value: new THREE.Vector3(...(o.bloque || [0.7, 0.35]), o.anchoJunta ?? 0.012) },
    uRot: { value: o.rotY || 0 }, uModo: { value: PIEDRA[o.modo || 'bloques'] }, uRel: { value: o.relieve ?? 1 }, uPat: { value: o.patina ?? 1 },
    uSuelo: { value: o.suelo ?? 0 }, uEsc: { value: o.escalaRuido ?? 1 },
  };
  const m = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: o.rough ?? 0.9, metalness: 0 });
  m.onBeforeCompile = sh => {
    Object.assign(sh.uniforms, U);
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWP2;varying vec3 vWN2;')
      .replace('#include <project_vertex>', '#include <project_vertex>\n vWP2=(modelMatrix*vec4(transformed,1.)).xyz; vWN2=normalize(mat3(modelMatrix)*objectNormal);');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>
uniform vec3 uC1,uC2,uJ,uB;uniform float uRot,uModo,uRel,uPat,uSuelo,uEsc;
varying vec3 vWP2;varying vec3 vWN2;
${NOISE}
float hP=0.;
float hb(float r,float c,float sd){return h21(vec2(r*1.37+sd,c*0.71-sd));}
// sillería irregular: hiladas de alto fijo, juntas verticales corridas al azar (bloques de largo variable)
vec4 bloque(vec2 q,vec2 bs,float sd){
 float P2=bs.y*2.,y2=q.y/P2,r2=floor(y2),f2=(y2-r2)*P2,h1=bs.y*(0.78+0.44*h11(r2*3.1+sd));
 float row=r2*2.+step(h1,f2);float fy=f2<h1?f2:f2-h1;float bh=f2<h1?h1:P2-h1;
 float x=q.x/bs.x+h11(row*7.13+sd)*3.;float c0=floor(x),f=x-c0;
 float sL=(hb(row,c0,sd)-.5)*.6,sR=(hb(row,c0+1.,sd)-.5)*.6;float id,e;
 if(f<sL){id=c0-1.;float sLL=(hb(row,c0-1.,sd)-.5)*.6;e=min(f-(sLL-1.),sL-f);}
 else if(f>1.+sR){id=c0+1.;float sRR=(hb(row,c0+2.,sd)-.5)*.6;e=min(f-(1.+sR),(2.+sRR)-f);}
 else{id=c0;e=min(f-sL,1.+sR-f);}
 e=min(e*bs.x,min(fy,bh-fy));
 return vec4(e,h21(vec2(id,row)+sd),h21(vec2(row,id)*1.7+sd+3.),row);}
`).replace('#include <color_fragment>', `#include <color_fragment>
 {float c=cos(uRot),s=sin(uRot);
  vec3 p=vWP2;p.xz=vec2(c*p.x-s*p.z,s*p.x+c*p.z);
  vec3 nn=vWN2;nn.xz=vec2(c*nn.x-s*nn.z,s*nn.x+c*nn.z);nn=abs(nn);
  vec2 q;float top=0.;
  if(nn.y>0.72){q=p.xz;top=1.;}else if(nn.x>nn.z)q=vec2(p.z,p.y);else q=vec2(p.x,p.y);
  vec3 pe=p*uEsc;
  float n1=fbm3(pe*1.7),n2=vn3(pe*9.),n3=fbm3(pe*.35+3.),n4=fbm3(pe*4.2+1.),n5=fbm3(pe*.9+7.);
  vec4 b=vec4(1.,.5,.5,0.);
  if(uModo<.5)b=bloque(q,top>.5?vec2(uB.x,uB.x*.8):uB.xy,0.);
  else if(uModo>1.5&&top>.5)b=bloque(q,uB.xy,5.);
  float e=b.x,jw=uB.z;
  vec3 col=mix(uC1,uC2,clamp(b.y*.9+(n3-.5)*.8,0.,1.));
  col*=0.78+0.34*n1+(n2-.5)*.10+(n4-.5)*.14;
  // pátina gris oscura de la piedra vieja (como las ruinas), líquenes claros, chorreado y humedad al pie
  float pg=smoothstep(.42,.72,n5+(b.z-.5)*.35);col=mix(col,vec3(dot(col,vec3(.3,.59,.11)))*vec3(.74,.72,.70),clamp(pg*.5*uPat,0.,.8));
  float lq=smoothstep(.64,.72,fbm3(pe*2.3+11.));col=mix(col,col*1.25+vec3(.04,.04,.025),lq*.4*uPat);
  float pt=smoothstep(.45,.8,fbm3(vec3(pe.x*3.,pe.y*.5,pe.z*3.)+5.));col*=1.-pt*.30*uPat*(1.-top*.6);
  float hum=1.-smoothstep(0.,1.1,vWP2.y-uSuelo);col*=1.-hum*.35*uPat;
  float jn=(uModo>.5&&uModo<1.5)?0.:1.-smoothstep(jw*.4,jw,e+(n2-.5)*.006);
  if(uModo>1.5&&top<.5)jn=0.;
  float borde=1.-smoothstep(0.,0.07,e);
  col*=1.-borde*.22*(1.-jn);
  col=mix(col,uJ*(0.75+0.5*n1),jn);
  diffuseColor.rgb=col;
  hP=-jn*0.008-borde*borde*0.014+((n2-.5)*0.003+(n4-.5)*0.008)*uRel;}
`).replace('#include <normal_fragment_maps>', `#include <normal_fragment_maps>
 {vec3 sp=-vViewPosition;vec3 sX=dFdx(sp),sY=dFdy(sp);vec3 R1=cross(sY,normal),R2=cross(normal,sX);float fD=dot(sX,R1)*faceDirection;
  vec2 dH=vec2(dFdx(hP),dFdy(hP));vec3 g=sign(fD)*(dH.x*R1+dH.y*R2);normal=normalize(abs(fD)*normal-g);}`);
  };
  m.customProgramCacheKey = () => 'piedra:' + key;
  m.userData.u = U;
  return m;
}
// follaje (mismo criterio que veg.js: grumos de hojas por ruido de mundo)
function matFollaje() {
  const m = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.9, metalness: 0 });
  m.onBeforeCompile = sh => {
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vW;').replace('#include <project_vertex>', '#include <project_vertex>\nvW=(modelMatrix*vec4(transformed,1.)).xyz;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nvarying vec3 vW;\n' + NOISE)
      .replace('#include <color_fragment>', `#include <color_fragment>
 float g1=vn3(vW*1.6),g2=vn3(vW*5.2+7.),g3=vn3(vW*13.+2.);
 diffuseColor.rgb*=.5+.62*(g1*.55+g2*.3+g3*.15);
 diffuseColor.rgb*=mix(.45,1.,smoothstep(.22,.62,g1*.7+g3*.3));`)
      .replace('#include <normal_fragment_maps>', `#include <normal_fragment_maps>
 {float e=.3;vec3 q=vW*3.4;vec3 gr=vec3(vn3(q+vec3(e,0,0))-vn3(q-vec3(e,0,0)),vn3(q+vec3(0,e,0))-vn3(q-vec3(0,e,0)),vn3(q+vec3(0,0,e))-vn3(q-vec3(0,0,e)));
  normal=normalize(normal+(viewMatrix*vec4(gr*1.6,0.)).xyz);}`);
  };
  m.customProgramCacheKey = () => 'proy-follaje';
  return m;
}

// ---------------------------------------------------------------- geometrías
const nz = g => { g = g.index ? g.toNonIndexed() : g; for (const k of Object.keys(g.attributes)) if (k !== 'position' && k !== 'normal') g.deleteAttribute(k); if (!g.attributes.normal) g.computeVertexNormals(); return g; };
const rbox = (w, h, d, x, y, z, r = 0.04) => { const g = new RoundedBoxGeometry(w, h, d, 2, Math.min(r, w / 2.2, h / 2.2, d / 2.2)); g.translate(x, y, z); return nz(g); };
function cil(a, b, r0, r1, seg = 12, cerrado = true) {
  const A = new THREE.Vector3(...a), B = new THREE.Vector3(...b), d = B.clone().sub(A), L = d.length();
  const g = new THREE.CylinderGeometry(r1, r0, L, seg, 1, !cerrado); g.translate(0, L / 2, 0);
  g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.normalize())); g.translate(...a); return nz(g);
}
const esfera = (r, sx, sy, sz, x, y, z, seg = 20) => { const g = new THREE.SphereGeometry(r, seg, Math.round(seg * 0.7)); g.scale(sx, sy, sz); g.translate(x, y, z); return nz(g); };
function blob(r, seed, { det = 3, rough = 0.3, sy = 0.75 } = {}) {
  let g = new THREE.IcosahedronGeometry(r, det); g.deleteAttribute('normal'); g.deleteAttribute('uv'); g = mergeVertices(g);
  const p = g.attributes.position, R = rng(seed), o = [R() * 9, R() * 9];
  for (let i = 0; i < p.count; i++) { const x = p.getX(i), y = p.getY(i), z = p.getZ(i); const n = fbm2(x / r * 1.4 + o[0] + z / r * .7, y / r * 1.4 + o[1] + z / r * .4, 3); const k = 1 + (n - .5) * 2 * rough; p.setXYZ(i, x * k, y * k * sy, z * k); }
  g.computeVertexNormals(); return g;
}
function colorear(g, f) { const p = g.attributes.position, c = new Float32Array(p.count * 3); for (let i = 0; i < p.count; i++) { const k = f(p.getX(i), p.getY(i), p.getZ(i)); c.set(k, i * 3); } g.setAttribute('color', new THREE.BufferAttribute(c, 3)); return g; }

// letras 3D con espaciado (Montserrat SemiBold, instancia estática de la variable)
function texto3D(font, str, size, depth, track = 0.06) {
  const geos = []; let x = 0; const res = font.data.resolution;
  for (const ch of str) {
    const gl = font.data.glyphs[ch] || font.data.glyphs['?'];
    if (ch !== ' ') {
      const g = new THREE.ExtrudeGeometry(font.generateShapes(ch, size), { depth, bevelEnabled: true, bevelThickness: depth * 0.3, bevelSize: size * 0.012, bevelSegments: 2, curveSegments: 8 });
      g.translate(x, 0, 0); geos.push(nz(g));
    }
    x += gl.ha * size / res + track * size;
  }
  x -= track * size; const g = mergeGeometries(geos); g.translate(-x / 2, 0, 0); return g;
}
function flecha(largo, alto, depth, dir = 1) { // flecha de chapa
  const s = new THREE.Shape(), h = alto / 2, cu = alto * 0.16, pu = alto * 0.95;
  const P = [[-largo / 2, -cu], [largo / 2 - pu, -cu], [largo / 2 - pu, -h], [largo / 2, 0], [largo / 2 - pu, h], [largo / 2 - pu, cu], [-largo / 2, cu]].map(([x, y]) => [x * dir, y]);
  s.moveTo(...P[0]); for (const p of P.slice(1)) s.lineTo(...p); s.closePath();
  return nz(new THREE.ExtrudeGeometry(s, { depth, bevelEnabled: true, bevelThickness: depth * .3, bevelSize: 0.012, bevelSegments: 2 }));
}

// Cristo con los brazos abiertos (alto del modelo base: 5,0 m; el frente es +Z)
function geoCristo(H) {
  const k = H / 5.0, G = [];
  // túnica: torno con pliegues verticales que se abren hacia el pie
  const prof = [[0.001, 0], [0.64, 0], [0.665, 0.07], [0.63, 0.32], [0.575, 0.9], [0.53, 1.6], [0.49, 2.3], [0.455, 2.82], [0.425, 3.02], [0.46, 3.32], [0.51, 3.72], [0.535, 4.0], [0.5, 4.2], [0.38, 4.33], [0.2, 4.4], [0.11, 4.47], [0.001, 4.5]];
  const curva = new THREE.CatmullRomCurve3(prof.map(([r, y]) => new THREE.Vector3(r, y, 0)), false, 'centripetal');
  const pts = curva.getPoints(90).map(p => new THREE.Vector2(Math.max(0.001, p.x), p.y));
  let tun = new THREE.LatheGeometry(pts, 72); tun.deleteAttribute('uv'); tun.deleteAttribute('normal'); tun = mergeVertices(tun);
  const p = tun.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i), z = p.getZ(i), r = Math.hypot(x, z); if (r < 0.01) continue;
    const th = Math.atan2(z, x);
    const amp = 0.05 * (1 - sstep(0.1, 3.0, y)) + 0.01 * (1 - sstep(3.0, 3.9, y));
    const f = Math.sin(th * 11 + 1.4 * Math.sin(th * 3 + 0.7) + y * 0.4) * 0.65 + Math.sin(th * 23 + y * 0.9) * 0.35;
    const rr = r * (1 + amp * f);
    const tor = sstep(2.6, 3.6, y); // de la cintura para arriba: más ancho que profundo (hombros)
    const sx = 1.03 + 0.2 * tor, sz = 0.92 - 0.17 * tor;
    p.setXYZ(i, Math.cos(th) * rr * sx, y, Math.sin(th) * rr * sz);
  }
  tun.computeVertexNormals(); G.push(nz(tun));
  G.push(nz(new THREE.TorusGeometry(0.44, 0.035, 10, 64).rotateX(Math.PI / 2).scale(1.1, 1, 0.84).translate(0, 3.03, 0))); // cordón
  G.push(nz(new THREE.TorusGeometry(0.2, 0.045, 10, 40).rotateX(Math.PI / 2).scale(1.15, 1, 0.9).translate(0, 4.36, 0.0))); // cuello de la túnica
  for (const s of [-1, 1]) {
    // brazo: hombro -> codo -> muñeca, apenas caído
    const hom = [s * 0.4, 4.16, 0], codo = [s * 1.3, 4.14, 0.02], mun = [s * 2.2, 4.1, 0.04];
    G.push(esfera(0.22, 1, 0.95, 0.9, ...hom), cil(hom, codo, 0.2, 0.16, 18), esfera(0.16, 1, 1, 1, ...codo), cil(codo, mun, 0.16, 0.115, 18));
    // manga que cuelga bajo el brazo hasta la cintura (da la silueta en T con caída)
    const sh = new THREE.Shape(); const X = v => v * s;
    sh.moveTo(X(0.36), 4.12); sh.lineTo(X(1.35), 4.06); sh.quadraticCurveTo(X(1.95), 4.02, X(2.1), 3.98);
    sh.quadraticCurveTo(X(1.7), 3.72, X(1.0), 3.42); sh.quadraticCurveTo(X(0.62), 3.25, X(0.4), 3.22); sh.closePath();
    const mg = new THREE.ExtrudeGeometry(sh, { depth: 0.26, bevelEnabled: true, bevelThickness: 0.09, bevelSize: 0.05, bevelSegments: 3, curveSegments: 16 });
    mg.translate(0, 0, -0.16); G.push(nz(mg));
    // mano abierta, palma al frente
    G.push(esfera(0.13, 1.35, 0.8, 0.45, s * 2.36, 4.09, 0.05), esfera(0.05, 0.9, 1.6, 0.9, s * 2.27, 4.0, 0.08)); // palma y pulgar
  }
  // cabeza apenas inclinada hacia adelante
  const cab = [cil([0, 4.4, 0], [0, 4.66, 0.01], 0.1, 0.095, 14),
    esfera(0.205, 0.86, 1.12, 0.96, 0, 4.8, 0.025),             // cara
    esfera(0.22, 0.98, 1.22, 0.9, 0, 4.8, -0.05),             // pelo
    esfera(0.15, 0.62, 1.5, 0.62, -0.13, 4.6, -0.07), esfera(0.15, 0.62, 1.5, 0.62, 0.13, 4.6, -0.07), // pelo sobre los hombros
    esfera(0.105, 0.86, 1.08, 0.8, 0, 4.64, 0.09),              // barba
    esfera(0.03, 0.7, 1.3, 1, 0, 4.78, 0.19)];                  // nariz
  for (const g of cab) { g.translate(0, -4.5, 0); g.rotateX(0.14); g.translate(0, 4.5, 0); G.push(g); }
  for (const s of [-1, 1]) G.push(esfera(0.1, 1, 0.55, 1.7, s * 0.15, 0.05, 0.6)); // pies
  const g = mergeGeometries(G); g.scale(k, k, k); return g;
}
// árbol grande de la plazoleta (~11 m): tronco con ramas abiertas y copa de grumos
function geoArbol(seed) {
  const R = rng(seed), T = [], F = [];
  T.push(cil([0, -0.4, 0], [0.15, 3.4, 0.05], 0.42, 0.3, 14));
  const ramas = 6;
  for (let i = 0; i < ramas; i++) {
    const a = i / ramas * 6.283 + R() * 0.6, lv = 2.6 + R() * 1.6, up = 3.0 + R() * 2.2;
    const b0 = [0.15, 3.1 + R() * 0.4, 0.05], b1 = [Math.cos(a) * lv * .55, b0[1] + up * .55, Math.sin(a) * lv * .55], b2 = [Math.cos(a + .25) * lv, b0[1] + up, Math.sin(a + .25) * lv];
    T.push(cil(b0, b1, 0.2, 0.14, 9), cil(b1, b2, 0.14, 0.07, 7));
    for (let j = 0; j < 2; j++) { const c = [b2[0] + (R() - .5) * 1.6, b2[1] + R() * 1.4, b2[2] + (R() - .5) * 1.6]; T.push(cil(b2, c, 0.07, 0.03, 5)); }
  }
  for (let i = 0; i < 34; i++) {
    const a = R() * 6.283, d = i < 4 ? R() * 1.5 : 1.8 + Math.sqrt(R()) * 4.2, r = 1.0 + R() * 0.9;
    const b = blob(r, seed * 17 + i, { det: 3, rough: 0.45, sy: 0.72 }); b.translate(Math.cos(a) * d, 7.4 + R() * 2.6 - d * 0.2, Math.sin(a) * d); F.push(b);
  }
  const tr = mergeGeometries(T.map(g => { g = nz(g); return colorear(g, (x, y) => { const k = 0.075 + 0.03 * sstep(0, 3, y); return [k * 1.15, k * 0.9, k * 0.68]; }); }));
  const base = [new THREE.Color('#465c26'), new THREE.Color('#57702c'), new THREE.Color('#6b8236'), new THREE.Color('#4b6324'), new THREE.Color('#7b8a3c')];
  const fo = mergeGeometries(F.map((g, i) => { const c = base[i % base.length]; return colorear(nz(g), (x, y) => { const ao = 0.42 + 0.58 * sstep(6.2, 10.4, y); return [c.r * ao, c.g * ao, c.b * ao]; }); }));
  return [tr, fo];
}
function geoMatas(seed) { // matas de pasto (hojas finas)
  const R = rng(seed), G = [];
  for (let i = 0; i < 34; i++) {
    const a = R() * 6.283, h = 0.25 + R() * 0.5, w = 0.012 + R() * 0.01, lean = 0.08 + R() * 0.25, b = R() * 6.283;
    const x0 = Math.cos(a) * R() * 0.12, z0 = Math.sin(a) * R() * 0.12;
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute([x0 - Math.cos(b) * w, 0, z0 - Math.sin(b) * w, x0 + Math.cos(b) * w, 0, z0 + Math.sin(b) * w, x0 + Math.cos(a) * lean, h, z0 + Math.sin(a) * lean], 3));
    g.computeVertexNormals(); const sec = R() < 0.35; G.push(colorear(g, (x, y) => { const t = y / 0.75; return sec ? [0.08 + 0.22 * t, 0.06 + 0.16 * t, 0.025 + 0.05 * t] : [0.025 + 0.12 * t, 0.04 + 0.16 * t, 0.012 + 0.03 * t]; }));
  }
  return mergeGeometries(G);
}

// ---------------------------------------------------------------- suelo (antes de plantar el monte)
function pintar(mask, u, v, r, canal, val, suave = 0.5) {
  const res = MK.size / MK.N, d = mask.tex.image.data, N = MK.N;
  const x0 = Math.floor((u - r - MK.u0) / res), x1 = Math.ceil((u + r - MK.u0) / res), y0 = Math.floor((MK.v1 - v - r) / res), y1 = Math.ceil((MK.v1 - v + r) / res);
  for (let y = Math.max(0, y0); y <= Math.min(N - 1, y1); y++) for (let x = Math.max(0, x0); x <= Math.min(N - 1, x1); x++) {
    const pu = MK.u0 + (x + .5) * res, pv = MK.v1 - (y + .5) * res; const dd = Math.hypot(pu - u, pv - v) / r; if (dd > 1) continue;
    const w = 1 - sstep(1 - suave, 1, dd); const i = (y * N + x) * 4 + canal; d[i] = Math.max(d[i], Math.round(val * 255 * w));
  }
  mask.tex.needsUpdate = true;
}
export function prepararSuelo(mask, cfg) {
  const P = mezclar(DEF, cfg.proyecto);
  const [tu, tv] = P.totem_pueblo.plano;
  pintar(mask, tu, tv, 21, 3, 1, 0.55);          // claro de pasto alrededor del tótem
  pintar(mask, tu, tv, 3.2, 2, 0.95, 0.5);       // tierra colorada de la cimentación
  const [pu, pv] = P.portal.plano;
  for (const s of [-1, 1]) { const [a, b] = localAPlano(pu, pv, P.portal.rumbo, s * 5.6, 0); pintar(mask, a, b, 2.4, 2, 0.8, 0.6); }
}

// ---------------------------------------------------------------- obras
export async function armarObras({ scene, cfg, L, veg, ut, core, sunDir }) {
  const P = mezclar(DEF, cfg.proyecto);
  const G = new THREE.Group(); scene.add(G);
  const font = new Font(await new Promise((ok, mal) => new TTFLoader().load('fonts/Montserrat-SemiBold.ttf', ok, undefined, mal)));
  const oro = new THREE.MeshStandardMaterial({ color: '#D4AF37', metalness: 1, roughness: 0.42, envMapIntensity: 1.2 });
  const chapa = new THREE.MeshStandardMaterial({ color: '#c9a23a', metalness: 1, roughness: 0.38, envMapIntensity: 2.0 });
  const sombras = m => { m.castShadow = true; m.receiveShadow = true; return m; };
  const exc = []; // zonas donde se saca el monte instanciado (plano: u, v, radio)
  const mat = { };
  const arenisca = (key, rotY, suelo, extra = {}) => matPiedra(key, { c1: '#6f4334', c2: '#94604a', junta: '#4a3429', bloque: [1.15, 0.5], anchoJunta: 0.007, patina: 1.25, rotY, suelo, rough: 0.92, ...extra });
  const basalto = (key, rotY, suelo, extra = {}) => matPiedra(key, { c1: '#2c2a29', c2: '#45403c', junta: '#1b1918', bloque: [0.9, 0.45], anchoJunta: 0.012, rotY, suelo, rough: 0.85, patina: 0.5, ...extra });

  // ---------- 1. tótem del pueblo
  {
    const T = P.totem_pueblo, [u, v] = T.plano, ry = giro(T.rumbo);
    const [lo] = huella(u, v, T.rumbo, 3.4, 1.8), y0 = lo - 0.06;
    const g = new THREE.Group();
    g.add(sombras(new THREE.Mesh(rbox(3.3, 1.35, 1.75, 0, -0.125, 0, 0.05), basalto('tp-base', ry, y0, { bloque: [1.1, 0.55] }))));
    g.add(sombras(new THREE.Mesh(rbox(2.6, 4.3, 1.0, 0, 0.55 + 2.15, 0, 0.035), arenisca('tp-mono', ry, y0))));
    g.add(sombras(new THREE.Mesh(rbox(2.85, 0.26, 1.2, 0, 4.98, 0, 0.04), arenisca('tp-cap', ry, y0, { c1: '#7d4430', c2: '#95583f', bloque: [2.0, 0.3] }))));
    g.add(sombras(new THREE.Mesh(rbox(2.24, 1.5, 0.08, 0, 3.98, 0.52, 0.02), basalto('tp-placa', ry, y0, { modo: 'liso', c1: '#262321', c2: '#34302c', patina: 0.25 }))));
    const lin = T.lineas, tam = [0.29, 0.18, 0.29], yb = [4.3, 3.95, 3.52];
    lin.forEach((s, i) => { const tg = texto3D(font, s, tam[i] ?? 0.3, 0.035, 0.07); tg.translate(0, yb[i] ?? 3.5 - i * 0.4, 0.565); g.add(sombras(new THREE.Mesh(tg, oro))); });
    const fl = flecha(1.5, 0.42, 0.035, -1); fl.translate(0, 2.55, 0.505); if (T.flecha !== false) g.add(sombras(new THREE.Mesh(fl, chapa)));
    const linea = rbox(1.9, 0.025, 0.02, 0, 3.15, 0.515, 0.008); g.add(new THREE.Mesh(linea, oro));
    const [x, y] = toWorld(u, v); g.position.set(x, y0, -y); g.rotation.y = ry; G.add(g);
    exc.push([u, v, 19]);
    mat.totem = g;
  }
  // ---------- 2. portal
  {
    const T = P.portal, [u, v] = T.plano, ry = giro(T.rumbo);
    const [lo] = huella(u, v, T.rumbo, 13.5, 2.4, 6), y0 = lo - 0.05;
    const g = new THREE.Group();
    const mA = arenisca('po-pil', ry, y0), mB = basalto('po-base', ry, y0, { bloque: [1.05, 0.5] }), mC = arenisca('po-cap', ry, y0, { c1: '#7b432f', c2: '#93573e', bloque: [2.2, 0.3] });
    const pil = [], bas = [], cap = [];
    for (const s of [-1, 1]) {
      const X = s * 5.6;
      bas.push(rbox(2.15, 1.3, 2.15, X, -0.15, 0, 0.05));
      pil.push(rbox(1.6, 4.6, 1.6, X, 0.5 + 2.3, 0, 0.035));
      cap.push(rbox(1.95, 0.25, 1.95, X, 5.225, 0, 0.04));
      // alas bajas de piedra que abren hacia afuera
      const wl = new RoundedBoxGeometry(4.4, 1.6, 0.62, 2, 0.04); wl.translate(0, 0.25, 0); wl.rotateY(s * 0.42); wl.translate(X + s * (1.0 + 2.0 * Math.cos(0.42)), 0, -2.0 * Math.sin(0.42)); pil.push(nz(wl));
      const wc = new RoundedBoxGeometry(4.55, 0.16, 0.74, 2, 0.03); wc.translate(0, 1.13, 0); wc.rotateY(s * 0.42); wc.translate(X + s * (1.0 + 2.0 * Math.cos(0.42)), 0, -2.0 * Math.sin(0.42)); cap.push(nz(wc));
    }
    pil.push(rbox(13.1, 1.35, 1.1, 0, 5.35 + 0.675, 0, 0.04)); // dintel
    cap.push(rbox(13.4, 0.18, 1.3, 0, 6.79, 0, 0.03));
    g.add(sombras(new THREE.Mesh(mergeGeometries(pil), mA)), sombras(new THREE.Mesh(mergeGeometries(bas), mB)), sombras(new THREE.Mesh(mergeGeometries(cap), mC)));
    const t1 = texto3D(font, T.titulo, 0.5, 0.04, 0.1); t1.translate(0, 6.08, 0.55); g.add(sombras(new THREE.Mesh(t1, oro)));
    if (T.sub) { const t2 = texto3D(font, T.sub, 0.19, 0.03, 0.75); t2.translate(0, 5.6, 0.55); g.add(sombras(new THREE.Mesh(t2, oro))); }
    for (const s of [-1, 1]) { const ln = rbox(1.3, 0.02, 0.02, s * 1.45, 5.67, 0.56, 0.008); g.add(new THREE.Mesh(ln, oro)); }
    if (T.luces !== false) {
      const emi = new THREE.MeshStandardMaterial({ color: '#2a2622', emissive: '#ffb25e', emissiveIntensity: 5.5, roughness: 0.5 });
      const caja = new THREE.MeshStandardMaterial({ color: '#2b2826', roughness: 0.6, metalness: 0.5 });
      for (const s of [-1, 1]) for (const lz of [1.3]) {
        const X = s * 5.6;
        g.add(new THREE.Mesh(rbox(0.42, 0.16, 0.26, X, 0.06, lz, 0.02), caja));
        const lente = new THREE.Mesh(new THREE.PlaneGeometry(0.34, 0.18).rotateX(-0.9).translate(X, 0.15, lz - 0.02), emi); g.add(lente);
        const pl = new THREE.SpotLight('#ffb36b', 38, 9, 0.75, 0.6, 2); pl.position.set(X, 0.3, lz + 0.05); pl.target.position.set(X, 4.5, -0.1); g.add(pl, pl.target);
      }
    }
    const [x, y] = toWorld(u, v); g.position.set(x, y0, -y); g.rotation.y = ry; G.add(g);
    exc.push([u, v, 9], ...[-1, 1].map(s => [...localAPlano(u, v, T.rumbo, s * 9, -1.5), 4]));
    mat.portal = g;
    // matas de pasto al pie de los pilares y del tótem
    const matas = geoMatas(7), fm = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.92, side: THREE.DoubleSide });
    const R = rng(55), pos = [];
    for (const s of [-1, 1]) for (let i = 0; i < 70; i++) { const a = R() * 6.283, d = 1.3 + R() * 2.2; const [pu2, pv2] = localAPlano(u, v, T.rumbo, s * 5.6 + Math.cos(a) * d, Math.sin(a) * d); if (Math.abs(pu2 - C.SO) < 4.2) continue; pos.push([pu2, pv2, 0.5 + R() * 0.6]); }
    const [tu, tv] = P.totem_pueblo.plano;
    for (let i = 0; i < 420; i++) { const a = R() * 6.283, d = 1.9 + Math.sqrt(R()) * 9; const pu2 = tu + Math.cos(a) * d, pv2 = tv + Math.sin(a) * d; if (Math.abs(pv2 - C.NO) < 4.6) continue; pos.push([pu2, pv2, 0.45 + R() * 0.65]); }
    const im = new THREE.InstancedMesh(matas, fm, pos.length), m4 = new THREE.Matrix4(), q = new THREE.Quaternion();
    pos.forEach(([a, b, s], i) => { const [x2, y2] = toWorld(a, b); q.setFromEuler(new THREE.Euler(0, R() * 6.283, 0)); m4.compose(new THREE.Vector3(x2, altura(x2, y2) - 0.05, -y2), q, new THREE.Vector3(s, s * (0.8 + R() * 0.5), s)); im.setMatrixAt(i, m4); });
    im.receiveShadow = true; im.castShadow = false; im.frustumCulled = false; G.add(im);
  }
  // ---------- 3. mirador (isla B3)
  const MIR = {};
  {
    const T = P.mirador, [mu, mv] = C.ROT, isla = L.rotonda.isla_lote_B3.poligono_plano, rc = T.rumbo_cristo, ry = giro(rc);
    // plataforma de solado: rombo de la isla con 0,9 m de retiro, apenas elevada; borde de basalto
    const ins = isla.map(([a, b]) => { const dx = a - mu, dy = b - mv, l = Math.hypot(dx, dy); return [mu + dx * (l - 1.25) / l, mv + dy * (l - 1.25) / l]; });
    let lo = 1e9, hi = -1e9; for (let i = 0; i <= 12; i++) for (let j = 0; j <= 12; j++) { const a = mu + (i / 12 - .5) * 48, b = mv + (j / 12 - .5) * 48; if (Math.abs(a - mu) + Math.abs(b - mv) > 23) continue; const h = sueloPlano(a, b); lo = Math.min(lo, h); hi = Math.max(hi, h); }
    const top = hi + 0.22; MIR.top = top;
    const sh = new THREE.Shape(ins.map(([a, b]) => { const [x, y] = toWorld(a, b); return new THREE.Vector2(x, y); }));
    const pg = new THREE.ExtrudeGeometry(sh, { depth: top - lo + 0.8, bevelEnabled: false }); pg.rotateX(-Math.PI / 2); pg.translate(0, lo - 0.8, 0);
    const solado = matPiedra('solado', { modo: 'solado', c1: '#806b5b', c2: '#a08a77', junta: '#2e3121', bloque: [1.0, 0.65], anchoJunta: 0.024, rotY: ROT + Math.PI / 4, suelo: top - 2, rough: 0.9, patina: 0.6 });
    const plat = new THREE.Mesh(nz(pg), solado); plat.receiveShadow = true; plat.castShadow = false; G.add(plat);
    // cordón de basalto sobre el borde
    const R = rng(91), cord = [];
    for (let e = 0; e < 4; e++) {
      const a = ins[e], b = ins[(e + 1) % 4], Lg = Math.hypot(b[0] - a[0], b[1] - a[1]), n = Math.round(Lg / 1.12), ang = Math.atan2(b[1] - a[1], b[0] - a[0]);
      for (let i = 0; i < n; i++) {
        const f = (i + .5) / n, pu = a[0] + (b[0] - a[0]) * f, pv = a[1] + (b[1] - a[1]) * f, [x, y] = toWorld(pu, pv);
        const w = 1.04 + (R() - .5) * 0.06, g0 = sueloPlano(pu, pv), bot = g0 - 0.5, tp = top + 0.14 + (R() - .5) * 0.04, hg = tp - bot;
        const g = new RoundedBoxGeometry(w, hg, 0.55, 2, 0.06); g.rotateY(ang + ROT + (R() - .5) * 0.04); g.translate(x, bot + hg / 2, -y); cord.push(nz(g));
      }
    }
    G.add(sombras(new THREE.Mesh(mergeGeometries(cord), basalto('cordon', ROT + Math.PI / 4, top - 1, { modo: 'liso', c1: '#2e2b29', c2: '#47413c', escalaRuido: 1.4 }))));
    // lajas de basalto sueltas afuera de la plataforma (las que ya están en el lugar)
    const laj = [];
    for (let i = 0; i < 9; i++) {
      const ang = (i / 9) * 6.283 + R() * 0.5, d = 24.5 + R() * 2.2, pu = mu + Math.cos(ang) * d, pv = mv + Math.sin(ang) * d;
      const b = blob(1, 300 + i, { det: 2, rough: 0.5, sy: 0.35 }); b.scale(1.2 + R() * 1.2, 0.9 + R() * 0.6, 0.9 + R() * 0.8); b.rotateY(R() * 6.28);
      const [x, y] = toWorld(pu, pv); b.translate(x, sueloPlano(pu, pv) - 0.15, -y); laj.push(nz(b));
    }
    G.add(sombras(new THREE.Mesh(mergeGeometries(laj), basalto('lajas', 0, lo - 1, { modo: 'liso', c1: '#2b2826', c2: '#4b4540', escalaRuido: 1.2 }))));
    // Cristo sobre pedestal, al frente de la plaza (hacia el arroyo)
    const [cu, cv] = localAPlano(mu, mv, rc, 0, 4.5);
    const ped = new THREE.Group();
    ped.add(sombras(new THREE.Mesh(rbox(3.5, 0.42, 3.5, 0, 0.21, 0, 0.05), basalto('ped-base', ry, top))));
    ped.add(sombras(new THREE.Mesh(rbox(2.5, 1.6, 2.5, 0, 0.42 + 0.8, 0, 0.035), arenisca('ped-mid', ry, top, { c1: '#93553c', c2: '#b0735a' }))));
    ped.add(sombras(new THREE.Mesh(rbox(2.85, 0.22, 2.85, 0, 2.13, 0, 0.04), arenisca('ped-cap', ry, top, { c1: '#82472f', c2: '#9a5d43', bloque: [3, 0.3] }))));
    ped.add(sombras(new THREE.Mesh(rbox(1.75, 0.24, 1.75, 0, 2.36, 0, 0.04), arenisca('ped-top', ry, top, { c1: '#a7a091', c2: '#bdb5a4', bloque: [3, 0.3], patina: 0.4 }))));
    const piedraClara = matPiedra('cristo', { modo: 'liso', c1: '#cbc2b0', c2: '#ddd5c4', rotY: ry, suelo: top + 2.4, rough: 0.82, patina: 0.55, relieve: 0.6, escalaRuido: 1.6 });
    const cr = sombras(new THREE.Mesh(geoCristo(T.cristo_alto ?? 5.0), piedraClara)); cr.position.y = 2.48; ped.add(cr);
    const [px, py] = toWorld(cu, cv); ped.position.set(px, top - 0.02, -py); ped.rotation.y = ry; G.add(ped);
    MIR.cristo = [cu, cv, top + 2.48, top + 2.48 + (T.cristo_alto ?? 5.0)];
    // dos bancos de piedra delante del Cristo, mirando al arroyo
    if (T.bancos !== false) {
      const bg = [];
      for (const s of [-1, 1]) { bg.push(rbox(2.15, 0.16, 0.56, s * 3.3, 0.45, 11.0, 0.03), rbox(0.42, 0.4, 0.46, s * 3.3 - 0.72, 0.19, 11.0, 0.03), rbox(0.42, 0.4, 0.46, s * 3.3 + 0.72, 0.19, 11.0, 0.03)); }
      const bm = new THREE.Mesh(mergeGeometries(bg), arenisca('bancos', ry, top, { c1: '#9a5e44', c2: '#b4775b', bloque: [3, 0.6], patina: 0.5 }));
      const [bx, by] = toWorld(mu, mv); bm.position.set(bx, top - 0.01, -by); bm.rotation.y = ry; G.add(sombras(bm));
      MIR.bancos = [-1, 1].map(s => localAPlano(mu, mv, rc, s * 3.3, 11));
    }
    // árbol grande a un costado, con cantero de basalto
    if (T.arbol !== false) {
      const [au, av] = localAPlano(mu, mv, rc, 7.5, -5.5);
      const [tr, fo] = geoArbol(23), ag = new THREE.Group();
      ag.add(sombras(new THREE.Mesh(tr, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.95 }))));
      const fm = sombras(new THREE.Mesh(fo, matFollaje())); ag.add(fm);
      const ct = []; for (let i = 0; i < 16; i++) { const a = i / 16 * 6.283; const gg = new RoundedBoxGeometry(0.8, 0.34, 0.42, 2, 0.06); gg.rotateY(-a); gg.translate(Math.cos(a) * 2.1, 0.12, Math.sin(a) * 2.1); ct.push(nz(gg)); }
      ag.add(sombras(new THREE.Mesh(mergeGeometries(ct), basalto('cantero', 0, top, { modo: 'liso', c1: '#2f2c2a', c2: '#45403b' }))));
      const tierra = new THREE.Mesh(new THREE.CircleGeometry(1.95, 40).rotateX(-Math.PI / 2).translate(0, 0.035, 0), new THREE.MeshStandardMaterial({ color: '#4a2f22', roughness: 1 }));
      tierra.receiveShadow = true; ag.add(tierra);
      const [ax, ay] = toWorld(au, av); ag.position.set(ax, top, -ay); ag.rotation.y = 1.3; G.add(ag);
      MIR.arbol = [au, av];
    }
    exc.push([mu, mv, 27.5]);
  }
  // ---------- se saca el cartel de venta y el monte instanciado donde van las obras
  if (ut && ut.children.length >= 2) { ut.children[0].visible = false; ut.children[1].visible = false; }
  const m4 = new THREE.Matrix4(), pv = new THREE.Vector3(), cero = new THREE.Matrix4().makeScale(0, 0, 0);
  const excW = exc.map(([u, v, r]) => { const [x, y] = toWorld(u, v); return [x, -y, r * r]; });
  let sacados = 0;
  veg.traverse(o => {
    if (!o.isInstancedMesh) return;
    for (let i = 0; i < o.count; i++) { o.getMatrixAt(i, m4); pv.setFromMatrixPosition(m4); for (const [x, z, r2] of excW) if ((pv.x - x) ** 2 + (pv.z - z) ** 2 < r2) { o.setMatrixAt(i, cero); sacados++; break; } }
    o.instanceMatrix.needsUpdate = true;
  });
  // ---------- polvo en el aire (motas que brillan a contraluz)
  const polvo = [];
  {
    const sitios = [[...P.totem_pueblo.plano, 14, 7], [...P.portal.plano, 18, 9], [C.ROT[0], C.ROT[1], 26, 12]];
    const R = rng(404);
    for (const [u, v, rad, alto] of sitios) {
      const n = 900, pos = new Float32Array(n * 3), fase = new Float32Array(n); const [x, y] = toWorld(u, v), h = sueloPlano(u, v);
      for (let i = 0; i < n; i++) { const a = R() * 6.283, d = Math.sqrt(R()) * rad; pos[i * 3] = x + Math.cos(a) * d; pos[i * 3 + 1] = h + 0.3 + R() * alto; pos[i * 3 + 2] = -y + Math.sin(a) * d; fase[i] = R() * 100; }
      const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('fase', new THREE.BufferAttribute(fase, 1));
      const m = new THREE.ShaderMaterial({
        transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
        uniforms: { uT: { value: 0 }, uSol: { value: sunDir.clone() }, uEsc: { value: core.H / 1080 } },
        vertexShader: `attribute float fase;uniform float uT,uEsc;uniform vec3 uSol;varying float vA;
          void main(){vec3 p=position;p+=vec3(sin(uT*.23+fase)*.6,mod(uT*.05+fase*.37,1.)*.8-.4,cos(uT*.19+fase*1.3)*.6);
          vec4 mv=modelViewMatrix*vec4(p,1.);gl_Position=projectionMatrix*mv;float d=-mv.z;
          vec3 vd=normalize((modelMatrix*vec4(p,1.)).xyz-cameraPosition);float cl=pow(max(dot(vd,uSol),0.),3.);
          vA=(0.10+1.3*cl)*smoothstep(1.,4.,d)*(1.-smoothstep(25.,60.,d))*(.5+.5*sin(fase*3.1+uT*.7));
          gl_PointSize=clamp(uEsc*95./d,1.,7.);}`,
        fragmentShader: `varying float vA;void main(){vec2 c=gl_PointCoord-.5;float k=1.-smoothstep(.15,.5,length(c));gl_FragColor=vec4(vec3(1.,.86,.62)*k*vA*.55,1.);}`,
      });
      const pts = new THREE.Points(g, m); pts.frustumCulled = false; G.add(pts); polvo.push(m);
    }
  }
  window.__obras = { sacados, mirador: MIR, alt: (u, v) => sueloPlano(u, v) };
  // ---------- textos del video
  const TX = P.textos;
  function textos(ctx, t) {
    const S = VERT ? 1.5 : 1, M = (VERT ? 70 : 60);
    ctx.save(); ctx.textBaseline = 'alphabetic';
    const sombra = b => { ctx.shadowColor = 'rgba(0,0,0,0.55)'; ctx.shadowBlur = b; ctx.shadowOffsetY = 1; };
    // aviso fijo
    if (TX.aviso) {
      ctx.globalAlpha = 0.78; sombra(8); ctx.fillStyle = '#F5F5F0'; ctx.font = `500 ${Math.round(17 * S)}px Mont`; ctx.letterSpacing = `${(0.6 * S).toFixed(1)}px`; ctx.textAlign = 'right';
      ctx.fillText(TX.aviso, OW - M, VERT ? 1465 : OH - 40);
    }
    // título de apertura (chico)
    const ti = TX.titulo;
    if (ti) {
      const a = sstep(ti.desde, ti.desde + 0.9, t) * (1 - sstep(ti.hasta - 0.8, ti.hasta, t));
      if (a > 0.001) {
        ctx.globalAlpha = a; sombra(14); ctx.textAlign = 'left';
        const x = M, y = VERT ? 1290 : OH - 92, dy = (1 - a) * 8;
        ctx.fillStyle = TX.acento; ctx.fillRect(x, y - Math.round(40 * S) + dy, Math.round(46 * S), Math.max(2, Math.round(3 * S)));
        ctx.fillStyle = '#F5F5F0'; ctx.font = `600 ${Math.round(30 * S)}px Mont`; ctx.letterSpacing = `${(2.4 * S).toFixed(1)}px`; ctx.fillText(ti.texto.toUpperCase(), x, y + dy);
      }
    }
    // cierre
    const ci = TX.cierre;
    if (ci) {
      const a = sstep(ci.desde, ci.desde + 1.2, t);
      if (a > 0.001) {
        ctx.globalAlpha = a * 0.55; ctx.shadowBlur = 0; const gy = VERT ? 1180 : OH * 0.62;
        const gr = ctx.createLinearGradient(0, gy - 120 * S, 0, gy + 200 * S); gr.addColorStop(0, 'rgba(10,10,10,0)'); gr.addColorStop(0.5, 'rgba(10,10,10,0.55)'); gr.addColorStop(1, 'rgba(10,10,10,0)');
        ctx.fillStyle = gr; ctx.fillRect(0, gy - 120 * S, OW, 320 * S);
        ctx.globalAlpha = a; sombra(18); ctx.textAlign = 'center';
        const y = (VERT ? 1230 : OH * 0.69) + (1 - a) * 10;
        ctx.fillStyle = '#F5F5F0'; ctx.font = `600 ${Math.round((VERT ? 46 : 58) * S)}px Mont`; ctx.letterSpacing = `${(VERT ? 5 : 7) * S}px`;
        ctx.fillText(ci.titulo.toUpperCase(), OW / 2, y);
        const b = sstep(ci.desde + 0.5, ci.desde + 1.6, t); ctx.globalAlpha = b;
        ctx.fillStyle = TX.acento; const lw = Math.round(70 * S); ctx.fillRect(OW / 2 - lw / 2, y + 26 * S, lw, Math.max(2, Math.round(3 * S)));
        ctx.fillStyle = TX.acento; ctx.font = `500 ${Math.round((VERT ? 22 : 24) * S)}px Mont`; ctx.letterSpacing = `${(4 * S).toFixed(1)}px`;
        ctx.fillText(ci.sub.toUpperCase(), OW / 2, y + 26 * S + 46 * S);
      }
    }
    ctx.restore();
  }
  // ---------- lente: profundidad de campo (enfoca al objetivo de la toma o al "foco" de la toma) y etalonaje cálido con halo de sol
  const sec = (cfg.camaras || {})[cfg.secuencia || 'paneo'] || {};
  const DOF = { k: 0.12, maxblur: 0.009, ...(sec.dof || {}) };
  let bokeh = null;
  if (DOF.k > 0) {
    bokeh = new BokehPass(scene, core.cam, { focus: 20, aperture: DOF.k, maxblur: DOF.maxblur });
    bokeh.materialBokeh.fragmentShader = bokeh.materialBokeh.fragmentShader.replace('float factor = ( focus + viewZ );', 'float factor = ( 1.0 / focus + 1.0 / min( viewZ, -0.05 ) );');
    const r0 = bokeh.render.bind(bokeh); bokeh.render = (...a) => { const bg = scene.background; scene.background = null; r0(...a); scene.background = bg; };
    core.comp.insertPass(bokeh, 2);
  }
  const grade = new ShaderPass({
    uniforms: { tDiffuse: { value: null }, uSol: { value: new THREE.Vector2(.5, .5) }, uVis: { value: 0 }, uAsp: { value: OW / OH }, uHalo: { value: sec.halo ?? 1 } },
    vertexShader: `varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,
    fragmentShader: `uniform sampler2D tDiffuse;uniform vec2 uSol;uniform float uVis,uAsp,uHalo;varying vec2 vUv;
 void main(){vec3 c=texture2D(tDiffuse,vUv).rgb;float l=dot(c,vec3(.299,.587,.114));
  c*=mix(vec3(.96,1.0,1.03),vec3(1.07,1.0,.87),smoothstep(.12,.85,l));
  vec2 d=(vUv-uSol)*vec2(uAsp,1.);float r=length(d);
  vec3 h=vec3(1.,.74,.45)*(exp(-r*2.0)*.20+exp(-r*8.)*.22)*uVis*uHalo;
  c=c+h*(1.-c);gl_FragColor=vec4(clamp(c,0.,1.),1.);}`,
  });
  core.comp.addPass(grade);
  const suelos = []; scene.traverse(o => { if (o.material && o.material.userData && o.material.userData.u && o.material.userData.u.uLinA) suelos.push(o.material.userData.u.uLinA); });
  const tomas = (sec.tomas || []).slice().sort((a, b) => a.desde - b.desde);
  const vS = new THREE.Vector3(), fw = new THREE.Vector3();
  function update(t, c) {
    for (const m of polvo) m.uniforms.uT.value = t;
    if (P.lineas_lotes) for (const u of suelos) u.value = sstep(P.lineas_lotes.desde, P.lineas_lotes.hasta, t);
    if (!c) return;
    if (bokeh) {
      const tm = tomas.find(x => t >= x.desde - 1e-6 && t <= x.hasta + 1e-6);
      let f = Math.hypot(c.p[0] - c.o[0], c.p[1] - c.o[1], c.p[2] - c.o[2]);
      if (tm && tm.foco != null) { const a = Array.isArray(tm.foco) ? tm.foco : [tm.foco, tm.foco]; f = a[0] + (a[1] - a[0]) * sstep(tm.desde, tm.hasta, t); }
      bokeh.uniforms.focus.value = Math.max(1, f); bokeh.uniforms.aperture.value = DOF.k * (tm && tm.dof != null ? tm.dof : 1);
    }
    const cam = core.cam; cam.getWorldDirection(fw);
    vS.copy(cam.position).addScaledVector(sunDir, 5000).project(cam);
    grade.uniforms.uSol.value.set(vS.x * .5 + .5, vS.y * .5 + .5); grade.uniforms.uVis.value = sstep(-0.05, 0.6, fw.dot(sunDir));
  }
  // render con fundidos encadenados (cortes suaves entre tomas que no se tocan)
  function renderizador({ sc, ov, sec, hl, DUR }) {
    const F = (sec.fundidos || []).map(f => typeof f === 'number' ? { t: f, dur: 1.0 } : f);
    const tmp = document.createElement('canvas'); tmp.width = OW; tmp.height = OH; const tc = tmp.getContext('2d');
    const pasada = (tt, t) => { sc.update(tt, hl(t)); core.fin.uniforms.uT.value = t; core.comp.render(); };
    return (t, fmt = 'jpeg') => {
      t = Math.max(0, Math.min(t, DUR - 1 / 60));
      const f = F.find(f => Math.abs(t - f.t) < f.dur / 2);
      if (f) {
        const k = sstep(f.t - f.dur / 2, f.t + f.dur / 2, t);
        pasada(Math.min(t, f.t - 1e-3), t); tc.drawImage(core.renderer.domElement, 0, 0, core.W, core.H, 0, 0, OW, OH);
        pasada(Math.max(t, f.t + 1e-3), t); core.octx.drawImage(core.renderer.domElement, 0, 0, core.W, core.H, 0, 0, OW, OH);
        core.octx.globalAlpha = 1 - k; core.octx.drawImage(tmp, 0, 0); core.octx.globalAlpha = 1;
      } else { pasada(t, t); core.octx.drawImage(core.renderer.domElement, 0, 0, core.W, core.H, 0, 0, OW, OH); }
      const c = core.ctx; c.setTransform(1, 0, 0, 1, 0, 0); c.clearRect(0, 0, OW, OH); ov.draw(c, t); textos(c, t); core.octx.drawImage(core.ov, 0, 0);
      return core.out.toDataURL(fmt === 'png' ? 'image/png' : 'image/jpeg', 0.94).split(',')[1];
    };
  }
  return { update, textos, renderizador, info: { sacados, mirador: MIR } };
}
