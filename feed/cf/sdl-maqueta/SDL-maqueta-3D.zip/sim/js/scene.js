// scene.js: arma la maqueta (cielo, sol, suelo, vegetación, utilería) y la actualiza por segundo.
import * as THREE from 'three';
import { RGBELoader } from 'three/addons/loaders/RGBELoader.js';
import { construirMascara, construirLineas, construirResaltado, mallaSuelo, materialSuelo, altura, configurarIsla, glslIsla } from './terrain.js';
import { plantar } from './veg.js';
import { utileria } from './props.js';
import { makeCams } from './cams.js';
import { prepararSuelo, armarObras } from './proyecto.js'; // obras del proyecto futuro (?obras=totems)
import { armarOferta } from './oferta.js'; // video de oferta (secuencias con "guion")
const D2R = Math.PI / 180;
async function textura(url, srgb) { const t = await new THREE.TextureLoader().loadAsync(url); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = 8; t.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace; return t; }
export async function build(core, cfg, L) {
  const { scene, renderer } = core;
  const estado = cfg.estado || 'hoy';
  // v4: isla. La niebla de todos los materiales se completa hasta el color de la bruma afuera del margen (config → mundo).
  configurarIsla(cfg);
  const CH = THREE.ShaderChunk;
  if (!CH.__isla0) CH.__isla0 = { pv: CH.fog_pars_vertex, v: CH.fog_vertex, pf: CH.fog_pars_fragment, f: CH.fog_fragment };
  CH.fog_pars_vertex = CH.__isla0.pv + `
#ifdef USE_FOG
varying vec3 vIslaW;
#endif`;
  CH.fog_vertex = CH.__isla0.v + `
#ifdef USE_FOG
vIslaW=(inverse(viewMatrix)*mvPosition).xyz;
#endif`;
  CH.fog_pars_fragment = CH.__isla0.pf + `
#ifdef USE_FOG
varying vec3 vIslaW;${glslIsla()}
#endif`;
  CH.fog_fragment = CH.__isla0.f.replace('gl_FragColor.rgb = mix(', 'fogFactor=max(fogFactor,islaFundido(vIslaW));gl_FragColor.rgb = mix(');
  // ---- cielo HDRI (Poly Haven, CC0) girado para que su sol coincida con el sol de la escena
  const sol = cfg.sol || { azimut: 40, altura: 24 };
  const A = sol.azimut * D2R, E = sol.altura * D2R;
  const sunDir = new THREE.Vector3(Math.sin(A) * Math.cos(E), Math.sin(E), -Math.cos(A) * Math.cos(E));
  const hdr = await new RGBELoader().setDataType(THREE.FloatType).loadAsync('tex/cielo.hdr');
  const { width: HW, height: HH, data: HD } = hdr.image;
  let best = -1, bx = 0, by = 0; for (let y = 0; y < HH / 2; y++) for (let x = 0; x < HW; x++) { const i = (y * HW + x) * 4, l = HD[i] + HD[i + 1] + HD[i + 2]; if (l > best) { best = l; bx = x; by = y; } }
  // el sol del HDRI se recorta: la luz directa la pone el DirectionalLight (si no, el cielo aplana todo)
  const TOPE = cfg.cielo_tope ?? 6; for (let i = 0; i < HD.length; i += 4) { const m = Math.max(HD[i], HD[i + 1], HD[i + 2]); if (m > TOPE) { const k = TOPE / m; HD[i] *= k; HD[i + 1] *= k; HD[i + 2] *= k; } }
  const phiH = (bx / HW - 0.5) * 2 * Math.PI, psi = Math.atan2(sunDir.z, sunDir.x);
  const rotY = psi - phiH;
  hdr.mapping = THREE.EquirectangularReflectionMapping;
  const bgI = cfg.cielo_intensidad ?? 0.85;
  scene.background = hdr; scene.backgroundIntensity = bgI; scene.backgroundRotation.set(0, rotY, 0);
  const pm = new THREE.PMREMGenerator(renderer); const env = pm.fromEquirectangular(hdr).texture; pm.dispose();
  scene.environment = env; scene.environmentIntensity = cfg.luz_cielo ?? 0.5; scene.environmentRotation.set(0, rotY, 0);
  // color de la bruma = promedio del cielo HDRI apenas sobre el horizonte
  let fr = 0, fg = 0, fb = 0, nn = 0; for (let y = Math.floor(HH * 0.47); y < Math.floor(HH * 0.495); y++) for (let x = 0; x < HW; x += 2) { const i = (y * HW + x) * 4; fr += HD[i]; fg += HD[i + 1]; fb += HD[i + 2]; nn++; }
  const fogC = new THREE.Color().setRGB(fr / nn * bgI, fg / nn * bgI, fb / nn * bgI, THREE.LinearSRGBColorSpace);
  scene.fog = new THREE.FogExp2(fogC, cfg.bruma ?? 0.00032);
  // v4: el cielo de fondo se funde a la bruma en el horizonte (los últimos grados y todo lo de abajo), así el plano
  // de bruma que rodea la isla no deja una línea contra el cielo. La luz (environment) sigue usando el HDRI original.
  {
    const BD = new Float32Array(HD), y0 = Math.floor(HH * (0.5 - (cfg.horizonte_grados ?? 5) / 180)), yh = Math.floor(HH * 0.5);
    const fc = [fr / nn, fg / nn, fb / nn];
    for (let y = y0; y < HH; y++) { const k = y >= yh ? 1 : Math.pow((y - y0) / (yh - y0), 1.6); for (let x = 0; x < HW; x++) { const i = (y * HW + x) * 4; for (let c = 0; c < 3; c++) BD[i + c] = BD[i + c] * (1 - k) + fc[c] * k; } }
    const bg = new THREE.DataTexture(BD, HW, HH, THREE.RGBAFormat, THREE.FloatType); bg.mapping = THREE.EquirectangularReflectionMapping; bg.colorSpace = hdr.colorSpace; bg.flipY = hdr.flipY; bg.magFilter = THREE.LinearFilter; bg.minFilter = THREE.LinearFilter; bg.needsUpdate = true;
    scene.background = bg;
  }
  // ---- sol
  const luz = new THREE.DirectionalLight(cfg.sol_color || '#fff1de', cfg.sol_intensidad ?? 3.4);
  luz.castShadow = true; luz.shadow.mapSize.set(4096, 4096); luz.shadow.bias = -0.0003; luz.shadow.normalBias = 0.35;
  scene.add(luz, luz.target);
  // ---- suelo
  const mask = construirMascara(L, estado);
  if (cfg.obras) prepararSuelo(mask, cfg);
  const lineas = construirLineas(L);
  const res = construirResaltado(L, cfg.resaltar);
  const tex = { soil: await textura('tex/red_laterite_soil_stones_diff.jpg', true), soilN: await textura('tex/red_laterite_soil_stones_nor.jpg', false), grass: await textura('tex/aerial_grass_rock_diff.jpg', true) };
  const mat = materialSuelo({ mask: mask.tex, lineas, resaltado: res.tex, texturas: tex });
  const s1 = new THREE.Mesh(mallaSuelo(), mat); s1.receiveShadow = true; s1.castShadow = false; scene.add(s1);
  // afuera de la isla: plano chato del color de la bruma, un poco más bajo (no se ve la unión: los dos son bruma)
  const lejos = new THREE.Mesh(new THREE.PlaneGeometry(120000, 120000).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: fogC, fog: false }));
  lejos.position.y = -9; scene.add(lejos);
  mat.userData.u.uLinA.value = (cfg.lineas_lotes ?? (estado === 'proyecto')) ? 1 : 0;
  // ---- vegetación y utilería
  const veg = plantar(L, mask, estado); scene.add(veg);
  const ut = utileria(cfg); scene.add(ut);
  const obras = cfg.obras ? await armarObras({ scene, cfg, L, veg, ut, core, sunDir }) : null;
  // ---- cámaras
  const sec = (cfg.camaras || {})[cfg.secuencia || 'paneo'];
  const cams = makeCams(sec);
  const oferta = sec.guion ? armarOferta({ cfg, L, mat, sec }) : null;
  const cam = core.cam, v3 = new THREE.Vector3(), f = new THREE.Vector3();
  const st = {};
  function update(t, alfaHL = 0) {
    const c = cams.at(t);
    cam.position.set(...c.p); cam.up.set(0, 1, 0); cam.lookAt(v3.set(...c.o)); cam.fov = c.fov; cam.updateProjectionMatrix(); cam.updateMatrixWorld();
    // caja de sombras que sigue a la cámara
    const d = cam.position.distanceTo(v3); f.set(c.o[0] - c.p[0], 0, c.o[2] - c.p[2]); if (f.lengthSq() < 1e-6) f.set(0, 0, -1); f.normalize();
    const S = Math.min(1400, Math.max(180, d * 1.9));
    const cx = c.o[0] + f.x * S * 0.18, cz = c.o[2] + f.z * S * 0.18, cy = altura(cx, -cz);
    const tx = S / luz.shadow.mapSize.x; // ajuste a la grilla de texeles del mapa de sombras (evita que tiemblen)
    const right = new THREE.Vector3().crossVectors(sunDir, new THREE.Vector3(0, 1, 0)).normalize(), up2 = new THREE.Vector3().crossVectors(right, sunDir).normalize();
    const C0 = new THREE.Vector3(cx, cy, cz); const a = Math.round(C0.dot(right) / tx) * tx - C0.dot(right), b = Math.round(C0.dot(up2) / tx) * tx - C0.dot(up2);
    C0.addScaledVector(right, a).addScaledVector(up2, b);
    luz.target.position.copy(C0); luz.position.copy(C0).addScaledVector(sunDir, 2500); luz.target.updateMatrixWorld();
    const sc = luz.shadow.camera; sc.left = -S / 2; sc.right = S / 2; sc.top = S / 2; sc.bottom = -S / 2; sc.near = 1500; sc.far = 3600; sc.updateProjectionMatrix();
    mat.userData.u.uHL.value = alfaHL;
    st.cam = c;
    if (obras) obras.update(t, c);
    if (oferta) oferta.update(t);
  }
  return { update, cams, obras, oferta, grupos: res.grupos, st, cuenta: veg.userData.cuenta, sunDir, rotY, sunHDR: [bx, by] };
}
