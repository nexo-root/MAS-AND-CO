// glsl.js: ruido compartido (GLSL y JS, determinista). Regla C1: nunca pow/sqrt/log con negativos.
export const NOISE=`
float h11(float n){return fract(sin(n*127.1+311.7)*43758.5453);}
float h21(vec2 p){p=fract(p*vec2(123.34,456.21));p+=dot(p,p+45.32);return fract(p.x*p.y);}
float h31(vec3 p){p=fract(p*vec3(.1031,.1030,.0973));p+=dot(p,p.yzx+33.33);return fract((p.x+p.y)*p.z);}
float vn2(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(h21(i),h21(i+vec2(1,0)),f.x),mix(h21(i+vec2(0,1)),h21(i+vec2(1,1)),f.x),f.y);}
float vn3(vec3 p){vec3 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);
 return mix(mix(mix(h31(i),h31(i+vec3(1,0,0)),f.x),mix(h31(i+vec3(0,1,0)),h31(i+vec3(1,1,0)),f.x),f.y),mix(mix(h31(i+vec3(0,0,1)),h31(i+vec3(1,0,1)),f.x),mix(h31(i+vec3(0,1,1)),h31(i+vec3(1,1,1)),f.x),f.y),f.z);}
float fbm2(vec2 p){float a=.5,s=0.;for(int i=0;i<5;i++){s+=a*vn2(p);p=p*2.03+vec2(17.1,9.2);a*=.5;}return s;}
float fbm3(vec3 p){float a=.5,s=0.;for(int i=0;i<4;i++){s+=a*vn3(p);p=p*2.02+vec3(7.1,3.2,5.7);a*=.5;}return s;}
float spow(float x,float n){return pow(max(x,0.),n);}
`;
const fr=x=>x-Math.floor(x);
export function h2(x,y){let px=fr(x*0.1031),py=fr(y*0.1030),pz=fr(x*0.0973);const d=px*(py+33.33)+py*(pz+33.33)+pz*(px+33.33);px+=d;py+=d;pz+=d;return fr((px+py)*pz);}
export function vn2(x,y){const ix=Math.floor(x),iy=Math.floor(y);let fx=x-ix,fy=y-iy;fx=fx*fx*(3-2*fx);fy=fy*fy*(3-2*fy);
  const a=h2(ix,iy),b=h2(ix+1,iy),c=h2(ix,iy+1),d=h2(ix+1,iy+1);return a+(b-a)*fx+(c-a)*fy+(a-b-c+d)*fx*fy;}
export function fbm2(x,y,o=5){let a=.5,s=0;for(let i=0;i<o;i++){s+=a*vn2(x,y);x=x*2.03+17.1;y=y*2.03+9.2;a*=.5;}return s;}
export function ridge2(x,y,o=5){let a=.5,s=0;for(let i=0;i<o;i++){s+=a*(1-Math.abs(vn2(x,y)*2-1));x=x*2.03+17.1;y=y*2.03+9.2;a*=.5;}return s;}
