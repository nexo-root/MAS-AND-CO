// overlay.js: rótulos con línea fina hacia cada grupo resaltado y texto de cierre. Montserrat, blanco con acento.
import { OW, OH, VERT } from './core.js';
import { toWorld } from './geo.js';
import { altura } from './terrain.js';
import { sstep } from './k.js';
export function makeOverlay({ grupos, cfg, proj }) {
  const R = cfg.resaltado || {}; const t0 = R.desde ?? 0, fade = R.fundido ?? 1.2;
  const TF = cfg.texto_final || null;
  const S = VERT ? 1.25 : 1; const M = 56 * S; // margen seguro
  const anc = grupos.map(g => { const [x, y] = toWorld(g.centro[0], g.centro[1]); return [x, altura(x, y) + 0.5, -y]; });
  function draw(ctx, t) {
    const a = sstep(t0 + fade * 0.5, t0 + fade * 1.3, t);
    if (a > 0.001 && grupos.length) {
      const P = anc.map(p => proj(...p));
      const vis = P.filter(p => p.ok); if (vis.length) {
        const cx = vis.reduce((s, p) => s + p.x, 0) / vis.length, cy = vis.reduce((s, p) => s + p.y, 0) / vis.length;
        ctx.save(); ctx.globalAlpha = a;
        const fs = Math.round(30 * S); ctx.font = `600 ${fs}px Mont`; ctx.textBaseline = 'middle';
        const usados = [];
        grupos.forEach((g, i) => {
          const p = P[i]; if (!p.ok) return;
          let dx = p.x - cx, dy = p.y - cy; let l = Math.hypot(dx, dy);
          if (l < 1) { dx = 1; dy = 0; l = 1; }
          dx /= l; dy /= l;
          if (!VERT) { dy *= 0.6; } else { dx *= 0.6; }
          const L = (VERT ? 150 : 190) * S;
          const txt = g.rotulo || `Mz ${g.mz} · Lotes ${(g.lotes || []).join(', ')}`;
          const tw = ctx.measureText(txt).width, pad = 14 * S, bh = fs + pad * 1.2;
          let lx = p.x + dx * L, ly = p.y + dy * L;
          const izq = dx < 0; // el texto crece hacia afuera
          let bx = izq ? lx - tw - pad * 2 : lx; bx = Math.max(M, Math.min(OW - M - tw - pad * 2, bx));
          let by = Math.max(M + bh / 2, Math.min(OH - M - bh / 2, ly));
          for (const u of usados) if (Math.abs(u - by) < bh * 1.25) by = u + (by >= u ? 1 : -1) * bh * 1.3;
          usados.push(by);
          const ex = izq ? bx + tw + pad * 2 : bx;
          // línea fina
          ctx.strokeStyle = 'rgba(255,255,255,0.92)'; ctx.lineWidth = 1.6 * S; ctx.shadowColor = 'rgba(0,0,0,0.55)'; ctx.shadowBlur = 6 * S;
          ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(ex, by); ctx.stroke();
          ctx.fillStyle = g.color; ctx.beginPath(); ctx.arc(p.x, p.y, 5 * S, 0, Math.PI * 2); ctx.fill();
          // caja
          ctx.shadowBlur = 18 * S; ctx.fillStyle = 'rgba(14,20,24,0.62)'; rr(ctx, bx, by - bh / 2, tw + pad * 2, bh, 6 * S); ctx.fill();
          ctx.shadowBlur = 0; ctx.fillStyle = g.color; ctx.fillRect(izq ? bx + tw + pad * 2 - 4 * S : bx, by - bh / 2, 4 * S, bh);
          ctx.fillStyle = '#fff'; ctx.textAlign = 'left'; ctx.fillText(txt, bx + pad, by + 1);
        });
        ctx.restore();
      }
    }
    if (TF) {
      const b = sstep(TF.desde, TF.desde + 1.0, t);
      if (b > 0.001) {
        ctx.save(); ctx.globalAlpha = b; ctx.shadowColor = 'rgba(0,0,0,0.6)'; ctx.shadowBlur = 16 * S;
        const f1 = Math.round((VERT ? 62 : 54) * S * 0.85), f2 = Math.round(26 * S);
        ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
        const x = M + 6, y = VERT ? M + 210 : M + f1 + 30;
        ctx.fillStyle = TF.color || '#3CCFFF'; ctx.fillRect(x, y - f1 - 10, 64 * S, 4 * S);
        ctx.fillStyle = '#fff'; ctx.font = `700 ${f1}px Mont`; ctx.fillText(TF.titulo || '', x, y);
        if (TF.sub) { ctx.font = `500 ${f2}px Mont`; ctx.fillStyle = 'rgba(255,255,255,0.88)'; ctx.fillText(TF.sub, x, y + f2 + 14); }
        ctx.restore();
      }
    }
  }
  return { draw, alfaResaltado: t => sstep(t0, t0 + fade, t) };
}
function rr(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
