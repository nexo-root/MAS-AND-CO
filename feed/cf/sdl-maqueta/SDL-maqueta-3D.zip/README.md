# Solares de Loreto · maqueta 3D (base fija para videos y PDFs)

Réplica en three.js del loteo armada desde `C:\dev\videos\sdl-referencia\loteo.json` (20 manzanas, 252 parcelas) y las fotos de dron.
Cómo calzan las fotos con el plano: `ORIENTACION.md`.

| Archivo | Qué es |
|---|---|
| `sim/` | La maqueta (lo que se empaqueta). `index.html`, `js/*.js`, `config.json`, `loteo.json`, `tex/` (cielo HDRI y texturas CC0 de Poly Haven), `fonts/` (Montserrat, OFL), `node_modules/three` (MIT, r170) |
| `paneo-horizontal.mp4` / `paneo-vertical.mp4` | Paneo de prueba (33 s, 30 fps, sin audio) |
| `control/` | Comparaciones foto real / maqueta (`cmp-*.jpg`), hoja del paneo (`hoja-*.jpg`) y cuadros sueltos |
| `cuadros.cjs` | Saca cuadros sueltos: `node cuadros.cjs "<query>" <prefijo> t1 t2 …` → `control/<prefijo>-<t>.jpg` |
| `grabar.cjs` | Graba el video con la placa de video |
| `comparar.py`, `hoja.py` | Arman las comparaciones y las hojas de cuadros |

## Contrato de render (el de siempre)
`window.__ready = true` al cargar · `window.renderFrame(t,'jpeg'|'png')` → base64 del cuadro del segundo t (determinista) · `window.__DUR` = duración.
Hay que servir `sim/` por http (la página hace fetch de los json, las texturas y la fuente).

Parámetros de URL: `?formato=vertical` (1080x1920, reencuadra: aleja la cámara y abre el lente) · `?estado=hoy|proyecto` · `?secuencia=paneo|foto01|foto03|cartel|totems|oferta|oferta_general` · `?config=otro.json` · `?ss=1.5` (supermuestreo; 1 para pruebas rápidas).

## Cambiar cosas (todo en `sim/config.json`)

**Estado**
- `"estado": "hoy"`: solo las calles que se ven en las fotos (anillo y cruz de la primera etapa con la ochava de la Mz 06, camino público NO largo, camino SO hasta la longitudinal 2), claro del mirador con piedra basáltica, Mz 05 con monte, resto monte y pastizal.
- `"estado": "proyecto"`: todas las calles de las 20 manzanas, rotonda completa alrededor de la isla B3, todos los lotes desmontados y con la línea de cada lote (los espacios verdes conservan el monte). `"lineas_lotes": true/false` fuerza las líneas en cualquier estado.

**Lotes resaltados**
```json
"resaltar": [ { "mz": 2, "lotes": [11,12,13], "color": "#3CCFFF", "rotulo": "Mz 2 · Lotes 11-13" } ],
"resaltado": { "desde": 29.0, "fundido": 1.5 }
```
Cualquier manzana y lote de `loteo.json` (también especiales: `{"mz":13,"lotes":[1]}`). Sin `"lotes"` se resalta la manzana entera. Cada entrada es un rótulo con su línea fina; si un grupo queda partido (lotes lejos entre sí), conviene separarlo en dos entradas. El lote se tiñe, lleva borde fino y su número pintado en el suelo.
`"texto_final": {"desde", "titulo", "sub", "color"}` es el título del cierre (borrarlo = sin título).

**Cámaras**
```json
"camaras": { "paneo": { "marco": "plano", "fov": 45, "fov_vertical": 70, "factor_vertical": 1.35, "cola": 2.5,
  "tomas": [ { "desde": 0, "hasta": 6, "posicion": [[x,y,altura],[x,y,altura]], "objetivo": [[x,y,0],[x,y,0]], "ease": "continuo" } ] } }
```
- Metros. `"marco": "mundo"` → x este, y norte, origen en el centro (como `poligono` de loteo.json). `"marco": "plano"` → u a lo largo de D→C, v hacia A, origen en el vértice D (como `poligono_plano`; es más cómodo: las calles son rectas, p. ej. longitudinal 1 en v = 292,4, transversal 1 en u = 107,5, mirador en (227,9; 172,2), esquina A en (0; 400)).
- Tomas encadenadas (una empieza donde termina la anterior) se recorren sin frenar (spline en el tiempo). `"ease": "suave"` frena y arranca en esa toma. Mínimo 1,5 s por toma. `"fov"` opcional por toma (número o `[ini, fin]`).
- Cenital: poné la cámara casi encima del objetivo, corrida 1-2 m hacia el lado contrario de lo que querés arriba en la pantalla (p. ej. objetivo v = 290 y cámara v = 288,5 → el noroeste queda arriba, como el plano).
- `"cola"`: segundos quietos al final. `"sin_textos": true` apaga rótulos y títulos.
- Ya hay cámaras guardadas que imitan las fotos: `foto01` (cenital, vertical) y `foto03` (diagonal), y `cartel` (ingreso).

**Luz**: `"sol": {"azimut": 40, "altura": 24}` (grados; 40 = noreste, como en las fotos), `sol_intensidad`, `luz_cielo`, `cielo_intensidad`, `bruma`, `exposicion`. `"auto": false` saca el auto blanco; `"auto_plano": [u, v, rumbo]` lo mueve.

## Grabar
```
cd C:\dev\videos\sdl-maqueta
node grabar.cjs paneo-horizontal
node grabar.cjs paneo-vertical --query "formato=vertical"
node grabar.cjs mi-video --query "estado=proyecto&secuencia=paneo" --audio voz.wav
```
Sale `<nombre>.mp4` acá mismo; los cuadros (`cuadros-<nombre>/`) se borran solos si el mp4 salió bien. ~0,15-0,3 s por cuadro con la GTX 1650.
También funciona el grabador de siempre: `node C:\Users\mfeli\OneDrive\Desktop\PW1\negocio\higgsfield\content-factory\render_local.cjs C:\dev\videos\sdl-maqueta --seg 33 --nombre paneo` (deja el mp4 en `C:\dev\videos\`).

Cuadros sueltos para revisar: `node cuadros.cjs "ss=1" p 0 10 20 30` · comparación: `python comparar.py <foto> control\p-10.jpg control\cmp.jpg`.

## Empaquetar para un chat de Higgsfield
```
cd C:\dev\videos\sdl-maqueta
tar -a -c -f sdl-maqueta-sim.zip sim ORIENTACION.md README.md
```
(≈ 16 MB). En el pedido decir: «Base fija: maqueta de Solares de Loreto en `sim/`. No cambies el terreno, las calles ni la vegetación (`js/terrain.js`, `js/veg.js`, `loteo.json`). Para cada video armá una secuencia nueva en `config.json → camaras` y los `resaltar` que pida el guion; si hace falta algo nuevo (rótulos, gráficos), agregalo en `js/overlay.js` o en un archivo nuevo. Respetá el contrato `__ready` / `renderFrame` / `__DUR`. Nunca la palabra "Simulación". No inventes casas, alambrados, postes de luz ni tanque.»
El kit que devuelva se graba en la PC con `render_local.cjs` (manual: `PW1\negocio\higgsfield\MANUAL-DIRECTOR-CLAUDE-CODE.md`).

## Proyecto futuro: tótems y mirador (19/11, secuencia `totems`)
Activación: `?secuencia=totems` (la secuencia trae sus `ajustes`: estado proyecto, `obras: "totems"`, sol dorado, sin auto ni resaltados). En cualquier otra secuencia: `?obras=totems` agrega las obras; `?obras=no` las saca. Sin `obras` la maqueta queda exactamente como antes (paneo, foto01, foto03, cartel).
```
node grabar.cjs proyecto-totems-horizontal --query "secuencia=totems"
node grabar.cjs proyecto-totems-vertical --query "secuencia=totems&formato=vertical"
node cuadros.cjs "secuencia=totems&ss=1" totems 1 18 28 38      (cuadros sueltos)
node sondear.cjs "secuencia=totems" "window.__obras"            (alturas y ubicaciones; window.__obras.alt(u,v) = suelo)
```
Código nuevo: `sim/js/proyecto.js` (obras, piedra procedural, Cristo, árbol, polvo, profundidad de campo, etalonaje, textos y fundidos). Enganches mínimos en `scene.js` (3 líneas), `main.js` (ajustes por secuencia, `?obras`, render con fundidos) y `cams.js` (opción `"mirada": "suave"`). Copia previa: `js-v2-antes-totems/` y `config-v2-antes-totems.json`.
Fuentes: `fonts/Montserrat-SemiBold.ttf` y `-Medium.ttf` (instancias estáticas de la variable, para las letras 3D). Se agregaron a `node_modules/three/examples/jsm/` TTFLoader, FontLoader, TextGeometry, RoundedBoxGeometry y libs/opentype (copias de r170).

**Cambiar cosas (`config.json → proyecto`)**
- `totem_pueblo`: `plano` [u, v] (hoy u = −270 sobre el camino público NO, del lado del loteo), `rumbo` (brújula: hacia dónde mira la cara, 291 = oeste-noroeste, de frente a quien viene del pueblo), `lineas` (texto de la placa, una palabra por renglón), `flecha` (apunta hacia el loteo).
- `portal`: `plano` (centro del portal sobre el camino SO, en la esquina A), `rumbo` 326 = mira al camino NO, `titulo`, `sub` ("LOTEO"), `luces`.
- `mirador`: `rumbo_cristo` (brújula; 56 = noreste, hacia el lado B‑C, donde pasa el arroyo Yabebirí según ESTRUCTURA §8), `cristo_alto` (estatua sin pedestal, m; el pedestal suma 2,5 m), `arbol`, `bancos`.
- `textos`: `titulo` (apertura), `cierre` (`titulo`, `sub`, `desde`), `aviso` (esquina, todo el video), `acento`.
- `lineas_lotes`: {desde, hasta} = las líneas de los lotes aparecen en la subida a cenital (antes no se ven, para que el suelo no parezca un plano).
**Cámaras** (`camaras.totems`): tomas como siempre; además `"fundidos": [{"t": 22, "dur": 1}]` (corte con fundido entre tomas que no se tocan), `"dof": {"k": 0.25, "maxblur": 0.02}` (profundidad de campo; enfoca solo al `objetivo`), por toma `"foco": [m ini, m fin]` y `"dof": 0..1`, y `"mirada": "suave"` (la mirada frena en los extremos sin frenar la cámara: evita latigazos del objetivo).

## Video de OFERTA de lotes (20/11, secuencias `oferta` y `oferta_general`)
Para venderle paquetes de lotes a un cliente. `oferta` = versión cliente (paquetes 1, 2 y 3, 41,5 s); `oferta_general` = solo paquetes 1 y 2 (35 s).
Sin voz ni audio. Estado "hoy" (no toca terreno, calles ni vegetación).
```
bash grabar-oferta.sh                                               (graba los 4: cliente/general x horizontal/vertical)
node grabar.cjs oferta-cliente-vertical --query "secuencia=oferta&formato=vertical"
node cuadros.cjs "secuencia=oferta&ss=1" o 18 26 34                 (cuadros sueltos para revisar)
```
Código nuevo: `sim/js/oferta.js` (resaltado propio con alfa por lote y por segundo: celeste tenue → dorado; fichas con el número de cada lote; marca de esquina; rótulos con línea fina; textos con velo). Enganches: `scene.js` (3 líneas: import, `armarOferta` si la secuencia trae `"guion"`, `oferta.update(t)`) y `main.js` (1 línea: render con el overlay de la oferta). Copias previas: `sim/config-antes-oferta.json`, `scene-antes-oferta.js.bak`, `main-antes-oferta.js.bak`.
La config se genera con `python _oferta_config.py` (pisa solo `oferta`, `camaras.oferta` y `camaras.oferta_general`); se puede editar ahí o directo en `config.json`.

**Cambiar paquetes y precios (`config.json → oferta`)**
- `paquetes.p1/p2/p3`: `mz`, `lotes` (los que se pintan de dorado), `titulo` ("Paquete 1"), `linea` ("Mz 2 · Lotes 11 a 13"), `dato` ("3 lotes juntos · 1.580 m²"), `nota` (renglón chico opcional), `precio` ("USD 15.000" o "Consultar"), `esquina` (n.º de lote) + `marca_esquina` ("ESQUINA"), `rotulo_horizontal` / `rotulo_vertical` = [x, y] de la caja en fracción de pantalla (0 = izquierda/arriba, 1 = derecha/abajo).
- `disponibles`: los lotes en celeste tenue (hoy los 13 de la app al 12/11). Colores: `color_disponible`, `color_paquete`.
**Tiempos (`camaras.oferta.guion`)**: `disponibles` {desde, alfa}; `paquetes` [{id, desde, hasta, rotulo:[ini, fin]}] (`hasta` = vuelve a celeste; sin `hasta` queda dorado); `todos_desde` (en el cierre se encienden todos los paquetes); `textos` [{desde, hasta, pos, pos_vertical, lineas:[[estilo, texto]]}] con estilos `titulo` (Georgia), `sub`, `dato`, `chico`, `etiqueta`, `grande`. Los renglones largos se cortan solos en " · ".
Para sacar o agregar un paquete: quitar/agregar su entrada en `guion.paquetes` y ajustar las `tomas` (cada paquete tiene su toma baja). Si cambia un precio, solo `precio` y volver a grabar.

## Lo que se sabe que no es igual a las fotos
- El mirador (isla B3) es un claro chico con lajas de basalto; desde arriba casi no se distingue (en las fotos se ve una mancha oscura con piedra más grande).
- El pastizal alrededor de la rotonda tiene un borde más prolijo que en la realidad y es un poco más claro.
- Desde v4 no hay bosque hasta el horizonte: el mundo es una isla (predio + margen) que se funde en la bruma. En las tomas altas se ve el borde blanco-grisáceo alrededor; la foto real tiene pinar y monte hasta el fondo.
- La copa del monte nativo se ve un poco más "redondeada" que en las fotos de cerca.
- El sol viene del noreste (como en las fotos), no de "media tarde".

## Historial
- v1 (17/11): primera maqueta. Guardada en `v1/` (mp4) y `js-v1-antes-arboles/` (código).
- v2 (18/11): pedido de Juan Diego — más árboles que cubren el loteo (monte más denso: paso 6,2→4,4 m, más árboles sueltos en el desmonte y pastizal abierto de la rotonda achicado ~25 %). Es la versión vigente. Nota: si `grabar.cjs` falla al final con ffmpeg, los cuadros quedan en `cuadros-<nombre>/`; codificar a mano con el mismo comando ffmpeg que figura en `log-*.txt`.
- v2+totems (19/11): proyecto futuro con tótem del pueblo, portal y mirador con Cristo (`proyecto-totems-*.mp4`). La v2 sigue intacta sin `obras`.
- v3 (19/11): poda de árboles según 19 videos mirados con /watch (ver `C:\dev\videos\sdl-referencia\ESTADO-REAL.md`): primera etapa casi pelada (~30-35 árboles sueltos), Mz 05 con 2/3 de monte cerrado, pastizal abierto en la rotonda como en las fotos. Código anterior en `js-v3-antes-podar/`; videos anteriores en `v1/` y `v2/`. Se regraban los 4 videos con `bash grabar4.sh`.
- v4 aligerada (20/11): pedido de Felipe — «lo importante es ver el loteo; eliminar todo alrededor». El mundo termina a ~110 m del predio (predio 500 × 400 + caminos públicos de 25 m + Lote B2) y se funde en la bruma: sin techo de bosque pintado, sin pinar lejano. El pinar es solo la franja de ~100 m junto al camino público NO (los últimos 60 m se ralean y bajan); en el borde los árboles se ralean, se achican y se pierden en la niebla. El sorteo de árboles es el mismo de v3 (cambia apenas porque la máscara tiene otra grilla). Medido (oferta horizontal): pinos 78.560 → 4.766 · monte 46.588 → 12.074 + 3.813 livianos en el margen · secos 3.425 → 979 · matas 2.804 → 2.709 · triángulos 30,7 M → 7,8 M · malla del suelo 1,3 M → ~0,3 M triángulos · máscara 4096² → 3328². El tiempo por cuadro casi no cambió (lo domina el supermuestreo, el posproceso y el JPEG, no la geometría). Copias previas: `js-v4-antes-aligerar/` y `config-v4-antes-aligerar.json`; videos de oferta anteriores en `C:\dev\videos\sdl-lote-venta\v1\`. Se regraban con `bash grabar-oferta.sh`.
  **Cambiar el margen** (`config.json → mundo`): `"margen": 110` (metros desde el borde del predio/caminos hasta la mitad del fundido), `"fundido": 110` (ancho de la bruma del borde), `"pinar_fondo": 100` (fondo del pinar desde el camino NO), `"onda": 22` (cuánto se ondula el borde para que no sea un rectángulo). Una secuencia puede sumar cajas a la isla con `ajustes → isla_extra: [[u0, v0, u1, v1]]` (marco del plano): `totems` la usa para el camino al pueblo (tótem en u = −270). `"horizonte_grados": 5` funde el cielo con la bruma en el horizonte. Para medir: `node medir.cjs "secuencia=oferta"` (instancias, triángulos, carga, ms por cuadro).

